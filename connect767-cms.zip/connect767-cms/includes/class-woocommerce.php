<?php
/**
 * WooCommerce integration. Everything here is a no-op if WooCommerce isn't
 * active — the rest of the site (listings, blog, uniforms) doesn't depend
 * on it.
 *
 *  - Adds an "icon" field to product categories (Remix Icon class name,
 *    e.g. ri-t-shirt-line) so the shop page's category pills have icons,
 *    exposed via the woocommerce_rest_prepare_product_cat filter to match
 *    what src/lib/mappers.js's mapWcCategory expects at wc.acf.icon.
 *
 *  - POST /connect767/v1/checkout — headless checkout bridge. Takes cart
 *    items from the React cart drawer, creates a real WooCommerce order,
 *    and returns the order's native "pay for order" URL so the browser can
 *    be redirected there to complete payment through whatever gateways are
 *    configured in WooCommerce (Stripe, PayPal, etc.) — building a second,
 *    custom payment flow isn't necessary or wise; WooCommerce already
 *    solves that well.
 */

if (!defined('ABSPATH')) {
    exit;
}

class C767_WooCommerce
{
    const NAMESPACE_ = 'connect767/v1';

    public static function init()
    {
        if (!class_exists('WooCommerce')) {
            return;
        }

        add_action('product_cat_add_form_fields', [__CLASS__, 'render_icon_field_add']);
        add_action('product_cat_edit_form_fields', [__CLASS__, 'render_icon_field_edit']);
        add_action('created_product_cat', [__CLASS__, 'save_icon_field']);
        add_action('edited_product_cat', [__CLASS__, 'save_icon_field']);

        add_filter('woocommerce_rest_prepare_product_cat', [__CLASS__, 'inject_icon_into_rest'], 10, 3);
        add_filter('woocommerce_rest_prepare_product_object', [__CLASS__, 'inject_fallback_image'], 10, 3);
        register_post_meta('product', 'fallback_image', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'string',
            'auth_callback' => function () {
                return current_user_can('edit_posts');
            },
        ]);

        add_action('rest_api_init', [__CLASS__, 'register_routes']);
    }

    /**
     * If a product has no real gallery image attached (sample-imported
     * products reference an external URL rather than a downloaded media
     * attachment — see class-importer.php), fall back to that URL so
     * mapWcProduct's `wc.images[0].src` still resolves to something.
     */
    public static function inject_fallback_image($response, $product, $request)
    {
        $data = $response->get_data();
        if (empty($data['images'])) {
            $fallback = get_post_meta($product->get_id(), 'fallback_image', true);
            if ($fallback) {
                $data['images'] = [['id' => 0, 'src' => $fallback, 'alt' => $product->get_name()]];
                $response->set_data($data);
            }
        }
        return $response;
    }

    // ---------- Category icon field ----------

    public static function render_icon_field_add()
    {
        ?>
        <div class="form-field">
            <label for="c767_icon">Icon (Remix Icon class)</label>
            <input type="text" name="c767_icon" id="c767_icon" placeholder="ri-t-shirt-line" />
            <p class="description">Used for the category pill icon on the Shop page. Browse icons at remixicon.com.</p>
        </div>
        <?php
    }

    public static function render_icon_field_edit($term)
    {
        $icon = get_term_meta($term->term_id, 'c767_icon', true);
        ?>
        <tr class="form-field">
            <th scope="row"><label for="c767_icon">Icon (Remix Icon class)</label></th>
            <td>
                <input type="text" name="c767_icon" id="c767_icon" value="<?php echo esc_attr($icon); ?>" placeholder="ri-t-shirt-line" />
                <p class="description">Used for the category pill icon on the Shop page. Browse icons at remixicon.com.</p>
            </td>
        </tr>
        <?php
    }

    public static function save_icon_field($term_id)
    {
        if (isset($_POST['c767_icon'])) {
            update_term_meta($term_id, 'c767_icon', sanitize_text_field(wp_unslash($_POST['c767_icon'])));
        }
    }

    public static function inject_icon_into_rest($response, $item, $request)
    {
        $icon = get_term_meta($item->term_id, 'c767_icon', true);
        $data = $response->get_data();
        $data['acf'] = ['icon' => $icon ?: 'ri-price-tag-3-line'];
        $response->set_data($data);
        return $response;
    }

    // ---------- Headless product/category proxy ----------

    /**
     * Real WooCommerce data via the plugin's own REST namespace instead of
     * the frontend hitting wc/v3 directly with a consumer key/secret baked
     * into the client-side JS bundle — anyone can read that out of the
     * built bundle in devtools, which is fine for local development but
     * not something that belongs in a production site. These proxy
     * endpoints read the data server-side (wc_get_products(), no API keys
     * involved) and return it pre-shaped to match what wc/v3 would have
     * returned, so src/lib/mappers.js's mapWcProduct/mapWcCategory don't
     * need to change — only the URL the frontend calls does (see
     * src/lib/config.js's customApiUrl vs wcApiUrl).
     */
    public static function register_routes()
    {
        register_rest_route(self::NAMESPACE_, '/checkout', [
            'methods' => 'POST',
            'callback' => [__CLASS__, 'checkout'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_, '/shop/products', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'list_products'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::NAMESPACE_, '/shop/categories', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'list_categories'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function list_products(WP_REST_Request $request)
    {
        $slug = $request->get_param('slug');

        // wc_get_products() doesn't recognize a 'slug' query var — WC_Product_Query
        // only matches post_name via 'name', so passing 'slug' here was silently
        // ignored and every request returned the entire catalog regardless of what
        // slug was asked for. That's why the product detail page always rendered
        // whichever product happened to come back first: the real bug behind
        // "every product link goes to the same item" (see WORDPRESS.md), not the
        // getProductBySlug() client-side filtering added as a defensive fix. Reuse
        // the same get_page_by_path() lookup product_id_from_slug() already uses
        // for checkout, which is known to resolve a WooCommerce product by slug
        // correctly.
        if ($slug) {
            $product_id = self::product_id_from_slug(sanitize_title($slug));
            $product = $product_id ? wc_get_product($product_id) : null;
            $products = ($product && $product->get_status() === 'publish') ? [$product] : [];
            return rest_ensure_response(array_map([__CLASS__, 'format_product'], $products));
        }

        // Preserve the manual order set in WordPress (Products > Sorting).
        // The frontend applies the Featured-first grouping without losing this
        // catalog order inside the featured and non-featured groups.
        $products = wc_get_products([
            'status' => 'publish',
            'limit' => -1,
            'orderby' => 'menu_order',
            'order' => 'ASC',
        ]);
        return rest_ensure_response(array_map([__CLASS__, 'format_product'], $products));
    }

    private static function format_product($product)
    {
        $image_id = $product->get_image_id();
        $image_ids = array_values(array_unique(array_filter(array_merge(
            $image_id ? [$image_id] : [],
            $product->get_gallery_image_ids()
        ))));
        $description = $product->get_description();
        $description_mentions_size_guide = (bool) preg_match(
            '/size\s*(chart|guide)|sizing|measurement/i',
            wp_strip_all_tags($description . ' ' . $product->get_short_description())
        );
        $has_size_attribute = false;
        foreach ($product->get_attributes() as $attribute) {
            $attribute_name = self::normalize_image_match_text(wc_attribute_label($attribute->get_name()));
            if (in_array($attribute_name, ['size', 'sizes', 'sizing'], true)) {
                $has_size_attribute = true;
                break;
            }
        }
        $images = array_values(array_filter(array_map(function ($attachment_id) use ($description_mentions_size_guide, $has_size_attribute) {
            $src = wp_get_attachment_url($attachment_id);
            if (!$src) {
                return null;
            }

            $metadata = wp_get_attachment_metadata($attachment_id);
            $width = (int) ($metadata['width'] ?? 0);
            $height = (int) ($metadata['height'] ?? 0);
            $title = get_the_title($attachment_id);
            $alt = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
            $caption = wp_get_attachment_caption($attachment_id);
            $search_text = self::normalize_image_match_text(implode(' ', [
                $title,
                $alt,
                $caption,
                pathinfo(wp_parse_url($src, PHP_URL_PATH) ?: '', PATHINFO_FILENAME),
            ]));
            $explicit_size_chart = preg_match('/(sizechart|sizeguide|sizingchart|measurement)/', $search_text);
            $likely_legacy_chart = ($description_mentions_size_guide || $has_size_attribute)
                && $height > 0
                && ($width / $height) >= 2.5;

            return [
                'id' => $attachment_id,
                'src' => $src,
                'name' => $title,
                'alt' => $alt,
                'width' => $width,
                'height' => $height,
                'is_size_chart' => (bool) ($explicit_size_chart || $likely_legacy_chart),
            ];
        }, $image_ids)));
        if (empty($images)) {
            $fallback = get_post_meta($product->get_id(), 'fallback_image', true);
            if ($fallback) {
                $images[] = ['id' => 0, 'src' => $fallback];
            }
        }

        $categories = array_map(function ($term) {
            return ['name' => $term->name, 'slug' => $term->slug];
        }, wc_get_product_terms($product->get_id(), 'product_cat'));

        $tags = array_map(function ($term) {
            return ['name' => $term->name];
        }, wc_get_product_terms($product->get_id(), 'product_tag'));

        $result = [
            'id' => $product->get_id(),
            'slug' => $product->get_slug(),
            'name' => $product->get_name(),
            'description' => $description,
            'short_description' => $product->get_short_description(),
            'type' => $product->get_type(),
            'price' => $product->get_price(),
            'regular_price' => $product->get_regular_price(),
            'on_sale' => $product->is_on_sale(),
            'featured' => $product->is_featured(),
            'menu_order' => $product->get_menu_order(),
            'date_created' => $product->get_date_created()
                ? $product->get_date_created()->date(DATE_ATOM)
                : null,
            'average_rating' => $product->get_average_rating(),
            'rating_count' => $product->get_rating_count(),
            'stock_status' => $product->get_stock_status(),
            'stock_quantity' => $product->get_stock_quantity(),
            'backorders_allowed' => $product->backorders_allowed(),
            'purchasable' => $product->is_purchasable(),
            'categories' => $categories,
            'tags' => $tags,
            'images' => $images,
            'size_chart' => current(array_filter($images, function ($image) {
                return !empty($image['is_size_chart']);
            })) ?: null,
        ];

        // Real size/color (etc.) support — previously this endpoint only
        // ever returned simple-product data, so a "T-Shirt" configured in
        // WooCommerce the normal way (a variable product with Size/Color
        // attributes) had no way for the frontend to show a size or color
        // picker at all, and "add to cart" had no variation ID to add.
        if ($product->is_type('variable')) {
            $color_image_map = self::build_color_image_map($product, $image_ids);
            $result['attributes'] = array_map(function ($attribute) {
                // WC_Product_Attribute::get_options() behaves differently
                // depending on attribute type: for a *global* attribute
                // (the standard, taxonomy-based way WooCommerce sites
                // usually set up Size/Color — anything named "pa_...")
                // it returns raw term IDs (integers), not label strings.
                // Only custom (non-taxonomy) attributes get real string
                // values directly. Passing a bare integer through to the
                // frontend crashed the variation picker entirely
                // (`n.toLowerCase is not a function` — a number has no
                // such method) the moment anyone selected an option.
                $options = $attribute->is_taxonomy()
                    ? array_map(function ($term_id) use ($attribute) {
                        $term = get_term($term_id, $attribute->get_name());
                        return $term && !is_wp_error($term) ? $term->name : (string) $term_id;
                    }, $attribute->get_options())
                    : $attribute->get_options();

                return [
                    'name' => wc_attribute_label($attribute->get_name()),
                    'options' => $options,
                ];
            }, array_values($product->get_attributes()));

            $result['variations'] = array_map(function ($variation_id) use ($color_image_map) {
                $variation = wc_get_product($variation_id);
                if (!$variation) {
                    return null;
                }
                // A variation may manage its own stock (the normal setup for
                // size-specific quantities) or inherit inventory from its
                // parent. Always expose the effective stock owner so the
                // storefront can prevent the cart from exceeding what
                // WooCommerce will accept at checkout.
                $stock_owner_id = method_exists($variation, 'get_stock_managed_by_id')
                    ? (int) $variation->get_stock_managed_by_id()
                    : (int) $variation->get_id();
                $stock_owner = $stock_owner_id === (int) $variation->get_id()
                    ? $variation
                    : wc_get_product($stock_owner_id);
                if (!$stock_owner) {
                    $stock_owner = $variation;
                }
                // `get_image_id()` in view context inherits the parent product's
                // thumbnail when the variation itself has no image. That made
                // every color report the exact same URL. Prefer a genuinely
                // assigned variation image, then the matching parent-gallery
                // color image built below.
                $variation_image_id = (int) $variation->get_image_id('edit');
                if (!$variation_image_id && !empty($color_image_map)) {
                    foreach ($variation->get_variation_attributes() as $attribute_name => $value) {
                        if (self::is_color_attribute($attribute_name)) {
                            $color_key = self::normalize_image_match_text($value);
                            $variation_image_id = (int) ($color_image_map[$color_key] ?? 0);
                            break;
                        }
                    }
                }
                return [
                    'id' => $variation->get_id(),
                    'attributes' => $variation->get_variation_attributes(),
                    'price' => $variation->get_price(),
                    'regular_price' => $variation->get_regular_price(),
                    'on_sale' => $variation->is_on_sale(),
                    'stock_status' => $variation->get_stock_status(),
                    'stock_quantity' => $stock_owner->get_stock_quantity(),
                    'backorders_allowed' => $stock_owner->backorders_allowed(),
                    'purchasable' => $variation->is_purchasable(),
                    'image' => $variation_image_id ? wp_get_attachment_url($variation_image_id) : null,
                ];
            }, $product->get_children());
            $result['variations'] = array_values(array_filter($result['variations']));
        }

        return $result;
    }

    /**
     * Match a variable product's color options to its product-gallery images.
     *
     * A large part of the imported catalog stores one mockup per color in the
     * parent gallery, but leaves every WC variation image blank. WooCommerce's
     * normal getter then inherits the same parent thumbnail for every color.
     * Use descriptive filenames first ("navy-blue", "brown", etc.), then pair
     * any remaining colors with the remaining gallery images in catalog order.
     */
    private static function build_color_image_map($product, array $image_ids)
    {
        $color_options = [];
        foreach ($product->get_attributes() as $attribute) {
            if (!self::is_color_attribute($attribute->get_name())) {
                continue;
            }
            $color_options = $attribute->is_taxonomy()
                ? array_map(function ($term_id) use ($attribute) {
                    $term = get_term($term_id, $attribute->get_name());
                    return $term && !is_wp_error($term) ? $term->name : (string) $term_id;
                }, $attribute->get_options())
                : $attribute->get_options();
            break;
        }

        if (empty($color_options) || empty($image_ids)) {
            return [];
        }

        $candidates = [];
        foreach ($image_ids as $attachment_id) {
            $file = get_attached_file($attachment_id);
            $search_text = self::normalize_image_match_text(implode(' ', [
                get_the_title($attachment_id),
                get_post_meta($attachment_id, '_wp_attachment_image_alt', true),
                $file ? pathinfo($file, PATHINFO_FILENAME) : '',
            ]));
            if (strpos($search_text, 'sizechart') !== false || strpos($search_text, 'measurement') !== false) {
                continue;
            }
            $candidates[(int) $attachment_id] = $search_text;
        }

        $map = [];
        $used = [];

        // These legacy products keep their color photography in the parent
        // gallery and use camera-generated filenames for several colors. A
        // blind gallery-order fallback paired Navy with Milk/Cream, Black
        // with Chocolate, and Blue with a red crew-neck photo. Pin the
        // visually verified filename fragments before applying the generic
        // filename and order matching below. This remains product-wide: every
        // size variation for a color receives the same correct image.
        $verified_overrides = self::verified_color_image_overrides($product->get_slug());
        foreach ($verified_overrides as $color => $filename_fragment) {
            $color_key = self::normalize_image_match_text($color);
            $image_key = self::normalize_image_match_text($filename_fragment);
            foreach ($candidates as $attachment_id => $search_text) {
                if (!isset($used[$attachment_id]) && strpos($search_text, $image_key) !== false) {
                    $map[$color_key] = $attachment_id;
                    $used[$attachment_id] = true;
                    break;
                }
            }
        }

        $sortable_options = $color_options;
        usort($sortable_options, function ($a, $b) {
            return strlen(self::normalize_image_match_text($b)) <=> strlen(self::normalize_image_match_text($a));
        });

        foreach ($sortable_options as $option) {
            $color_key = self::normalize_image_match_text($option);
            if (isset($map[$color_key]) || strlen($color_key) < 3) {
                continue;
            }
            foreach ($candidates as $attachment_id => $search_text) {
                if (!isset($used[$attachment_id]) && strpos($search_text, $color_key) !== false) {
                    $map[$color_key] = $attachment_id;
                    $used[$attachment_id] = true;
                    break;
                }
            }
        }

        $remaining_images = array_values(array_filter(array_keys($candidates), function ($attachment_id) use ($used) {
            return !isset($used[$attachment_id]);
        }));
        foreach ($color_options as $option) {
            $color_key = self::normalize_image_match_text($option);
            if (!isset($map[$color_key]) && !empty($remaining_images)) {
                $map[$color_key] = array_shift($remaining_images);
            }
        }

        return $map;
    }

    private static function verified_color_image_overrides($product_slug)
    {
        $overrides = [
            'unisex-stay-connected-t-shirt' => [
                'black' => 'WhatsAppImage2023-01-19at1.55.11AM',
                'chocolate' => 'WhatsAppImage2023-01-19at1.56.56AM',
                'cream' => 'MilkC767',
                'navy' => 'WhatsAppImage2023-01-19at1.52.39AM',
                'ocean-blue' => 'BlueC767',
                'white' => 'WhiteC767',
            ],
            'unisex-sissarou-t-shirt' => [
                'black' => 'WhatsAppImage2023-01-19at2.11.09AM',
                'chocolate' => 'WhatsAppImage2023-01-19at2.06.55AM_1',
                'cream' => 'Milkparrot',
                'green' => 'Greenparrot',
                'navy' => 'WhatsAppImage2023-01-19at2.08.59AM',
                'white' => 'Whiteparrot',
            ],
            'cotton-crew-neck-t-shirts' => [
                'blue' => '174A0524-Edit-scaled-1-scaled',
                'red' => '174A9975-Edit-scaled-1-scaled',
            ],
        ];

        return $overrides[$product_slug] ?? [];
    }

    private static function is_color_attribute($name)
    {
        $name = strtolower((string) $name);
        return strpos($name, 'color') !== false || strpos($name, 'colour') !== false;
    }

    private static function normalize_image_match_text($value)
    {
        return preg_replace('/[^a-z0-9]+/', '', strtolower(remove_accents((string) $value)));
    }

    public static function list_categories()
    {
        $terms = get_terms(['taxonomy' => 'product_cat', 'hide_empty' => false]);
        if (is_wp_error($terms)) {
            return rest_ensure_response([]);
        }

        return rest_ensure_response(array_map(function ($term) {
            $icon = get_term_meta($term->term_id, 'c767_icon', true);
            return [
                'slug' => $term->slug,
                'name' => $term->name,
                'acf' => ['icon' => $icon ?: 'ri-price-tag-3-line'],
            ];
        }, $terms));
    }

    // ---------- Headless checkout ----------

    /**
     * Build one shipment-ready WooCommerce order for every Shop payment path.
     * Stripe, PayPal, and the hosted WooCommerce fallback all call this method
     * so customer addresses, shipping lines, taxes, and totals stay identical.
     */
    public static function build_pending_order(array $items, $email, array $shipping)
    {
        if (empty($items)) {
            return new WP_Error('c767_empty_cart', 'Cart is empty.', ['status' => 400]);
        }

        $email = sanitize_email((string) $email);
        if (!$email || !is_email($email)) {
            return new WP_Error('c767_invalid_email', 'A valid email address is required.', ['status' => 400]);
        }

        $address = self::sanitize_shipping_address($shipping);
        if (is_wp_error($address)) {
            return $address;
        }

        $order = wc_create_order();
        if (is_wp_error($order)) {
            return new WP_Error('c767_order_failed', $order->get_error_message(), ['status' => 400]);
        }

        foreach ($items as $item) {
            $slug = sanitize_title((string) ($item['slug'] ?? ''));
            $qty = max(1, (int) ($item['qty'] ?? 1));
            $variation_id = (int) ($item['variationId'] ?? 0);

            if ($variation_id) {
                $variation = wc_get_product($variation_id);
                if ($variation && $variation->is_type('variation') && $variation->is_purchasable()) {
                    $stock_check = self::validate_requested_stock($variation, $qty);
                    if (is_wp_error($stock_check)) {
                        $order->delete(true);
                        return $stock_check;
                    }
                    $order->add_product($variation, $qty);
                    continue;
                }
            }

            $product_id = self::product_id_from_slug($slug);
            $product = $product_id ? wc_get_product($product_id) : null;
            if ($product && $product->is_purchasable()) {
                $stock_check = self::validate_requested_stock($product, $qty);
                if (is_wp_error($stock_check)) {
                    $order->delete(true);
                    return $stock_check;
                }
                $order->add_product($product, $qty);
            }
        }

        if (count($order->get_items()) === 0) {
            $order->delete(true);
            return new WP_Error('c767_no_valid_items', 'None of the cart items matched a real product.', ['status' => 400]);
        }

        $billing = $address;
        $billing['email'] = $email;
        $order->set_address($billing, 'billing');
        $order->set_address($address, 'shipping');
        $order->calculate_totals(false);

        $shipping_rate = self::calculate_shipping_rate($order, $address);
        if (is_wp_error($shipping_rate)) {
            $order->delete(true);
            return $shipping_rate;
        }

        $shipping_item = new WC_Order_Item_Shipping();
        $shipping_item->set_method_title($shipping_rate->get_label());
        $shipping_item->set_method_id($shipping_rate->get_method_id());
        $shipping_item->set_instance_id($shipping_rate->get_instance_id());
        $shipping_item->set_total((float) $shipping_rate->get_cost());
        $shipping_item->set_taxes($shipping_rate->get_taxes());
        $order->add_item($shipping_item);

        $order->calculate_totals();
        $order->set_status('pending');
        $order->save();

        return $order;
    }

    /**
     * Recheck stock on the server immediately before creating an order.
     * The storefront warning is helpful feedback, but checkout must remain
     * authoritative when inventory changes in another session or a request
     * is submitted without using the storefront UI.
     */
    private static function validate_requested_stock($product, $quantity)
    {
        if (!$product->is_in_stock()) {
            return new WP_Error(
                'c767_out_of_stock',
                sprintf('%s is currently out of stock.', $product->get_name()),
                ['status' => 409]
            );
        }

        if (!$product->has_enough_stock($quantity)) {
            $available = $product->get_stock_quantity();
            $message = is_numeric($available)
                ? sprintf('Only %d of %s are currently available.', max(0, (int) $available), $product->get_name())
                : sprintf('%s is not available in the requested quantity.', $product->get_name());

            return new WP_Error('c767_insufficient_stock', $message, ['status' => 409]);
        }

        return true;
    }

    private static function sanitize_shipping_address(array $shipping)
    {
        $address = [
            'first_name' => sanitize_text_field((string) ($shipping['firstName'] ?? '')),
            'last_name' => sanitize_text_field((string) ($shipping['lastName'] ?? '')),
            'company' => sanitize_text_field((string) ($shipping['company'] ?? '')),
            'address_1' => sanitize_text_field((string) ($shipping['address1'] ?? '')),
            'address_2' => sanitize_text_field((string) ($shipping['address2'] ?? '')),
            'city' => sanitize_text_field((string) ($shipping['city'] ?? '')),
            'state' => strtoupper(sanitize_text_field((string) ($shipping['state'] ?? ''))),
            'postcode' => sanitize_text_field((string) ($shipping['postcode'] ?? '')),
            'country' => strtoupper(sanitize_text_field((string) ($shipping['country'] ?? 'US'))),
            'phone' => wc_sanitize_phone_number((string) ($shipping['phone'] ?? '')),
        ];

        foreach (['first_name', 'last_name', 'address_1', 'city', 'postcode', 'country'] as $field) {
            if ($address[$field] === '') {
                return new WP_Error('c767_incomplete_shipping_address', 'Complete every required shipping-address field.', ['status' => 400]);
            }
        }

        $countries = WC()->countries->get_countries();
        if (!isset($countries[$address['country']])) {
            return new WP_Error('c767_invalid_shipping_country', 'Choose a valid shipping country.', ['status' => 400]);
        }

        if ($address['country'] === 'US') {
            $states = WC()->countries->get_states('US');
            if (!$address['state'] || !isset($states[$address['state']])) {
                return new WP_Error('c767_invalid_shipping_state', 'Choose a valid U.S. state.', ['status' => 400]);
            }
        }

        return $address;
    }

    private static function calculate_shipping_rate(WC_Order $order, array $address)
    {
        $contents = [];
        $contents_cost = 0.0;

        foreach ($order->get_items('line_item') as $item_id => $item) {
            $product = $item->get_product();
            if (!$product || !$product->needs_shipping()) {
                continue;
            }
            $contents[$item_id] = [
                'key' => (string) $item_id,
                'product_id' => $item->get_product_id(),
                'variation_id' => $item->get_variation_id(),
                'variation' => [],
                'quantity' => $item->get_quantity(),
                'data' => $product,
                'line_total' => (float) $item->get_total(),
                'line_tax' => 0,
                'line_subtotal' => (float) $item->get_subtotal(),
                'line_subtotal_tax' => 0,
            ];
            $contents_cost += (float) $item->get_total();
        }

        if (empty($contents)) {
            return new WP_Error('c767_no_shippable_items', 'This order does not contain shippable products.', ['status' => 400]);
        }

        $package = [
            'contents' => $contents,
            'contents_cost' => $contents_cost,
            'applied_coupons' => [],
            'user' => ['ID' => get_current_user_id()],
            'destination' => [
                'country' => $address['country'],
                'state' => $address['state'],
                'postcode' => $address['postcode'],
                'city' => $address['city'],
                'address' => $address['address_1'],
                'address_1' => $address['address_1'],
                'address_2' => $address['address_2'],
            ],
        ];

        $zone = WC_Shipping_Zones::get_zone_matching_package($package);
        $rates = [];
        foreach ($zone->get_shipping_methods(true) as $method) {
            $method->rates = [];
            $method->calculate_shipping($package);
            foreach ($method->rates as $rate) {
                $rates[] = $rate;
            }
        }

        if (empty($rates)) {
            return new WP_Error('c767_no_shipping_method', 'No shipping method is available for this address.', ['status' => 400]);
        }

        usort($rates, function ($a, $b) {
            return (float) $a->get_cost() <=> (float) $b->get_cost();
        });

        return $rates[0];
    }

    public static function checkout(WP_REST_Request $request)
    {
        $items = (array) $request->get_param('items');
        $shipping = (array) $request->get_param('shipping');
        $order = self::build_pending_order($items, $request->get_param('email'), $shipping);
        if (is_wp_error($order)) {
            return $order;
        }

        do_action('c767_checkout_order_created', $order);

        return rest_ensure_response([
            'orderId' => $order->get_id(),
            'checkoutUrl' => $order->get_checkout_payment_url(),
            'total' => $order->get_total(),
        ]);
    }

    private static function product_id_from_slug($slug)
    {
        if (!$slug) {
            return 0;
        }
        $post = get_page_by_path($slug, OBJECT, 'product');
        return $post ? $post->ID : 0;
    }
}
