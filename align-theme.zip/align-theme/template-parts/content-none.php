<?php defined( 'ABSPATH' ) || exit; ?>
<div class="empty-state wrap" style="margin-block:60px">
    <svg class="icon" viewBox="0 0 24 24" style="width:48px;height:48px;margin-bottom:20px"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
    <h2><?php esc_html_e( 'Nothing found', 'align-theme' ); ?></h2>
    <p><?php esc_html_e( 'Try a different search or browse our shop.', 'align-theme' ); ?></p>
    <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>" class="btn"><?php esc_html_e( 'Browse Products', 'align-theme' ); ?></a>
</div>
