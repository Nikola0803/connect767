<?php
defined( 'ABSPATH' ) || exit;
get_header();

$search_query = get_search_query();
$post_type    = isset( $_GET['post_type'] ) ? sanitize_text_field( $_GET['post_type'] ) : '';
$is_products  = ( $post_type === 'product' ) || ( have_posts() && get_post_type( get_the_ID() ) === 'product' );
?>

<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Search results', 'align-theme' ); ?></div>
        <h1>
            <?php if ( $search_query ) : ?>
            <?php printf( esc_html__( 'Results for "%s"', 'align-theme' ), '<em>' . esc_html( $search_query ) . '</em>' ); ?>
            <?php else : ?>
            <?php esc_html_e( 'Search', 'align-theme' ); ?>
            <?php endif; ?>
        </h1>
    </div>
</div>

<div class="wrap" style="padding-top:40px;padding-bottom:60px">

    <!-- Search form -->
    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="catalog-search-label" style="max-width:580px;margin-bottom:36px">
        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
        <input
            type="search"
            name="s"
            value="<?php echo esc_attr( $search_query ); ?>"
            placeholder="<?php esc_attr_e( 'Search compounds, categories…', 'align-theme' ); ?>"
            aria-label="<?php esc_attr_e( 'Search', 'align-theme' ); ?>"
            autofocus
        >
        <input type="hidden" name="post_type" value="product">
    </form>

    <?php if ( have_posts() ) : ?>

        <?php
        global $wp_query;
        $total = $wp_query->found_posts;
        ?>
        <p class="result-count" style="margin-bottom:28px">
            <?php printf( esc_html( _n( '%s result', '%s results', $total, 'align-theme' ) ), number_format_i18n( $total ) ); ?>
        </p>

        <div class="product-grid">
            <?php while ( have_posts() ) : the_post(); ?>
                <?php
                if ( get_post_type() === 'product' ) {
                    global $product;
                    if ( ! $product ) $product = wc_get_product( get_the_ID() );
                    if ( $product ) {
                        wc_get_template_part( 'content', 'product' );
                    }
                } else {
                    // Non-product post result
                    ?>
                    <article class="search-result">
                        <div class="eyebrow"><?php echo esc_html( get_post_type_object( get_post_type() )->labels->singular_name ); ?></div>
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p><?php echo wp_trim_words( get_the_excerpt(), 20 ); ?></p>
                        <a href="<?php the_permalink(); ?>" class="text-link"><?php esc_html_e( 'Read more →', 'align-theme' ); ?></a>
                    </article>
                    <?php
                }
                ?>
            <?php endwhile; ?>
        </div>

        <?php the_posts_pagination( [
            'prev_text' => '← ' . __( 'Previous', 'align-theme' ),
            'next_text' => __( 'Next', 'align-theme' ) . ' →',
        ] ); ?>

    <?php else : ?>

        <div class="empty-state">
            <svg class="icon" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
            <h2><?php esc_html_e( 'No results found.', 'align-theme' ); ?></h2>
            <p><?php printf( esc_html__( 'No products matched "%s". Try a different search or browse the catalogue.', 'align-theme' ), esc_html( $search_query ) ); ?></p>
            <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>" class="btn">
                <?php esc_html_e( 'Browse all products', 'align-theme' ); ?>
            </a>
        </div>

    <?php endif; ?>

</div>

<?php get_footer(); ?>
