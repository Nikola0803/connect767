</div><!-- #primary -->

<footer class="site-footer">
    <div class="wrap">
        <div class="footer-masthead">
            <span>ALIGN</span>
            <div>BIOSCIENCES<br>PRECISION IN EVERY DETAIL.</div>
        </div>

        <div class="footer-grid">
            <div class="footer-brand">
                <p><?php esc_html_e( 'A precision biosciences brand developing rigorously tested research peptides with clarity and discipline.', 'align-theme' ); ?></p>
                <a href="mailto:info@alignpeptides.com">info@alignpeptides.com</a>
                <p><?php esc_html_e( 'Toronto, Canada', 'align-theme' ); ?></p>
            </div>

            <div>
                <h3><?php esc_html_e( 'Shop', 'align-theme' ); ?></h3>
                <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'All Products', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/product-category/research-pens/' ) ); ?>"><?php esc_html_e( 'Research Pens', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/product-category/glps/' ) ); ?>"><?php esc_html_e( 'GLPs', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/product-category/research-bundles/' ) ); ?>"><?php esc_html_e( 'Stacks & Bundles', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/wholesale/' ) ); ?>"><?php esc_html_e( 'Wholesale', 'align-theme' ); ?></a>
            </div>

            <div>
                <h3><?php esc_html_e( 'Support', 'align-theme' ); ?></h3>
                <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>"><?php esc_html_e( 'Contact', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/track-order/' ) ); ?>"><?php esc_html_e( 'Track Order', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/shipping-policy/' ) ); ?>"><?php esc_html_e( 'Shipping', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/refund-policy/' ) ); ?>"><?php esc_html_e( 'Returns', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/faqs/' ) ); ?>"><?php esc_html_e( 'FAQs', 'align-theme' ); ?></a>
            </div>

            <div>
                <h3><?php esc_html_e( 'Company', 'align-theme' ); ?></h3>
                <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><?php esc_html_e( 'About Align', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>"><?php esc_html_e( 'Research Standards', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>"><?php esc_html_e( 'Resources', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/partnership/' ) ); ?>"><?php esc_html_e( 'Partnership', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab Results', 'align-theme' ); ?></a>
            </div>

            <div class="footer-news">
                <h3><?php esc_html_e( 'Newsletter', 'align-theme' ); ?></h3>
                <p><?php esc_html_e( 'Subscribe to get regular updates.', 'align-theme' ); ?></p>
                <?php if ( shortcode_exists( 'omnisend_form' ) ) : ?>
                    <?php echo do_shortcode( '[omnisend_form]' ); ?>
                <?php else : ?>
                    <form data-form="newsletter">
                        <div class="email-row">
                            <input type="email" required aria-label="<?php esc_attr_e( 'Email address for newsletter', 'align-theme' ); ?>" placeholder="<?php esc_attr_e( 'Your email address', 'align-theme' ); ?>">
                            <button type="submit" aria-label="<?php esc_attr_e( 'Subscribe', 'align-theme' ); ?>">
                                <svg class="icon" viewBox="0 0 24 24"><path d="M4 12h16m-6-6 6 6-6 6"/></svg>
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
                <p style="margin-top:18px">WELCOME10 · <?php esc_html_e( '10% off your first order', 'align-theme' ); ?></p>
            </div>
        </div>

        <div class="footer-bottom">
            <span>&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php esc_html_e( 'Align Peptides. All rights reserved.', 'align-theme' ); ?></span>
            <span>
                <a href="<?php echo esc_url( home_url( '/terms-conditions/' ) ); ?>"><?php esc_html_e( 'Terms & Conditions', 'align-theme' ); ?></a>
                &nbsp;/&nbsp;
                <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php esc_html_e( 'Privacy Policy', 'align-theme' ); ?></a>
                &nbsp;/&nbsp;
                <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>"><?php esc_html_e( 'Research Use Only', 'align-theme' ); ?></a>
            </span>
        </div>
        <p class="footer-legal"><?php esc_html_e( 'All products are supplied strictly for qualified in vitro laboratory research and are not for human or veterinary use. They are not drugs, foods, supplements, or cosmetics, and are not marketed as supplements, medications, treatments, or performance-enhancing products. No claims are made regarding clinical outcomes, safety, or efficacy. Not evaluated by Health Canada or the FDA.', 'align-theme' ); ?></p>
    </div>
</footer>

<!-- Back-to-top -->
<button type="button" id="back-to-top" class="back-to-top" aria-label="<?php esc_attr_e( 'Back to top', 'align-theme' ); ?>" hidden>
    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>
</button>

<!-- Toast notification -->
<div id="toast" class="toast" aria-live="polite" aria-atomic="true" role="status"></div>

<!-- Email popup (S40 replacement) — shown once per session after 15 s -->
<div class="popup-overlay" id="popup-overlay" hidden aria-modal="true" role="dialog" aria-labelledby="popup-title">
    <div class="popup-card">
        <button type="button" class="icon-btn popup-close" id="popup-close" aria-label="<?php esc_attr_e( 'Close', 'align-theme' ); ?>">
            <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
        <div class="eyebrow"><?php esc_html_e( 'EXCLUSIVE RESEARCH OFFER', 'align-theme' ); ?></div>
        <h2 id="popup-title"><?php esc_html_e( '10% OFF your first order', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Third-party tested research compounds, with a COA on every batch.', 'align-theme' ); ?></p>
        <form id="popup-form" novalidate>
            <?php wp_nonce_field( 'align_popup_capture', 'popup_nonce' ); ?>
            <label class="field full" style="margin-bottom:14px">
                <span class="sr-only"><?php esc_html_e( 'Email address', 'align-theme' ); ?></span>
                <input type="email" id="popup-email" name="email" required placeholder="<?php esc_attr_e( 'Email address', 'align-theme' ); ?>" autocomplete="email">
            </label>
            <button type="submit" class="btn" style="width:100%"><?php esc_html_e( 'Get my 10% off code', 'align-theme' ); ?></button>
        </form>
        <p id="popup-msg" role="status" style="font-size:13px;margin-top:14px;min-height:18px"></p>
        <button type="button" id="popup-dismiss" class="popup-dismiss text-link" style="margin-top:18px;display:block;width:100%;text-align:center"><?php esc_html_e( 'No thanks, I\'ll pay full price.', 'align-theme' ); ?></button>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
