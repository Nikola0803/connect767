<?php
defined( 'ABSPATH' ) || exit;
get_header();

while ( have_posts() ) :
    the_post();
    ?>
    <div class="wrap">
        <div class="page-hero tint">
            <?php align_breadcrumbs(); ?>
            <h1><?php the_title(); ?></h1>
        </div>
        <div class="content-copy section" style="max-width:860px">
            <?php the_content(); ?>
        </div>
    </div>
    <?php
endwhile;

get_footer();
