<?php
defined( 'ABSPATH' ) || exit;
get_header();

// Icon helper — exact SVG paths from design app.js
function align_icon( $name ) {
    $icons = [
        'check'  => '<path d="m7 12 3 3 7-7"/><circle cx="12" cy="12" r="9"/>',
        'file'   => '<path d="M5 3h9l5 5v13H5V3Zm9 0v6h5M8 13h8M8 17h6"/>',
        'truck'  => '<path d="M2 6h12v12H2V6Zm12 5h4l4 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
        'shield' => '<path d="m12 2 8 3v7c0 5-8 10-8 10S4 17 4 12V5l8-3Z"/><path d="m8 12 3 3 5-6"/>',
        'lab'    => '<path d="M8 3h8M9 3v7L3 20h18l-6-10V3M7 15h10"/>',
        'mail'   => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 6 9 7 9-7"/>',
        'arrow'  => '<path d="M4 12h16m-6-6 6 6-6 6"/>',
    ];
    $d = $icons[ $name ] ?? $icons['check'];
    return '<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">' . $d . '</svg>';
}

// Spotlight product (GHK-Cu)
$sp_q = new WP_Query( [ 'post_type' => 'product', 'name' => 'ghk-cu', 'posts_per_page' => 1 ] );
$spotlight = $sp_q->have_posts() ? wc_get_product( $sp_q->posts[0]->ID ) : null;
if ( ! $spotlight ) {
    $fallback = wc_get_products( [ 'limit' => 1, 'orderby' => 'popularity', 'status' => 'publish' ] );
    $spotlight = $fallback[0] ?? null;
}

// Hero products: ghk-cu, bpc-157, mots-c
$hero_products = [];
foreach ( [ 'ghk-cu', 'bpc-157', 'mots-c' ] as $hslug ) {
    $hq = new WP_Query( [ 'post_type' => 'product', 'name' => $hslug, 'posts_per_page' => 1 ] );
    if ( $hq->have_posts() ) $hero_products[] = wc_get_product( $hq->posts[0]->ID );
}
if ( count( $hero_products ) < 3 ) {
    foreach ( wc_get_products( [ 'limit' => 6, 'orderby' => 'popularity', 'status' => 'publish' ] ) as $ep ) {
        if ( count( $hero_products ) >= 3 ) break;
        $dupe = false;
        foreach ( $hero_products as $hp ) { if ( $hp->get_id() === $ep->get_id() ) { $dupe = true; break; } }
        if ( ! $dupe ) $hero_products[] = $ep;
    }
}

// Edit products: mots-c, bpc-tb500, bpc-157, tesamorelin
$edit_products = [];
foreach ( [ 'mots-c', 'bpc-tb500', 'bpc-157', 'tesamorelin' ] as $eslug ) {
    $eq = new WP_Query( [ 'post_type' => 'product', 'name' => $eslug, 'posts_per_page' => 1 ] );
    if ( $eq->have_posts() ) $edit_products[] = wc_get_product( $eq->posts[0]->ID );
}
if ( count( $edit_products ) < 4 ) {
    $sp_id = $spotlight ? $spotlight->get_id() : 0;
    foreach ( wc_get_products( [ 'limit' => 12, 'orderby' => 'popularity', 'status' => 'publish' ] ) as $mp ) {
        if ( count( $edit_products ) >= 4 ) break;
        if ( $mp->get_id() === $sp_id ) continue;
        $dupe = false;
        foreach ( $edit_products as $dp ) { if ( $dp->get_id() === $mp->get_id() ) { $dupe = true; break; } }
        if ( ! $dupe ) $edit_products[] = $mp;
    }
}

// BPC-157 for proof tile image
$bpc_q = new WP_Query( [ 'post_type' => 'product', 'name' => 'bpc-157', 'posts_per_page' => 1 ] );
$bpc = $bpc_q->have_posts() ? wc_get_product( $bpc_q->posts[0]->ID ) : null;
$bpc_img = $bpc ? ( wp_get_attachment_image_url( $bpc->get_image_id(), 'align-product' ) ?: '' ) : '';

// Category pills — ordered per design, with specific product slug for pill image
$remix_cats = [
    [ 'all-peptides',      'Shop Peptides',    'Research compounds',    'bpc-157' ],
    [ 'glps',              'GLPs',             'Explore the collection','mots-c' ],
    [ 'research-supplies', 'Supplies',         'Laboratory essentials', 'ghk-cu' ],
    [ 'research-pens',     'Research Pens',    'Explore formats',       'nad' ],
    [ 'research-bundles',  'Stacks & Bundles', 'Browse the collection', 'bpc-tb500' ],
];

// COA compound records count (matches design's D.coas.length = 25)
$coa_count = 25;
?>

<!-- ===== HERO ===== -->
<section class="hero wrap">
    <div class="hero-copy">
        <a class="proof-badge" href="<?php echo esc_url( home_url( '/coa/' ) ); ?>">
            <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 3h9l5 5v13H5V3Zm9 0v6h5M8 13h8M8 17h6"/></svg>
            <span>
                <small><?php esc_html_e( 'Documentation first', 'align-theme' ); ?></small>
                <b><?php esc_html_e( 'Independent laboratory testing · View COAs ↗', 'align-theme' ); ?></b>
            </span>
        </a>
        <h1><?php esc_html_e( 'Precision.', 'align-theme' ); ?><br><?php esc_html_e( 'Without', 'align-theme' ); ?><br><span><?php esc_html_e( 'compromise.', 'align-theme' ); ?></span></h1>
        <p><?php esc_html_e( 'Independent laboratory testing on every compound. Certificate of Analysis available on every order.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="btn light"><?php esc_html_e( 'Shop All Compounds', 'align-theme' ); ?></a>
    </div>

    <div class="strong-hero-art">
        <span class="hero-art-word" aria-hidden="true">ALIGN</span>
        <?php foreach ( $hero_products as $i => $hp ) :
            $hp_img = wp_get_attachment_image_url( $hp->get_image_id(), 'align-product' ) ?: wc_placeholder_img_src( 'align-product' );
        ?>
        <a href="<?php echo esc_url( $hp->get_permalink() ); ?>" class="hero-product hp-<?php echo esc_attr( $i ); ?>">
            <img src="<?php echo esc_url( $hp_img ); ?>" alt="<?php echo esc_attr( $hp->get_name() ); ?> — original Align vial" loading="<?php echo $i === 0 ? 'eager' : 'lazy'; ?>">
        </a>
        <?php endforeach; ?>
        <span class="hero-art-caption">ORIGINAL ALIGN COMPOUNDS / RESEARCH USE ONLY</span>
    </div>
</section>

<!-- ===== TICKER ===== -->
<section class="ticker" aria-label="<?php esc_attr_e( 'Align research standards', 'align-theme' ); ?>">
    <div class="ticker-track" id="ticker-track">
        <?php
        $ticker_items = [
            [ 'check',  __( 'Third-party lab tested',   'align-theme' ) ],
            [ 'file',   __( 'COA on every order',        'align-theme' ) ],
            [ 'truck',  __( 'Canadian shipping',         'align-theme' ) ],
            [ 'shield', __( 'Discreet packaging',        'align-theme' ) ],
            [ 'lab',    __( 'Research use only',         'align-theme' ) ],
            [ 'mail',   __( 'Research-focused support',  'align-theme' ) ],
        ];
        foreach ( [ 0, 1 ] as $pass ) :
            foreach ( $ticker_items as $titem ) : ?>
            <div class="ticker-item" <?php echo $pass ? 'aria-hidden="true"' : ''; ?>>
                <span class="ticker-icon"><?php echo align_icon( $titem[0] ); ?></span>
                <?php echo esc_html( $titem[1] ); ?>
            </div>
        <?php endforeach; endforeach; ?>
    </div>
</section>
<div class="wrap ticker-controls">
    <button type="button" id="ticker-pause" aria-label="<?php esc_attr_e( 'Pause motion', 'align-theme' ); ?>" aria-pressed="false"><?php esc_html_e( 'Pause motion', 'align-theme' ); ?></button>
</div>

<!-- ===== COLLECTION REMIX ===== -->
<section class="collection-remix wrap">
    <div class="collection-remix-title">
        <div class="eyebrow"><?php esc_html_e( 'FIND YOUR STARTING POINT', 'align-theme' ); ?></div>
        <h2><?php esc_html_e( 'One standard.', 'align-theme' ); ?><br><?php esc_html_e( 'More ways to research.', 'align-theme' ); ?></h2>
        <a href="<?php echo esc_url( home_url( '/all-categories/' ) ); ?>" class="text-link"><?php esc_html_e( 'Explore every category ↗', 'align-theme' ); ?></a>
    </div>
    <nav class="collection-remix-pills" aria-label="<?php esc_attr_e( 'Featured research categories', 'align-theme' ); ?>">
        <?php foreach ( $remix_cats as $ri => [ $rslug, $rname, $rsub, $rpslug ] ) :
            if ( $rslug === 'all-peptides' ) {
                $rcat_link = get_permalink( wc_get_page_id( 'shop' ) );
            } else {
                $rcat_obj  = get_term_by( 'slug', $rslug, 'product_cat' );
                // Never skip — fallback to shop with cat filter so pill index stays correct
                $rcat_link = $rcat_obj ? get_term_link( $rcat_obj ) : home_url( '/product-category/' . $rslug . '/' );
            }
            $rpq = new WP_Query( [ 'post_type' => 'product', 'name' => $rpslug, 'posts_per_page' => 1 ] );
            $rpimg = '';
            if ( $rpq->have_posts() ) {
                $rpp   = wc_get_product( $rpq->posts[0]->ID );
                $rpimg = wp_get_attachment_image_url( $rpp->get_image_id(), 'align-product' ) ?: '';
            }
        ?>
        <a class="remix-pill remix-pill-<?php echo esc_attr( $ri ); ?>" href="<?php echo esc_url( $rcat_link ); ?>">
            <div>
                <small>0<?php echo esc_html( $ri + 1 ); ?> / COLLECTION</small>
                <strong><?php echo esc_html( $rname ); ?></strong>
                <span><?php echo esc_html( $rsub ); ?></span>
            </div>
            <?php if ( $rpimg ) : ?>
            <img src="<?php echo esc_url( $rpimg ); ?>" alt="" loading="lazy">
            <?php endif; ?>
            <b><?php echo align_icon( 'arrow' ); ?></b>
        </a>
        <?php endforeach; ?>
    </nav>
</section>

<!-- ===== COLLECTION EDIT ===== -->
<section class="section wrap collection-edit">
    <div class="section-head">
        <div>
            <div class="eyebrow"><?php esc_html_e( 'THE ALIGN EDIT', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Explore the collection.', 'align-theme' ); ?></h2>
        </div>
        <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="text-link"><?php esc_html_e( 'View all compounds ↗', 'align-theme' ); ?></a>
    </div>

    <div class="edit-layout">
        <?php if ( $spotlight ) :
            $sp_img = wp_get_attachment_image_url( $spotlight->get_image_id(), 'align-product' ) ?: wc_placeholder_img_src();
        ?>
        <a href="<?php echo esc_url( $spotlight->get_permalink() ); ?>" class="edit-spotlight">
            <div class="spotlight-top">
                <span><?php esc_html_e( 'COMPOUND SPOTLIGHT', 'align-theme' ); ?></span>
                <?php echo align_icon( 'arrow' ); ?>
            </div>
            <h3><?php echo esc_html( $spotlight->get_name() ); ?></h3>
            <p><?php esc_html_e( 'Explore available strengths.', 'align-theme' ); ?><br><?php esc_html_e( 'Review original batch documentation.', 'align-theme' ); ?></p>
            <img src="<?php echo esc_url( $sp_img ); ?>" alt="<?php echo esc_attr( $spotlight->get_name() ); ?> — original Align vial" loading="lazy">
            <div class="spotlight-bottom">
                <span><?php esc_html_e( 'From', 'align-theme' ); ?> <?php echo wp_kses_post( $spotlight->get_price_html() ); ?> CAD</span>
                <strong><?php esc_html_e( 'Explore compound ↗', 'align-theme' ); ?></strong>
            </div>
        </a>
        <?php endif; ?>

        <div class="edit-products">
            <div class="product-grid">
                <?php foreach ( $edit_products as $ep ) :
                    $GLOBALS['product'] = $ep;
                    wc_get_template_part( 'content', 'product' );
                endforeach; ?>
            </div>
        </div>
    </div>

    <div class="edit-footer">
        <span><?php esc_html_e( 'Find your compound. Choose your format. Review the report.', 'align-theme' ); ?></span>
        <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="btn">
            <?php esc_html_e( 'Browse the full catalogue', 'align-theme' ); ?>
            <?php echo align_icon( 'arrow' ); ?>
        </a>
    </div>
</section>

<!-- ===== QUALITY BAND ===== -->
<section class="quality-band">
    <div class="quality-inner wrap">
        <div>
            <div class="eyebrow"><?php esc_html_e( 'Quality assurance', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'The paperwork', 'align-theme' ); ?><br><?php esc_html_e( 'ships with it.', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'Quality is demonstrated through testing, traceability, and Certificates of Analysis, not implied outcomes or marketing language.', 'align-theme' ); ?></p>
            <div class="quality-links">
                <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>" class="btn light"><?php esc_html_e( 'View COA Reports', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>" class="text-link" style="color:rgba(255,255,255,.65)"><?php esc_html_e( 'Our research standards ↗', 'align-theme' ); ?></a>
            </div>
        </div>
        <div class="strong-report">
            <span><?php esc_html_e( 'ALIGN / LAB RESULTS LIBRARY', 'align-theme' ); ?></span>
            <h3><?php esc_html_e( 'Proof.', 'align-theme' ); ?><br><?php esc_html_e( 'At your fingertips.', 'align-theme' ); ?></h3>
            <div>
                <strong><?php echo esc_html( $coa_count ); ?></strong>
                <p><?php esc_html_e( 'compound records', 'align-theme' ); ?><br><?php esc_html_e( 'Original laboratory reports', 'align-theme' ); ?></p>
            </div>
            <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>" class="btn light"><?php esc_html_e( 'Find your report ↗', 'align-theme' ); ?></a>
        </div>
    </div>
</section>

<!-- ===== PROOF GRID ===== -->
<section class="section wrap">
    <div class="proof-title">
        <h2><?php esc_html_e( 'A research-first mindset.', 'align-theme' ); ?><br><span><?php esc_html_e( 'Documented at every step.', 'align-theme' ); ?></span></h2>
    </div>
    <div class="proof-grid">
        <article class="proof-tile main">
            <div class="eyebrow"><?php esc_html_e( 'Documentation over claims', 'align-theme' ); ?></div>
            <h3><?php esc_html_e( 'Quality you can review.', 'align-theme' ); ?></h3>
            <div class="proof-paper">
                <img src="<?php echo esc_url( ALIGN_THEME_URI . '/assets/images/align-logo.svg' ); ?>" alt="Align Biosciences" width="110">
                <strong><?php esc_html_e( 'Certificates of Analysis', 'align-theme' ); ?></strong>
                <div class="paper-row"><span><?php esc_html_e( 'Independent analysis', 'align-theme' ); ?></span><?php echo align_icon( 'check' ); ?></div>
                <div class="paper-row"><span><?php esc_html_e( 'Batch identification', 'align-theme' ); ?></span><?php echo align_icon( 'check' ); ?></div>
                <div class="paper-row"><span><?php esc_html_e( 'Documented results', 'align-theme' ); ?></span><?php echo align_icon( 'check' ); ?></div>
                <p><?php esc_html_e( 'Review the full report for the relevant compound and batch.', 'align-theme' ); ?></p>
            </div>
            <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>" class="text-link"><?php esc_html_e( 'Explore the lab results →', 'align-theme' ); ?></a>
        </article>
        <article class="proof-tile dark">
            <div class="eyebrow"><?php esc_html_e( 'Disciplined standards', 'align-theme' ); ?></div>
            <h3><?php esc_html_e( 'Research comes first.', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Clarity, consistency, and responsible handling.', 'align-theme' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>" class="text-link"><?php esc_html_e( 'Our approach →', 'align-theme' ); ?></a>
        </article>
        <article class="proof-tile">
            <div class="eyebrow"><?php esc_html_e( 'Next business day dispatch', 'align-theme' ); ?></div>
            <h3><?php esc_html_e( 'Shipped across Canada.', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Full tracking. Free shipping on orders over $400.', 'align-theme' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/shipping-policy/' ) ); ?>" class="text-link"><?php esc_html_e( 'Shipping information →', 'align-theme' ); ?></a>
            <?php if ( $bpc_img ) : ?>
            <img class="tile-image" src="<?php echo esc_url( $bpc_img ); ?>" alt="" loading="lazy">
            <?php endif; ?>
        </article>
    </div>
    <div class="proof-bottom">
        <div class="eyebrow" style="color:#bacfc0"><?php esc_html_e( 'Precision biosciences', 'align-theme' ); ?></div>
        <h3><?php esc_html_e( 'Defined standards.', 'align-theme' ); ?><br><?php esc_html_e( 'Careful execution.', 'align-theme' ); ?></h3>
        <p><?php esc_html_e( 'Consistency, verification, and documentation at the centre of every research product.', 'align-theme' ); ?></p>
    </div>
</section>

<!-- ===== ABOUT SPLIT ===== -->
<section class="section wrap split-section">
    <div class="strong-about-art">
        <?php if ( $bpc_img ) : ?>
        <img src="<?php echo esc_url( $bpc_img ); ?>" alt="<?php esc_attr_e( 'Original Align BPC-157 vial', 'align-theme' ); ?>" loading="lazy">
        <?php else : ?>
        <img src="<?php echo esc_url( ALIGN_THEME_URI . '/assets/images/align-forest-hero-v2.png' ); ?>" alt="" loading="lazy">
        <?php endif; ?>
        <span><?php esc_html_e( 'ALIGN', 'align-theme' ); ?><br><?php esc_html_e( 'BIOSCIENCES', 'align-theme' ); ?></span>
    </div>
    <div>
        <div class="eyebrow"><?php esc_html_e( 'About Align Biosciences', 'align-theme' ); ?></div>
        <h2><?php esc_html_e( 'Precision Peptide', 'align-theme' ); ?><br><?php esc_html_e( 'Research.', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'ALIGN BIOSCIENCES is a precision biosciences research brand focused on developing and supplying rigorously tested peptides.', 'align-theme' ); ?></p>
        <p><?php esc_html_e( 'The company was built to bring discipline, structure, and credibility to a peptide landscape that has grown faster than its standards.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>" class="btn"><?php esc_html_e( 'Read More About Us', 'align-theme' ); ?></a>
    </div>
</section>

<!-- ===== WHY ALIGN ===== -->
<section class="section why-section">
    <div class="wrap">
        <h2 class="center"><?php esc_html_e( 'Why Choose Us?', 'align-theme' ); ?></h2>
        <div class="why-grid">
            <?php
            $why_items = [
                [ 'truck', __( 'Fast Canadian Shipping',   'align-theme' ), __( 'Ships next business day with full tracking across Canada.', 'align-theme' ) ],
                [ 'file',  __( 'COA on Every Order',       'align-theme' ), __( 'Certificate of Analysis available for every product and every batch.', 'align-theme' ) ],
                [ 'lab',   __( 'Independent Lab Testing',  'align-theme' ), __( 'Compound analysis and batch documentation available for review.', 'align-theme' ) ],
                [ 'mail',  __( 'Research-Focused Support', 'align-theme' ), __( 'Questions about availability, order status, or batch documentation.', 'align-theme' ) ],
            ];
            foreach ( $why_items as [ $wi, $wh, $wpara ] ) : ?>
            <article>
                <?php echo align_icon( $wi ); ?>
                <h3><?php echo esc_html( $wh ); ?></h3>
                <p><?php echo esc_html( $wpara ); ?></p>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===== FAQ ===== -->
<section class="section wrap faq-layout">
    <div>
        <div class="eyebrow"><?php esc_html_e( 'Frequently asked questions', 'align-theme' ); ?></div>
        <h2><?php esc_html_e( 'Want to learn more?', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Clear answers, before you order.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/faqs/' ) ); ?>" class="text-link" style="display:inline-block;margin-top:20px"><?php esc_html_e( 'View all FAQs →', 'align-theme' ); ?></a>
    </div>
    <div class="faq-list">
        <?php
        $faqs = [
            [ __( 'What is Align Biosciences?', 'align-theme' ),                 __( 'Align Biosciences is a Canadian research compound supplier focused on documentation, consistency, and third-party verified quality. Every product is independently tested by an accredited Canadian laboratory.', 'align-theme' ) ],
            [ __( 'Are your products intended for human use?', 'align-theme' ),   __( 'No. All products are for in vitro laboratory research use only. They are not for human consumption, medical use, or veterinary use. These products have not been evaluated by Health Canada or the FDA.', 'align-theme' ) ],
            [ __( 'Do you provide Certificates of Analysis?', 'align-theme' ),    __( 'Yes. COAs are available for every product and every batch. Visit our Lab Results page to view current certificates.', 'align-theme' ) ],
            [ __( 'How fast do you ship?', 'align-theme' ),                       __( 'Ships next business day for orders placed Monday to Friday. Full tracking provided on every order. We ship across Canada only.', 'align-theme' ) ],
            [ __( 'How is product quality verified?', 'align-theme' ),            __( 'Each product undergoes structured testing and is supported by batch-specific documentation to confirm specifications and consistency.', 'align-theme' ) ],
            [ __( 'How can I contact your team?', 'align-theme' ),                __( 'Contact us at info@alignpeptides.com with your order number and product name. Messages are reviewed during regular business hours. Please allow one to two business days for a reply.', 'align-theme' ) ],
        ];
        foreach ( $faqs as [ $fq, $fa ] ) : ?>
        <details>
            <summary><?php echo esc_html( $fq ); ?></summary>
            <p class="faq-answer"><?php echo esc_html( $fa ); ?></p>
        </details>
        <?php endforeach; ?>
    </div>
</section>

<!-- ===== WELCOME BAND ===== -->
<section class="welcome-band wrap">
    <div>
        <div class="eyebrow"><?php esc_html_e( 'Your first order with Align', 'align-theme' ); ?></div>
        <h3><?php esc_html_e( 'Welcome to the research.', 'align-theme' ); ?></h3>
        <p><?php esc_html_e( 'Use ', 'align-theme' ); ?><strong>WELCOME10</strong><?php esc_html_e( ' for 10% off your first order. Free shipping over $400.', 'align-theme' ); ?></p>
    </div>
    <button type="button" class="btn" id="copy-welcome10">
        <?php esc_html_e( 'Copy WELCOME10', 'align-theme' ); ?>
        <?php echo align_icon( 'arrow' ); ?>
    </button>
</section>

<?php get_footer(); ?>
