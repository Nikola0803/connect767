<?php
/**
 * Age gate — Disclaimer page
 * Chromeless, full-page, inline JS, non-delayed. NO get_header()/get_footer().
 * Assign this page the slug "disclaimer" in WordPress.
 */
defined( 'ABSPATH' ) || exit;

// WP needs to run its hooks but we output our own chrome
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php esc_html_e( 'Research Access Verification', 'align-theme' ); ?> | <?php bloginfo( 'name' ); ?></title>
<?php wp_head(); ?>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%;font-family:'DM Sans',sans-serif;background:#0b0e0c;color:#fff}
.gate-wrap{min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:40px 24px;position:relative;overflow:hidden;text-align:center}
.gate-bg{position:absolute;inset:0;background:url('<?php echo esc_url( get_template_directory_uri() . '/assets/images/align-forest-hero-v2.png' ); ?>') center/cover no-repeat;opacity:.35}
.gate-content{position:relative;z-index:1;max-width:540px}
.gate-logo{font-size:11px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.5);margin-bottom:32px}
.gate-logo span{color:rgba(255,255,255,.9)}
.gate-eyebrow{font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:#56d59d;margin-bottom:20px}
.gate-h1{font-size:clamp(34px,5vw,52px);font-weight:600;letter-spacing:-.04em;line-height:1.08;margin-bottom:24px}
.gate-copy{font-size:14px;line-height:1.7;color:rgba(255,255,255,.65);margin-bottom:8px}
.gate-copy+.gate-copy{margin-bottom:32px}
.gate-btn{display:inline-block;padding:16px 38px;background:#fff;color:#0b0e0c;font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;text-decoration:none;border-radius:99px;border:none;cursor:pointer;transition:opacity .15s;margin-top:8px}
.gate-btn:hover{opacity:.9}
.gate-strip{margin-top:36px;font-size:10px;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:rgba(255,255,255,.4)}
.gate-strip span{margin:0 12px}
@media(max-width:480px){.gate-h1{font-size:30px}}
</style>
</head>
<body class="gate-body">

<div class="gate-wrap">
    <div class="gate-bg" aria-hidden="true"></div>
    <div class="gate-content">
        <div class="gate-logo"><span>ALIGN</span> / BIOSCIENCES</div>
        <div class="gate-eyebrow">RESEARCH USE ONLY · 19+</div>
        <h1 class="gate-h1"><?php esc_html_e( 'Confirm Your Access', 'align-theme' ); ?></h1>
        <p class="gate-copy"><?php esc_html_e( 'You must be of legal age in your province and a qualified research professional. All products are for in vitro laboratory research only — not for human or animal consumption.', 'align-theme' ); ?></p>
        <p class="gate-copy"><?php esc_html_e( 'By entering you confirm you are 19+ and accessing this site in a qualified research capacity. Products are not intended for personal, therapeutic, or clinical use.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" id="apd-enter" class="gate-btn"><?php esc_html_e( 'I AGREE &amp; ENTER SITE', 'align-theme' ); ?></a>
        <div class="gate-strip">
            <span><?php esc_html_e( 'CANADIAN', 'align-theme' ); ?></span>·
            <span><?php esc_html_e( 'THIRD-PARTY TESTED', 'align-theme' ); ?></span>·
            <span><?php esc_html_e( 'COA AVAILABLE', 'align-theme' ); ?></span>
        </div>
    </div>
</div>

<!-- Inline gate JS — non-delayed, runs immediately -->
<script>
(function(){
  var COOKIE_AGE = 34560000; // 400 days in seconds

  function getCookie(name){
    var m=document.cookie.match('(?:^|;)\\s*'+name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+'=([^;]*)');
    return m?decodeURIComponent(m[1]):null;
  }

  function setCookie(name,val,maxAge){
    document.cookie=name+'='+encodeURIComponent(val)+';path=/;max-age='+maxAge+';samesite=lax;secure';
  }

  // Capture UTM / fbclid / gclid from query string into cookies (S14 compat)
  var q=new URLSearchParams(location.search);
  ['utm_source','utm_medium','utm_campaign','utm_content','utm_term','fbclid','gclid','msclkid'].forEach(function(k){
    if(q.get(k)) setCookie('align_'+k,q.get(k),COOKIE_AGE);
  });

  // Resolve intended destination (S71 compat)
  var dest=getCookie('align_intended_dest');
  var enter=document.getElementById('apd-enter');
  if(enter){
    var target=(dest||<?php echo json_encode( esc_url( home_url( '/shop/' ) ) ); ?>);
    // Append current query string (UTM/fbclid) to destination
    var qs=location.search;
    if(qs && target.indexOf('?')===-1) target+=qs;
    enter.href=target;

    enter.addEventListener('click',function(){
      setCookie('align_age_verified','1',COOKIE_AGE);
      // S153 compat: clear intended dest
      document.cookie='align_intended_dest=;path=/;max-age=0';
    });
  }
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
