/* Align Precision — product.js (single product page) */
(function () {
  'use strict';

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  // ── Gallery thumbnails ───────────────────────────────────────
  const mainImg  = $('#main-product-img');
  const thumbBtns = $$('.thumb-btn');

  thumbBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      if (!mainImg) return;
      mainImg.src = btn.dataset.img;
      thumbBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // ── Quantity control ─────────────────────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('[data-qty]');
    if (!btn) return;
    const input = btn.closest('.qty-control')?.querySelector('input[type="number"], .qty-display');
    if (!input) return;

    const dir     = btn.dataset.qty;
    const current = parseInt(input.value || input.textContent || 1);
    const min     = parseInt(input.min || 1);
    const max     = parseInt(input.max || 9999);

    let next = dir === '+' ? current + 1 : current - 1;
    next = Math.max(min, Math.min(max, next));

    if (input.tagName === 'INPUT') {
      input.value = next;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      input.textContent = next;
    }
  });

  // ── Pack / variation selector ────────────────────────────────
  $$('.pack-option').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.option-values');
      if (!group) return;
      $$('.pack-option', group).forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  $$('.chip[data-attribute]').forEach(chip => {
    chip.addEventListener('click', () => {
      const group = chip.closest('.option-values');
      if (!group) return;
      $$('.chip', group).forEach(c => c.classList.remove('active'));
      chip.classList.add('active');

      // Sync to WooCommerce variation select if present
      const attr  = chip.dataset.attribute;
      const val   = chip.dataset.value;
      const sel   = $(`select[name="${attr}"]`);
      if (sel) {
        sel.value = val;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  });

  // ── D2 Pack/Strength pills — sync to WC variation selects ────
  $$('.pdp-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const attrName = pill.dataset.attr;
      const val      = pill.dataset.value;
      // Deactivate siblings in same row
      const row = pill.closest('.pdp-pills');
      if (row) row.querySelectorAll('.pdp-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      // Find WC select for this attribute and update
      const selectors = [
        `select[name="attribute_${attrName}"]`,
        `select[name="attribute_pa_${attrName}"]`,
        `select[data-attribute_name="${attrName}"]`,
        `select[data-attribute_name="attribute_${attrName}"]`,
      ];
      let sel = null;
      for (const s of selectors) { sel = document.querySelector(s); if (sel) break; }
      if (sel) {
        sel.value = val;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
      }
    });
  });

  // ── Gallery zoom on click (simple lightbox) ──────────────────
  const mainImage = $('#product-gallery .product-main-image img');
  if (mainImage) {
    mainImage.style.cursor = 'zoom-in';
    mainImage.addEventListener('click', () => {
      const overlay = document.createElement('div');
      overlay.style.cssText = 'position:fixed;inset:0;background:#000a;z-index:999;display:grid;place-items:center;cursor:zoom-out';
      const img = document.createElement('img');
      img.src = mainImage.src;
      img.style.cssText = 'max-width:90vw;max-height:90vh;border-radius:12px;box-shadow:0 30px 80px #0006';
      overlay.appendChild(img);
      overlay.addEventListener('click', () => overlay.remove());
      document.body.appendChild(overlay);
    });
  }

})();
