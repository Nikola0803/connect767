/* Align Precision — theme.js */
(function () {
  'use strict';

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];
  const data = window.alignData || {};

  // ── Rotating promo banner (S25 replacement) ──────────────────
  (function promoBar() {
    const slides = $$('.promo-slide');
    if (slides.length < 2) return;
    let current = 0;
    function showSlide(i) {
      slides[current].classList.remove('active');
      current = (i + slides.length) % slides.length;
      slides[current].classList.add('active');
    }
    setInterval(() => showSlide(current + 1), 4000);
  })();

  // ── WELCOME10 copy ───────────────────────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('#topbar-copy-code');
    if (!btn) return;
    e.preventDefault();
    navigator.clipboard
      ? navigator.clipboard.writeText('WELCOME10').then(() => showToast('Code WELCOME10 copied!'))
      : showToast('Use code WELCOME10 at checkout');
  });

  // ── Cart drawer ─────────────────────────────────────────────
  const cartOverlay = $('#cart-overlay');
  const cartClose   = $('.cart-close');

  function openCart() {
    if (!cartOverlay) return;
    cartOverlay.hidden = false;
    document.body.style.overflow = 'hidden';
    cartClose && cartClose.focus();
  }

  function closeCart() {
    if (!cartOverlay) return;
    cartOverlay.hidden = true;
    document.body.style.overflow = '';
  }

  $$('.cart-toggle').forEach(btn => btn.addEventListener('click', openCart));
  cartClose && cartClose.addEventListener('click', closeCart);
  cartOverlay && cartOverlay.addEventListener('click', function (e) {
    if (e.target === cartOverlay) closeCart();
  });

  // ── Add to cart (product card quick-add buttons) ─────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.add-to-cart-btn');
    if (!btn) return;
    e.preventDefault();
    const productId = btn.dataset.productId;
    if (!productId) return;

    btn.disabled = true;
    btn.textContent = '…';

    fetch(data.ajaxUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action: 'align_add_to_cart',
        nonce: data.nonce,
        product_id: productId,
        quantity: 1,
      }),
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          updateCartCount(res.data.count);
          showToast('Added to cart');
          refreshCartDrawer();
          openCart();
        } else {
          showToast(res.data?.message || 'Could not add to cart');
        }
      })
      .catch(() => showToast('Network error'))
      .finally(() => {
        btn.disabled = false;
        btn.textContent = 'Add to Cart';
      });
  });

  // ── Sticky ATC add to cart ────────────────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.sticky-atc-btn');
    if (!btn) return;
    e.preventDefault();
    const mainAtc = $('.purchase-row-wrapper button[name="add-to-cart"], .purchase-row-wrapper .single_add_to_cart_button');
    if (mainAtc) {
      mainAtc.click();
    }
  });

  // ── Remove from cart ─────────────────────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.remove-cart-item');
    if (!btn) return;
    e.preventDefault();
    const key = btn.dataset.key;

    fetch(data.ajaxUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        action: 'align_remove_cart_item',
        nonce: data.nonce,
        key,
      }),
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          updateCartCount(res.data.count);
          refreshCartDrawer();
        }
      });
  });

  // ── Mini-cart qty stepper (K1) ───────────────────────────────
  document.addEventListener('click', function (e) {
    const minus = e.target.closest('.mini-cart-stepper .qty-minus');
    const plus  = e.target.closest('.mini-cart-stepper .qty-plus');
    const btn   = minus || plus;
    if (!btn) return;
    const wrap  = btn.closest('.mini-cart-stepper');
    const key   = wrap.dataset.key;
    const nonce = wrap.dataset.nonce;
    const disp  = wrap.querySelector('.qty-display');
    if (!key || !disp) return;

    let qty = parseInt(disp.textContent, 10) || 1;
    if (minus) qty = Math.max(1, qty - 1);
    if (plus)  qty = qty + 1;
    disp.textContent = qty;

    fetch(data.ajaxUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'align_update_cart_qty', nonce, key, qty }),
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          updateCartCount(res.data.count);
          refreshCartDrawer();
        }
      });
  });

  function refreshCartDrawer() {
    fetch(data.ajaxUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ action: 'align_get_cart', nonce: data.nonce }),
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          const inner = $('.cart-drawer-inner');
          if (inner) inner.innerHTML = res.data.cart_html;
          updateCartCount(res.data.count);
        }
      });
  }

  function updateCartCount(count) {
    $$('.bag-count').forEach(el => {
      el.textContent = count;
      el.dataset.count = count;
      el.style.display = count > 0 ? '' : 'none';
    });
  }

  // ── Search overlay ───────────────────────────────────────────
  const searchOverlay = $('#search-overlay');
  const searchClose   = $('.search-close');
  const searchInput   = searchOverlay ? $('input[type="search"]', searchOverlay) : null;

  $$('.search-toggle').forEach(btn => btn.addEventListener('click', () => {
    if (!searchOverlay) return;
    searchOverlay.hidden = false;
    document.body.style.overflow = 'hidden';
    searchInput && setTimeout(() => searchInput.focus(), 80);
  }));

  searchClose && searchClose.addEventListener('click', () => {
    searchOverlay.hidden = true;
    document.body.style.overflow = '';
  });

  searchOverlay && searchOverlay.addEventListener('click', function (e) {
    if (e.target === searchOverlay) {
      searchOverlay.hidden = true;
      document.body.style.overflow = '';
    }
  });

  // ── Live search AJAX ─────────────────────────────────────────
  if (searchInput) {
    let searchTimer;
    const resultsBox = $('#search-results');
    searchInput.addEventListener('input', function () {
      clearTimeout(searchTimer);
      const q = this.value.trim();
      if (!q) { if (resultsBox) resultsBox.innerHTML = ''; return; }
      searchTimer = setTimeout(() => {
        fetch(data.ajaxUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ action: 'align_live_search', nonce: data.nonce, q }),
        })
          .then(r => r.json())
          .then(res => { if (res.success && resultsBox) resultsBox.innerHTML = res.data.html; });
      }, 260);
    });
  }

  // ── Mega menus (Catalogue + Explore) ────────────────────────
  const megaPairs = [
    { trigger: document.querySelector('.nav-mega-trigger:not(.nav-explore-trigger)'), menu: document.getElementById('mega-menu') },
    { trigger: document.querySelector('.nav-explore-trigger'),                        menu: document.getElementById('mega-menu-explore') },
  ].filter(p => p.trigger && p.menu);

  let openMega = null;

  function closeMega() {
    megaPairs.forEach(({ trigger, menu }) => {
      menu.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
    });
    openMega = null;
  }

  megaPairs.forEach(({ trigger, menu }) => {
    trigger.addEventListener('click', e => {
      e.stopPropagation();
      if (!menu.hidden) { closeMega(); return; }
      closeMega();
      menu.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      openMega = menu;
    });
  });

  document.addEventListener('click', e => {
    if (!openMega) return;
    const inside = megaPairs.some(({ trigger, menu }) =>
      trigger.contains(e.target) || menu.contains(e.target)
    );
    if (!inside) closeMega();
  });

  // ── Mobile menu ──────────────────────────────────────────────
  const mobileMenuBtn  = $('.mobile-menu');
  const mobileNav      = $('#mobile-nav');
  const mobileOverlay  = $('#mobile-nav-overlay');
  const mobileClose    = $('.mobile-nav-close');

  function openMobileNav() {
    if (!mobileNav) return;
    mobileNav.classList.add('open');
    mobileOverlay && mobileOverlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    mobileMenuBtn && mobileMenuBtn.setAttribute('aria-expanded', 'true');
  }

  function closeMobileNav() {
    if (!mobileNav) return;
    mobileNav.classList.remove('open');
    mobileOverlay && mobileOverlay.classList.remove('open');
    document.body.style.overflow = '';
    mobileMenuBtn && mobileMenuBtn.setAttribute('aria-expanded', 'false');
  }

  mobileMenuBtn && mobileMenuBtn.addEventListener('click', openMobileNav);
  mobileClose   && mobileClose.addEventListener('click', closeMobileNav);
  mobileOverlay && mobileOverlay.addEventListener('click', closeMobileNav);

  // ── Mobile nav accordion (S74 replacement) ──────────────────
  $$('.mobile-nav-accordion').forEach(btn => {
    btn.addEventListener('click', function () {
      const sub = this.nextElementSibling;
      if (!sub) return;
      const isOpen = !sub.hidden;
      // close all others
      $$('.mobile-nav-sub').forEach(el => { el.hidden = true; });
      $$('.mobile-nav-accordion').forEach(el => el.setAttribute('aria-expanded', 'false'));
      if (!isOpen) {
        sub.hidden = false;
        this.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ── Ticker pause/resume ──────────────────────────────────────
  const ticker      = $('.ticker');
  const tickerTrack = $('#ticker-track');
  const tickerPause = $('#ticker-pause');
  let paused = false;

  if (tickerPause && tickerTrack) {
    tickerPause.addEventListener('click', () => {
      paused = !paused;
      tickerTrack.style.animationPlayState = paused ? 'paused' : 'running';
      tickerPause.textContent = paused ? '▶ Resume' : '⏸ Pause';
      ticker && ticker.classList.toggle('paused', paused);
    });
  }

  // ── Toast ────────────────────────────────────────────────────
  function showToast(msg, duration = 2800) {
    const toast = $('#toast');
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('visible');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => toast.classList.remove('visible'), duration);
  }

  // ── Back-to-top ──────────────────────────────────────────────
  const btt = $('#back-to-top');
  if (btt) {
    window.addEventListener('scroll', () => {
      btt.hidden = window.scrollY < 400;
    }, { passive: true });
    btt.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  // ── Email popup (S40 replacement — 15 s delay, once per session) ─
  (function popup() {
    const overlay = $('#popup-overlay');
    if (!overlay) return;

    // Don't show on disclaimer page or if already shown this session
    const isGate = document.body.classList.contains('gate-body');
    const shown  = sessionStorage.getItem('align_popup_shown');
    if (isGate || shown) return;

    // Check age gate cookie
    const hasCookie = document.cookie.includes('align_age_verified=1');
    if (!hasCookie) return;

    function closePopup() {
      overlay.hidden = true;
      document.body.style.overflow = '';
    }

    // Show after 15 s
    setTimeout(() => {
      overlay.hidden = false;
      document.body.style.overflow = 'hidden';
      sessionStorage.setItem('align_popup_shown', '1');
    }, 15000);

    $('#popup-close') && $('#popup-close').addEventListener('click', closePopup);
    $('#popup-dismiss') && $('#popup-dismiss').addEventListener('click', closePopup);
    overlay.addEventListener('click', e => { if (e.target === overlay) closePopup(); });

    const form = $('#popup-form');
    form && form.addEventListener('submit', function (e) {
      e.preventDefault();
      const email = $('#popup-email')?.value?.trim();
      if (!email) return;
      const msg = $('#popup-msg');
      const nonce = form.querySelector('[name="popup_nonce"]')?.value || '';

      fetch(data.ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ action: 'align_popup_capture', nonce, email }),
      })
        .then(r => r.json())
        .then(res => {
          if (msg) msg.textContent = res.success ? 'Code WELCOME10 — use it at checkout!' : (res.data?.message || 'Something went wrong.');
          if (res.success) setTimeout(closePopup, 3500);
        })
        .catch(() => { if (msg) msg.textContent = 'Network error, please try again.'; });
    });
  })();

  // ── Mobile sticky ATC (D10) ──────────────────────────────────
  (function stickyAtc() {
    const stickyBar = $('#sticky-atc');
    const anchor    = $('.purchase-row-wrapper');
    if (!stickyBar || !anchor) return;

    const observer = new IntersectionObserver(
      ([entry]) => { stickyBar.hidden = entry.isIntersecting; },
      { rootMargin: '0px 0px -60px 0px' }
    );
    observer.observe(anchor);
  })();

  // ── Product gallery thumbnail swap ───────────────────────────
  document.addEventListener('click', function (e) {
    const btn = e.target.closest('.thumb-btn');
    if (!btn) return;
    const imgUrl = btn.dataset.img;
    const mainImg = document.getElementById('main-product-img');
    if (mainImg && imgUrl) mainImg.src = imgUrl;
    $$('.thumb-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
  });

  // ── Product accordion / tabs ─────────────────────────────────
  document.addEventListener('click', function (e) {
    const summary = e.target.closest('details summary');
    if (!summary) return;
    // Default <details> behavior handles toggle; just ensure smooth animation
  });

  // ── Keyboard: Escape closes overlays ────────────────────────
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (cartOverlay && !cartOverlay.hidden)     closeCart();
    if (searchOverlay && !searchOverlay.hidden) { searchOverlay.hidden = true; document.body.style.overflow = ''; }
    if (mobileNav && mobileNav.classList.contains('open')) closeMobileNav();
    if (openMega) closeMega();
    const po = $('#popup-overlay');
    if (po && !po.hidden) { po.hidden = true; document.body.style.overflow = ''; }
  });

  // ── WooCommerce fragment update (cart count) ─────────────────
  document.body.addEventListener('wc_fragments_refreshed', function () {
    const count = parseInt($('.bag-count')?.dataset.count || 0);
    updateCartCount(count);
  });

  // ── Checkout: coupon toggle (X4) ─────────────────────────────
  const couponToggle = document.getElementById('coupon-toggle');
  const couponRow    = document.getElementById('coupon-form-row');
  if (couponToggle && couponRow) {
    couponToggle.addEventListener('click', () => {
      const open = couponRow.hidden;
      couponRow.hidden = !open;
      couponToggle.setAttribute('aria-expanded', String(open));
    });
  }

  const applyBtn = document.getElementById('btn-apply-coupon');
  if (applyBtn) {
    applyBtn.addEventListener('click', () => {
      const code = document.getElementById('coupon_code')?.value?.trim();
      const msg  = document.getElementById('coupon-msg');
      if (!code) return;
      applyBtn.disabled = true;
      applyBtn.textContent = '…';
      fetch(data.ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ action: 'woocommerce_apply_coupon', security: applyBtn.dataset.nonce, coupon_code: code }),
      })
        .then(r => r.json())
        .then(res => {
          if (msg) {
            msg.hidden = false;
            const notices = res.messages || res.data?.messages || [];
            msg.innerHTML = Array.isArray(notices) ? notices.join(' ') : String(notices);
            msg.classList.toggle('error', !!res.data?.error);
          }
          if (typeof wc_checkout_params !== 'undefined') {
            document.body.trigger && document.body.dispatchEvent(new Event('update_checkout'));
          }
        })
        .catch(() => { if (msg) { msg.hidden = false; msg.textContent = 'Could not apply coupon.'; msg.classList.add('error'); } })
        .finally(() => { applyBtn.disabled = false; applyBtn.textContent = 'Apply'; });
    });
  }

  // ── Checkout: mobile order summary toggle (X12) ───────────────
  const summaryToggle = document.getElementById('checkout-summary-toggle');
  const summaryInner  = document.getElementById('checkout-summary-inner');
  if (summaryToggle && summaryInner) {
    summaryToggle.addEventListener('click', () => {
      if (window.innerWidth > 900) return;
      const open = summaryInner.classList.toggle('open');
      summaryToggle.classList.toggle('open', open);
      summaryInner.style.display = open ? '' : '';
    });
  }

})();
