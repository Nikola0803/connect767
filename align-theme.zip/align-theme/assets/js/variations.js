/**
 * Align — variation chip UI
 * Converts WooCommerce <select> variation tables into chip/pack buttons
 * while keeping WC's native variation JS working via hidden selects.
 */
(function() {
    'use strict';

    function buildChips(form) {
        var table = form.querySelector('table.variations');
        if (!table) return;

        var rows = table.querySelectorAll('tr');
        var container = document.createElement('div');
        container.className = 'align-variations';

        rows.forEach(function(row) {
            var label = row.querySelector('th.label label');
            var select = row.querySelector('td.value select');
            if (!select) return;

            var attrName = select.getAttribute('name') || '';
            var isPack = /pack/i.test(attrName) || /size/i.test(attrName);
            var labelText = label ? label.textContent.trim() : attrName.replace('attribute_', '').replace('pa_', '').replace(/-/g, ' ');

            var group = document.createElement('div');
            group.className = 'option-group';

            var heading = document.createElement('h3');
            heading.innerHTML = escHtml(labelText) + ' <small>' + (isPack ? 'Choose pack size' : 'Select a format') + '</small>';
            group.appendChild(heading);

            var valuesDiv = document.createElement('div');
            valuesDiv.className = 'option-values' + (isPack ? ' packs' : '');

            // Build chip/pack buttons from <option> values
            var options = select.querySelectorAll('option');
            options.forEach(function(opt) {
                if (!opt.value) return; // skip placeholder

                var btn = document.createElement('button');
                btn.type = 'button';
                btn.className = isPack ? 'pack-option' : 'chip';
                btn.dataset.select = attrName;
                btn.dataset.value = opt.value;
                btn.setAttribute('aria-pressed', 'false');

                if (isPack) {
                    // Try to get price from variation data
                    var priceStr = getVariationPrice(form, attrName, opt.value);
                    btn.innerHTML =
                        '<strong>' + escHtml(opt.textContent.trim()) + '</strong>' +
                        '<span>' + (priceStr || '') + '</span>' +
                        '<small>per selected pack</small>';
                } else {
                    btn.textContent = opt.textContent.trim();
                }

                btn.addEventListener('click', function() {
                    // Deactivate siblings
                    valuesDiv.querySelectorAll('button').forEach(function(b) {
                        b.classList.remove('active');
                        b.setAttribute('aria-pressed', 'false');
                    });
                    btn.classList.add('active');
                    btn.setAttribute('aria-pressed', 'true');

                    // Sync to select + trigger change
                    select.value = opt.value;
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                });

                valuesDiv.appendChild(btn);
            });

            group.appendChild(valuesDiv);
            container.appendChild(group);
        });

        // Hide the default variations table
        table.style.display = 'none';

        // Insert chips before the table
        table.parentNode.insertBefore(container, table);

        // Listen for WC setting variation_id (price update) — re-check active states
        form.addEventListener('found_variation', function(e) {
            if (!e.detail) return;
            // Nothing needed — chips already reflect selections
        });

        // Auto-select first available option in each group
        container.querySelectorAll('.option-group').forEach(function(grp) {
            var first = grp.querySelector('button');
            if (first) first.click();
        });
    }

    function getVariationPrice(form, attrName, value) {
        // Read from WC variation data if available
        var variationData = [];
        try {
            var raw = form.dataset.productVariations;
            if (raw) variationData = JSON.parse(raw);
        } catch(e) {}

        if (!variationData.length) return '';

        var match = variationData.find(function(v) {
            return v.attributes && v.attributes[attrName] === value && v.is_in_stock;
        });
        if (!match && variationData.length) {
            match = variationData.find(function(v) {
                return v.attributes && v.attributes[attrName] === value;
            });
        }
        if (match && match.display_price) {
            return formatPrice(match.display_price);
        }
        return '';
    }

    function formatPrice(price) {
        return new Intl.NumberFormat('en-CA', { style: 'currency', currency: 'CAD' }).format(price);
    }

    function buildQtyControl(form) {
        var qtyInput = form.querySelector('input[name="quantity"],.qty');
        if (!qtyInput) return;

        var wrapper = qtyInput.closest('.quantity,.qty-wrapper');
        if (!wrapper) wrapper = qtyInput.parentNode;

        var purchaseRow = form.querySelector('.purchase-row');
        if (!purchaseRow) return; // not our template

        // Hide native qty
        wrapper.style.display = 'none';

        var ctrl = document.createElement('div');
        ctrl.className = 'qty-control';
        ctrl.setAttribute('aria-label', 'Quantity');

        var minus = document.createElement('button');
        minus.type = 'button';
        minus.textContent = '−';
        minus.setAttribute('aria-label', 'Decrease quantity');

        var display = document.createElement('span');
        display.id = 'quantity-value';
        display.textContent = qtyInput.value || '1';

        var plus = document.createElement('button');
        plus.type = 'button';
        plus.textContent = '+';
        plus.setAttribute('aria-label', 'Increase quantity');

        function updateQty(delta) {
            var v = Math.max(1, Math.min(99, parseInt(display.textContent, 10) + delta));
            display.textContent = v;
            qtyInput.value = v;
            qtyInput.dispatchEvent(new Event('change', { bubbles: true }));
        }

        minus.addEventListener('click', function() { updateQty(-1); });
        plus.addEventListener('click', function() { updateQty(1); });

        ctrl.appendChild(minus);
        ctrl.appendChild(display);
        ctrl.appendChild(plus);

        purchaseRow.insertBefore(ctrl, purchaseRow.firstChild);
    }

    function escHtml(str) {
        return String(str).replace(/[&<>"']/g, function(c) {
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
        });
    }

    function init() {
        var forms = document.querySelectorAll('.variations_form.cart, form.cart[data-product_variations]');
        forms.forEach(function(form) {
            buildChips(form);
            buildQtyControl(form);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
