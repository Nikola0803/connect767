<?php
defined( 'ABSPATH' ) || exit;
get_header();

$term_name = __( 'All Products', 'align-theme' );
$term_slug = 'all-peptides';

// Main categories matching design mainCats order
$main_cats = [
    'all-peptides'       => __( 'All Products', 'align-theme' ),
    'glp1-agonists'      => __( 'GLPs', 'align-theme' ),
    'research-pens'      => __( 'Research Pens', 'align-theme' ),
    'recovery-repair'    => __( 'Recovery Research', 'align-theme' ),
    'longevity'          => __( 'Longevity Research', 'align-theme' ),
    'metabolic-research' => __( 'Metabolic Research', 'align-theme' ),
    'growth-research'    => __( 'Growth Research', 'align-theme' ),
    'hormonal-cognitive' => __( 'Hormonal &amp; Cognitive', 'align-theme' ),
    'research-bundles'   => __( 'Stacks &amp; Bundles', 'align-theme' ),
    'research-supplies'  => __( 'Research Supplies', 'align-theme' ),
];
?>

<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Align / The catalogue', 'align-theme' ); ?></div>
        <h1><?php echo esc_html( $term_name ); ?></h1>
        <p><?php esc_html_e( 'Research compounds. Original documentation. A clearer way to find what you need.', 'align-theme' ); ?></p>
    </div>
</div>

<div class="wrap">
    <section class="catalog-layout">

        <!-- Filter panel: toolbar + category tabs -->
        <div class="catalog-filter-panel">
            <div class="catalog-toolbar">
                <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="catalog-search-label">
                    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
                    <input
                        type="search"
                        name="s"
                        placeholder="<?php esc_attr_e( 'Search by compound or strength…', 'align-theme' ); ?>"
                        value="<?php echo get_search_query(); ?>"
                        aria-label="<?php esc_attr_e( 'Search compounds', 'align-theme' ); ?>"
                    >
                    <input type="hidden" name="post_type" value="product">
                </form>

                <span class="result-count">
                    <?php
                    global $wp_query;
                    printf(
                        esc_html( _n( '%s product', '%s products', $wp_query->found_posts, 'align-theme' ) ),
                        number_format_i18n( $wp_query->found_posts )
                    );
                    ?>
                </span>

                <select id="catalog-format" aria-label="<?php esc_attr_e( 'Filter product format', 'align-theme' ); ?>" onchange="if(this.value)window.location.href=this.value">
                    <?php
                    $format_cats = [
                        ''                 => __( 'All formats', 'align-theme' ),
                        'research-pens'    => __( 'Research pens', 'align-theme' ),
                        'research-bundles' => __( 'Stacks &amp; bundles', 'align-theme' ),
                        'research-supplies'=> __( 'Supplies', 'align-theme' ),
                    ];
                    foreach ( $format_cats as $slug => $label ) {
                        $url = $slug ? esc_url( get_term_link( get_term_by( 'slug', $slug, 'product_cat' ) ) ) : '';
                        printf(
                            '<option value="%s"%s>%s</option>',
                            $url,
                            '',
                            $label
                        );
                    }
                    ?>
                </select>

                <select id="catalog-sort" onchange="window.location.href=this.value" aria-label="<?php esc_attr_e( 'Sort products', 'align-theme' ); ?>">
                    <?php
                    $current = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : get_option( 'woocommerce_default_catalog_orderby' );
                    $labels  = [
                        'menu_order' => __( 'Featured', 'align-theme' ),
                        'date'       => __( 'Name: A–Z', 'align-theme' ),
                        'price'      => __( 'Price: low to high', 'align-theme' ),
                        'price-desc' => __( 'Price: high to low', 'align-theme' ),
                    ];
                    foreach ( $labels as $val => $label ) {
                        $url = add_query_arg( 'orderby', $val );
                        printf(
                            '<option value="%s"%s>%s</option>',
                            esc_url( $url ),
                            selected( $val, $current, false ),
                            esc_html( $label )
                        );
                    }
                    ?>
                </select>
            </div>

            <!-- Category filter tabs (main 10 categories from design) -->
            <nav class="catalog-category-tabs" aria-label="<?php esc_attr_e( 'Research categories', 'align-theme' ); ?>">
                <?php foreach ( $main_cats as $slug => $label ) :
                    if ( $slug === 'all-peptides' ) {
                        $href   = esc_url( get_permalink( wc_get_page_id( 'shop' ) ) );
                        $active = ' class="active"';
                        $count  = absint( wp_count_posts( 'product' )->publish );
                    } else {
                        $cat_obj = get_term_by( 'slug', $slug, 'product_cat' );
                        if ( ! $cat_obj ) continue;
                        $href   = esc_url( get_term_link( $cat_obj ) );
                        $active = '';
                        $count  = absint( $cat_obj->count );
                    }
                    ?>
                    <a href="<?php echo $href; ?>"<?php echo $active; ?>>
                        <?php echo $label; ?> <span><?php echo $count; ?></span>
                    </a>
                <?php endforeach; ?>
            </nav>
        </div>

        <!-- Product results -->
        <div class="catalog-results">
            <?php if ( have_posts() ) : ?>
            <div class="product-grid">
                <?php woocommerce_product_loop_start();
                while ( have_posts() ) {
                    the_post();
                    wc_get_template_part( 'content', 'product' );
                }
                woocommerce_product_loop_end(); ?>
            </div>
            <?php
            woocommerce_pagination();
            else :
                wc_get_template( 'loop/no-products-found.php' );
            endif; ?>
        </div>

        <!-- Support note -->
        <div class="catalog-support">
            <span><?php esc_html_e( 'Looking for a particular compound?', 'align-theme' ); ?></span>
            <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="text-link">
                <?php esc_html_e( 'Ask about the current listing and batch documentation ↗', 'align-theme' ); ?>
            </a>
        </div>

    </section>
</div>

<?php get_footer(); ?>
