<?php
defined( 'ABSPATH' ) || exit;
get_header();

while ( have_posts() ) :
    the_post();
    global $product;
    if ( ! $product ) $product = wc_get_product( get_the_ID() );
    if ( ! $product ) break;

    $product_id   = $product->get_id();
    $coa          = align_get_coa( $product_id );
    $gallery_ids  = $product->get_gallery_image_ids();
    $main_img_id  = $product->get_image_id();
    $main_img_url = wp_get_attachment_image_url( $main_img_id, 'align-product' ) ?: wc_placeholder_img_src( 'align-product' );
    $is_variable  = $product->is_type( 'variable' );
?>

<!-- Mobile sticky ATC bar (D10) — shown via IntersectionObserver when main ATC scrolls out of view -->
<div class="sticky-atc" id="sticky-atc" hidden>
    <div class="wrap sticky-atc-inner">
        <div class="sticky-atc-info">
            <span class="sticky-atc-name"><?php echo esc_html( $product->get_name() ); ?></span>
            <span class="sticky-atc-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></span>
        </div>
        <button type="button" class="btn sticky-atc-btn"><?php esc_html_e( 'Add to Cart', 'align-theme' ); ?></button>
    </div>
</div>

<div class="wrap">
    <?php align_breadcrumbs(); ?>

    <section class="product-layout">

        <!-- ── Gallery ──────────────────────────────────────── -->
        <div class="product-gallery" id="product-gallery">
            <div class="product-main-image" id="product-main-image">
                <img
                    src="<?php echo esc_url( $main_img_url ); ?>"
                    alt="<?php echo esc_attr( $product->get_name() ); ?> — Align Biosciences"
                    id="main-product-img"
                    width="700" height="735"
                    loading="eager"
                >
            </div>
            <?php if ( $main_img_id || ! empty( $gallery_ids ) ) : ?>
            <div class="gallery-thumbs">
                <?php if ( $main_img_id ) : ?>
                <button type="button" class="thumb-btn active" data-img="<?php echo esc_url( $main_img_url ); ?>" aria-label="<?php esc_attr_e( 'Main image', 'align-theme' ); ?>">
                    <img src="<?php echo esc_url( wp_get_attachment_image_url( $main_img_id, 'align-card' ) ); ?>" alt="" loading="lazy">
                </button>
                <?php endif; ?>
                <?php foreach ( $gallery_ids as $gid ) : ?>
                <button type="button" class="thumb-btn" data-img="<?php echo esc_url( wp_get_attachment_image_url( $gid, 'align-product' ) ); ?>" aria-label="<?php esc_attr_e( 'Product image', 'align-theme' ); ?>">
                    <img src="<?php echo esc_url( wp_get_attachment_image_url( $gid, 'align-card' ) ); ?>" alt="" loading="lazy">
                </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- ── Detail ───────────────────────────────────────── -->
        <div class="product-detail">
            <div class="eyebrow"><?php esc_html_e( 'Research use only · Align Biosciences', 'align-theme' ); ?></div>
            <h1><?php the_title(); ?></h1>

            <!-- Document badge — always link to COA page -->
            <a class="document-badge" href="<?php echo esc_url( home_url( '/coa/' ) ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8zM14 2v6h6M16 13H8M16 17H8M10 9H8"/></svg>
                <div>
                    <strong><?php esc_html_e( 'Batch documentation & independent testing', 'align-theme' ); ?></strong>
                    <p><?php esc_html_e( 'Review the Certificate of Analysis for your batch ↗', 'align-theme' ); ?></p>
                </div>
            </a>

            <!-- Price + stock + price-drop pill (D3) -->
            <div class="detail-price-row">
                <div class="detail-price"><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
                <?php if ( $product->is_on_sale() && ! $product->is_type( 'variable' ) ) :
                    $reg = (float) $product->get_regular_price();
                    $sal = (float) $product->get_sale_price();
                    $pct = $reg > 0 ? round( ( ( $reg - $sal ) / $reg ) * 100 ) : 0;
                    if ( $pct > 0 ) : ?>
                <span class="price-drop-pill">↓ <?php echo esc_html( $pct ); ?>% <?php esc_html_e( 'Price drop', 'align-theme' ); ?></span>
                    <?php endif;
                endif; ?>
                <?php if ( $product->is_in_stock() ) : ?>
                <span class="stock-status">● <?php esc_html_e( 'In stock', 'align-theme' ); ?></span>
                <?php else : ?>
                <span class="stock-status" style="color:#c0392b">● <?php esc_html_e( 'Unavailable', 'align-theme' ); ?></span>
                <?php endif; ?>
            </div>

            <!-- Short description -->
            <?php if ( $product->get_short_description() ) : ?>
            <div class="short-copy"><?php echo wp_kses_post( $product->get_short_description() ); ?></div>
            <?php else : ?>
            <div class="short-copy"><p><?php esc_html_e( 'Supplied for in vitro laboratory research. Review the product information and batch documentation below.', 'align-theme' ); ?></p></div>
            <?php endif; ?>

            <!-- Pack / Strength pills (D2) -->
            <?php if ( $is_variable ) :
                $available_variations = $product->get_available_variations();
                $attributes           = $product->get_variation_attributes();
                foreach ( $attributes as $attr_name => $attr_values ) :
                    if ( empty( $attr_values ) ) continue;
                    $attr_label = wc_attribute_label( $attr_name );
                    $is_pack    = stripos( $attr_name, 'pack' ) !== false || stripos( $attr_label, 'pack' ) !== false;
                    ?>
                <div class="pdp-pills-row" data-attr="<?php echo esc_attr( $attr_name ); ?>">
                    <div class="pdp-pills-label"><?php echo esc_html( $attr_label ); ?></div>
                    <div class="pdp-pills">
                        <?php foreach ( $attr_values as $val ) :
                            // Find a matching variation to get price
                            $variation_price = '';
                            $savings_pct     = 0;
                            if ( $is_pack ) {
                                foreach ( $available_variations as $var ) {
                                    $match = false;
                                    foreach ( $var['attributes'] as $k => $v ) {
                                        if ( strtolower( sanitize_title( $attr_name ) ) === strtolower( str_replace( 'attribute_', '', $k ) ) ||
                                             'attribute_' . sanitize_title( $attr_name ) === $k ) {
                                            $match = ( $v === $val || $v === '' );
                                        }
                                    }
                                    if ( $match || empty( array_filter( $var['attributes'] ) ) ) {
                                        if ( $var['display_price'] ) {
                                            $variation_price = wc_price( $var['display_price'] );
                                            if ( $var['display_regular_price'] > $var['display_price'] && $var['display_regular_price'] > 0 ) {
                                                $savings_pct = round( ( ( $var['display_regular_price'] - $var['display_price'] ) / $var['display_regular_price'] ) * 100 );
                                            }
                                        }
                                        break;
                                    }
                                }
                            }
                            ?>
                        <button type="button"
                                class="pdp-pill"
                                data-attr="<?php echo esc_attr( $attr_name ); ?>"
                                data-value="<?php echo esc_attr( $val ); ?>">
                            <?php echo esc_html( $val ); ?>
                            <?php if ( $is_pack && $savings_pct > 0 ) : ?>
                                <span class="pill-save">Save <?php echo esc_html( $savings_pct ); ?>%</span>
                            <?php endif; ?>
                        </button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach;
            endif; ?>

            <!-- WooCommerce add-to-cart (variations.js replaces selects with chips) -->
            <div class="purchase-row-wrapper">
                <?php woocommerce_template_single_add_to_cart(); ?>
            </div>

            <!-- Shipping note -->
            <div class="shipping-note">
                <svg class="icon" viewBox="0 0 24 24"><path d="M2 6h12v12H2V6Zm12 5h4l4 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg>
                <div>
                    <strong><?php esc_html_e( 'Ships next business day with tracking.', 'align-theme' ); ?></strong>
                    <p><?php esc_html_e( 'Canada-only shipping. Free shipping over $400.', 'align-theme' ); ?></p>
                </div>
            </div>

            <!-- COA button (full-width) -->
            <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>" class="btn coa-button" style="display:block;width:100%;text-align:center;margin-bottom:12px">
                <?php esc_html_e( '✓  View COA Reports', 'align-theme' ); ?>
            </a>

            <!-- Micro-trust -->
            <div class="micro-trust">
                <div>
                    <svg class="icon" viewBox="0 0 24 24"><path d="m7 12 3 3 7-7"/><circle cx="12" cy="12" r="9"/></svg>
                    <?php esc_html_e( 'Third-party tested', 'align-theme' ); ?>
                </div>
                <div>
                    <svg class="icon" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8zM14 2v6h6"/></svg>
                    <?php esc_html_e( 'Batch documentation', 'align-theme' ); ?>
                </div>
                <div>
                    <svg class="icon" viewBox="0 0 24 24"><path d="M2 6h12v12H2V6Zm12 5h4l4 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/></svg>
                    <?php esc_html_e( 'Canadian shipping', 'align-theme' ); ?>
                </div>
                <div>
                    <svg class="icon" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    <?php esc_html_e( 'Research use only', 'align-theme' ); ?>
                </div>
            </div>

            <p class="ruo-note"><?php esc_html_e( 'For in vitro laboratory research use only. Not for human consumption.', 'align-theme' ); ?></p>

            <!-- Payment icons (D6) -->
            <div class="payment-icons">
                <svg viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Visa"><rect width="38" height="24" rx="4" fill="#1A1F71"/><text x="7" y="17" fill="#fff" font-size="11" font-family="Arial" font-weight="700">VISA</text></svg>
                <svg viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Mastercard"><rect width="38" height="24" rx="4" fill="#252525"/><circle cx="15" cy="12" r="7" fill="#EB001B"/><circle cx="23" cy="12" r="7" fill="#F79E1B"/><path d="M19 6.8a7 7 0 0 1 0 10.4A7 7 0 0 1 19 6.8z" fill="#FF5F00"/></svg>
                <svg viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="Amex"><rect width="38" height="24" rx="4" fill="#2557D6"/><text x="5" y="16" fill="#fff" font-size="8.5" font-family="Arial" font-weight="700">AMEX</text></svg>
                <svg viewBox="0 0 38 24" width="38" height="24" role="img" aria-label="PayPal"><rect width="38" height="24" rx="4" fill="#fff" stroke="#e0e0e0"/><text x="4" y="16" fill="#003087" font-size="9" font-family="Arial" font-weight="700">Pay<tspan fill="#009CDE">Pal</tspan></text></svg>
                <span class="payment-icon-label"><?php esc_html_e( 'Secure checkout · Interac e-Transfer −5%', 'align-theme' ); ?></span>
            </div>

            <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="text-link" style="display:block;margin-top:16px;font-size:13px">
                <?php esc_html_e( 'Questions about this listing? Contact our team →', 'align-theme' ); ?>
            </a>
        </div>
    </section>
</div>

<!-- ── Product description + accordion ─────────────────────── -->
<?php if ( $product->get_description() ) : ?>
<section class="wrap product-description">
    <div>
        <div class="eyebrow"><?php esc_html_e( 'Product information', 'align-theme' ); ?></div>
        <div class="content-copy"><?php echo wp_kses_post( $product->get_description() ); ?></div>
    </div>
    <div class="info-accordion">
        <div class="eyebrow"><?php esc_html_e( 'At a glance', 'align-theme' ); ?></div>
        <h2 style="font-size:30px;margin-bottom:22px"><?php esc_html_e( 'Research specifications', 'align-theme' ); ?></h2>

        <?php if ( $coa['url'] ) : ?>
        <details open>
            <summary><?php esc_html_e( 'Certificate of Analysis', 'align-theme' ); ?></summary>
            <div class="content-copy">
                <?php if ( $coa['purity'] ) : ?>
                <p><strong><?php esc_html_e( 'Purity:', 'align-theme' ); ?></strong> <?php echo esc_html( $coa['purity'] ); ?>%</p>
                <?php endif; ?>
                <?php if ( $coa['batch'] ) : ?>
                <p><strong><?php esc_html_e( 'Batch:', 'align-theme' ); ?></strong> <?php echo esc_html( $coa['batch'] ); ?></p>
                <?php endif; ?>
                <a href="<?php echo esc_url( $coa['url'] ); ?>" target="_blank" rel="noopener" class="btn coa-button"><?php esc_html_e( 'Download COA PDF', 'align-theme' ); ?></a>
            </div>
        </details>
        <?php else : ?>
        <details open>
            <summary><?php esc_html_e( 'Research context', 'align-theme' ); ?></summary>
            <div class="content-copy">
                <p><?php esc_html_e( 'Each compound is tested by an independent third-party laboratory. Batch documentation is available on the COA page.', 'align-theme' ); ?></p>
                <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>" class="btn coa-button"><?php esc_html_e( 'View Lab Results', 'align-theme' ); ?></a>
            </div>
        </details>
        <?php endif; ?>

        <details>
            <summary><?php esc_html_e( 'Shipping & research-use information', 'align-theme' ); ?></summary>
            <div class="content-copy">
                <p><?php esc_html_e( 'Shipped via temperature-controlled packaging. Store lyophilised peptides at −20°C in a dry, dark environment. Reconstituted peptides should be aliquoted and stored at −80°C.', 'align-theme' ); ?></p>
                <p><?php esc_html_e( 'This product is sold for in vitro research and laboratory use only. Not intended for human consumption, food use, drug use, or veterinary applications.', 'align-theme' ); ?></p>
                <a href="<?php echo esc_url( home_url( '/shipping-policy/' ) ); ?>" class="text-link"><?php esc_html_e( 'Read the Shipping Policy', 'align-theme' ); ?></a>
            </div>
        </details>
    </div>
</section>
<?php endif; ?>

<!-- ── Frequently Bought Together (D8) ────────────────────── -->
<?php
$fbt_ids = $product->get_upsell_ids();
if ( empty( $fbt_ids ) ) {
    $fbt_raw = wc_get_related_products( $product_id, 4 );
    $fbt_ids = array_slice( $fbt_raw, 0, 4 );
}
if ( ! empty( $fbt_ids ) ) :
    $fbt_products = array_filter( array_map( 'wc_get_product', array_slice( $fbt_ids, 0, 4 ) ) );
?>
<section class="section wrap fbt-section">
    <div class="section-head">
        <div>
            <div class="eyebrow"><?php esc_html_e( 'Research bundle suggestion', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Frequently Bought Together', 'align-theme' ); ?></h2>
        </div>
    </div>
    <div class="fbt-grid">
        <?php foreach ( $fbt_products as $fbt ) :
            $fbt_img = wp_get_attachment_image_url( $fbt->get_image_id(), 'align-card' ) ?: wc_placeholder_img_src( 'align-card' );
        ?>
        <div class="fbt-card">
            <a href="<?php echo esc_url( $fbt->get_permalink() ); ?>" class="fbt-img-link">
                <img src="<?php echo esc_url( $fbt_img ); ?>" alt="<?php echo esc_attr( $fbt->get_name() ); ?>" loading="lazy" width="120" height="120">
            </a>
            <div class="fbt-info">
                <a href="<?php echo esc_url( $fbt->get_permalink() ); ?>" class="fbt-name"><?php echo esc_html( $fbt->get_name() ); ?></a>
                <div class="fbt-price"><?php echo wp_kses_post( $fbt->get_price_html() ); ?></div>
            </div>
            <?php if ( $fbt->is_in_stock() && $fbt->is_purchasable() && ! $fbt->is_type( 'variable' ) ) : ?>
            <button type="button" class="btn small add-to-cart-btn" data-product="<?php echo esc_attr( $fbt->get_id() ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'align_nonce' ) ); ?>">
                <?php esc_html_e( 'Add', 'align-theme' ); ?>
            </button>
            <?php else : ?>
            <a href="<?php echo esc_url( $fbt->get_permalink() ); ?>" class="btn small outline"><?php esc_html_e( 'View', 'align-theme' ); ?></a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- ── Related products ──────────────────────────────────────── -->
<?php
$related_ids = wc_get_related_products( $product_id, 4 );
if ( ! empty( $related_ids ) ) :
    $related = array_filter( array_map( 'wc_get_product', $related_ids ) );
?>
<section class="section wrap">
    <div class="section-head">
        <div>
            <div class="eyebrow"><?php esc_html_e( 'Continue researching', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Related products', 'align-theme' ); ?></h2>
        </div>
        <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>" class="text-link"><?php esc_html_e( 'View all products →', 'align-theme' ); ?></a>
    </div>
    <div class="product-grid">
        <?php foreach ( $related as $rel ) : ?>
        <?php setup_postdata( $GLOBALS['post'] =& get_post( $rel->get_id() ) ); ?>
        <?php wc_get_template_part( 'content', 'product' ); ?>
        <?php endforeach; ?>
        <?php wp_reset_postdata(); ?>
    </div>
</section>
<?php endif; ?>

<?php
endwhile;
get_footer();
?>
