<?php defined( 'ABSPATH' ) || exit; ?>
<div class="product-grid">
