<?php
defined( 'ABSPATH' ) || exit;

global $product;

if ( empty( $product ) || ! $product->is_visible() ) return;

$product_id  = $product->get_id();
$permalink   = $product->get_permalink();
$img_url     = wp_get_attachment_image_url( $product->get_image_id(), 'align-card' ) ?: wc_placeholder_img_src( 'align-card' );
$in_stock    = $product->is_in_stock();
$is_on_sale  = $product->is_on_sale();
$is_variable = $product->is_type( 'variable' );

// --- Custom badge (BEST SELLER / TOP PICK / NEW / POPULAR) from product meta
$custom_badge = get_post_meta( $product_id, '_align_badge', true );

// --- Purity from meta (C5)
$purity = get_post_meta( $product_id, 'align_purity', true );
if ( ! $purity ) $purity = get_post_meta( $product_id, '_coa_purity_testides', true );

// --- Sale percentage
$sale_pct = '';
if ( $is_on_sale && ! $is_variable ) {
    $reg = (float) $product->get_regular_price();
    $sale = (float) $product->get_sale_price();
    if ( $reg > 0 ) {
        $sale_pct = '-' . round( ( ( $reg - $sale ) / $reg ) * 100 ) . '%';
    }
} elseif ( $is_on_sale && $is_variable ) {
    $variations = $product->get_available_variations();
    if ( ! empty( $variations ) ) {
        $max_pct = 0;
        foreach ( $variations as $v ) {
            if ( ! empty( $v['display_regular_price'] ) && ! empty( $v['display_price'] ) ) {
                $reg  = (float) $v['display_regular_price'];
                $sale = (float) $v['display_price'];
                if ( $reg > 0 ) $max_pct = max( $max_pct, round( ( ( $reg - $sale ) / $reg ) * 100 ) );
            }
        }
        if ( $max_pct > 0 ) $sale_pct = '-' . $max_pct . '%';
    }
}

// --- Primary category
$primary_cat = '';
$terms = get_the_terms( $product_id, 'product_cat' );
if ( $terms && ! is_wp_error( $terms ) ) {
    foreach ( $terms as $t ) {
        if ( $t->parent !== 0 ) continue;
        $primary_cat = $t->name;
        break;
    }
    if ( ! $primary_cat ) $primary_cat = $terms[0]->name;
}

// --- Strengths line
$strengths = '';
foreach ( [ 'pa_strength', 'pa_size', 'pa_concentration', 'strength', 'size' ] as $key ) {
    $val = $product->get_attribute( $key );
    if ( $val ) { $strengths = $val; break; }
}

// --- Saved/wishlist state
$saved_class = '';
if ( is_user_logged_in() ) {
    $saved_ids = get_user_meta( get_current_user_id(), '_align_saved_products', true );
    if ( is_array( $saved_ids ) && in_array( $product_id, $saved_ids, true ) ) {
        $saved_class = ' saved';
    }
}
?>
<article class="product-card<?php echo ! $in_stock ? ' oos' : ''; ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>">

    <!-- Badges row -->
    <div class="card-index">
        <?php if ( $primary_cat ) : ?>
        <span class="card-cat"><?php echo esc_html( $primary_cat ); ?></span>
        <?php endif; ?>

        <div class="card-badges">
            <?php if ( $sale_pct ) : ?>
            <span class="tag sale-tag"><?php echo esc_html( $sale_pct ); ?></span>
            <?php endif; ?>
            <?php if ( $custom_badge ) : ?>
            <span class="tag custom-badge"><?php echo esc_html( strtoupper( $custom_badge ) ); ?></span>
            <?php endif; ?>
            <?php if ( ! $in_stock ) : ?>
            <span class="tag oos-tag"><?php esc_html_e( 'OUT OF STOCK', 'align-theme' ); ?></span>
            <?php endif; ?>
        </div>

        <button
            type="button"
            class="save-product<?php echo esc_attr( $saved_class ); ?>"
            data-product="<?php echo esc_attr( $product_id ); ?>"
            aria-label="<?php esc_attr_e( 'Save product', 'align-theme' ); ?>"
        >
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
        </button>
    </div>

    <!-- Image -->
    <a href="<?php echo esc_url( $permalink ); ?>" class="product-card-link" aria-label="<?php echo esc_attr( $product->get_name() ); ?>">
        <div class="product-media">
            <img
                src="<?php echo esc_url( $img_url ); ?>"
                alt="<?php echo esc_attr( $product->get_name() ); ?>"
                loading="lazy"
                width="600" height="600"
            >
            <span class="image-view"><?php esc_html_e( 'Explore compound', 'align-theme' ); ?> <svg viewBox="0 0 24 24" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></span>
        </div>
    </a>

    <!-- Info -->
    <div class="product-card-info">
        <h3><a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>

        <?php if ( $strengths ) : ?>
        <p class="card-format"><?php echo esc_html( $strengths ); ?></p>
        <?php endif; ?>

        <?php if ( $purity ) : ?>
        <p class="card-purity"><?php printf( esc_html__( '≥%s%% purity · HPLC verified', 'align-theme' ), esc_html( $purity ) ); ?></p>
        <?php endif; ?>

        <div class="product-card-foot">
            <span class="price">
                <?php echo wp_kses_post( $product->get_price_html() ); ?>
                <small class="currency"><?php echo esc_html( get_woocommerce_currency() ); ?></small>
            </span>
            <?php if ( $in_stock && ! $is_variable ) : ?>
            <button
                type="button"
                class="add-to-cart-btn"
                data-product-id="<?php echo esc_attr( $product_id ); ?>"
                aria-label="<?php printf( esc_attr__( 'Add %s to cart', 'align-theme' ), $product->get_name() ); ?>"
            >+</button>
            <?php else : ?>
            <a href="<?php echo esc_url( $permalink ); ?>" class="card-arrow" aria-label="<?php echo esc_attr( sprintf( __( 'Explore %s', 'align-theme' ), $product->get_name() ) ); ?>">
                <svg viewBox="0 0 24 24" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </a>
            <?php endif; ?>
        </div>

        <div class="card-document">
            <span><?php echo $in_stock ? esc_html__( 'Available for research', 'align-theme' ) : esc_html__( 'Currently unavailable', 'align-theme' ); ?></span>
            <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab reports ↗', 'align-theme' ); ?></a>
        </div>
    </div>

</article>
