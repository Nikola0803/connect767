<?php
defined( 'ABSPATH' ) || exit;
?>

<div class="wrap checkout-thankyou" style="padding:60px 0 100px;max-width:720px">

    <?php if ( $order ) :
        do_action( 'woocommerce_before_thankyou', $order->get_id() );
    ?>

    <?php if ( $order->has_status( 'failed' ) ) : ?>

        <div class="alert alert-error" style="background:#fef2f2;border:1px solid #fecaca;border-radius:12px;padding:20px 24px;margin-bottom:28px">
            <h2 style="font-size:22px;color:#c0392b;margin-bottom:8px"><?php esc_html_e( 'Payment failed', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'Unfortunately your order cannot be processed. Please attempt your purchase again or contact our team.', 'align-theme' ); ?></p>
        </div>

        <a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="btn"><?php esc_html_e( 'Try again', 'align-theme' ); ?></a>

    <?php else : ?>

        <div class="eyebrow" style="color:#187a54;margin-bottom:10px"><?php esc_html_e( 'Order confirmed', 'align-theme' ); ?></div>
        <h1 style="font-size:clamp(32px,5vw,52px);margin-bottom:12px"><?php esc_html_e( 'Thank you for your order.', 'align-theme' ); ?></h1>
        <p style="font-size:15px;color:#555;margin-bottom:32px"><?php esc_html_e( 'Your order has been received. You will receive a confirmation email shortly.', 'align-theme' ); ?></p>

        <!-- Order summary -->
        <div class="form-card" style="margin-bottom:28px">
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:18px;padding:4px 0">
                <div>
                    <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( 'Order number', 'align-theme' ); ?></div>
                    <strong><?php echo esc_html( $order->get_order_number() ); ?></strong>
                </div>
                <div>
                    <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( 'Date', 'align-theme' ); ?></div>
                    <strong><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></strong>
                </div>
                <div>
                    <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( 'Total', 'align-theme' ); ?></div>
                    <strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong>
                </div>
                <div>
                    <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( 'Payment', 'align-theme' ); ?></div>
                    <strong><?php echo esc_html( $order->get_payment_method_title() ); ?></strong>
                </div>
            </div>
        </div>

        <?php
        // e-Transfer instructions when gateway = hretg
        if ( $order->get_payment_method() === 'hretg' ) : ?>
        <div class="form-card" style="background:#f0fdf4;border-color:#bbf7d0;margin-bottom:28px">
            <div class="eyebrow" style="color:#16a34a;margin-bottom:10px"><?php esc_html_e( 'Interac e-Transfer instructions', 'align-theme' ); ?></div>
            <h3 style="font-size:18px;margin-bottom:14px"><?php esc_html_e( 'Your order is pending payment.', 'align-theme' ); ?></h3>
            <p style="font-size:14px;line-height:1.75;margin-bottom:12px"><?php esc_html_e( 'Please send your e-Transfer to:', 'align-theme' ); ?> <strong>payments@alignpeptides.com</strong></p>
            <p style="font-size:14px;margin-bottom:8px"><?php printf( esc_html__( 'Amount: %s', 'align-theme' ), '<strong>' . wp_kses_post( $order->get_formatted_order_total() ) . '</strong>' ); ?></p>
            <p style="font-size:14px;margin-bottom:8px"><?php printf( esc_html__( 'Message/memo: Order #%s', 'align-theme' ), '<strong>' . esc_html( $order->get_order_number() ) . '</strong>' ); ?></p>
            <p style="font-size:13px;color:#555;margin-top:14px"><?php esc_html_e( 'Your order will be processed once payment is confirmed. A confirmation email will be sent to you.', 'align-theme' ); ?></p>
        </div>
        <?php endif; ?>

        <!-- Order items -->
        <div class="form-card" style="margin-bottom:28px">
            <h3 style="font-size:16px;font-weight:700;margin-bottom:18px"><?php esc_html_e( 'Items ordered', 'align-theme' ); ?></h3>
            <?php foreach ( $order->get_items() as $item_id => $item ) :
                $product    = $item->get_product();
                $item_img   = $product ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : '';
            ?>
            <div style="display:flex;align-items:center;gap:14px;padding:10px 0;border-bottom:1px solid #f5f5f5">
                <?php if ( $item_img ) : ?>
                <img src="<?php echo esc_url( $item_img ); ?>" alt="" width="52" height="52" style="border-radius:8px;object-fit:cover;flex-shrink:0">
                <?php endif; ?>
                <div style="flex:1;min-width:0">
                    <div style="font-weight:600;font-size:14px"><?php echo wp_kses_post( $item->get_name() ); ?></div>
                    <?php echo wc_get_formatted_cart_item_data( $item ); ?>
                    <div style="font-size:13px;color:#777">× <?php echo esc_html( $item->get_quantity() ); ?></div>
                </div>
                <div style="font-weight:600;font-size:14px;white-space:nowrap"><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></div>
            </div>
            <?php endforeach; ?>

            <div style="margin-top:14px;padding-top:14px;border-top:1px solid #eee">
                <?php foreach ( $order->get_order_item_totals() as $key => $total ) : ?>
                <div style="display:flex;justify-content:space-between;font-size:13px;padding:4px 0;<?php echo $key === 'order_total' ? 'font-weight:700;font-size:15px;border-top:1px solid #eee;padding-top:10px;margin-top:6px' : ''; ?>">
                    <span><?php echo wp_kses_post( $total['label'] ); ?></span>
                    <span><?php echo wp_kses_post( $total['value'] ); ?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Shipping address -->
        <div class="form-card" style="margin-bottom:28px">
            <h3 style="font-size:16px;font-weight:700;margin-bottom:14px"><?php esc_html_e( 'Shipping address', 'align-theme' ); ?></h3>
            <address style="font-style:normal;font-size:14px;line-height:1.8;color:#555">
                <?php echo wp_kses_post( $order->get_formatted_shipping_address() ?: $order->get_formatted_billing_address() ); ?>
            </address>
        </div>

        <?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>

        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px">
            <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="btn outline"><?php esc_html_e( 'View order details', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="btn"><?php esc_html_e( 'Continue shopping', 'align-theme' ); ?></a>
        </div>

    <?php endif; ?>

    <?php else : ?>

    <div class="eyebrow" style="color:#187a54;margin-bottom:10px"><?php esc_html_e( 'Thank you', 'align-theme' ); ?></div>
    <h1 style="font-size:clamp(32px,5vw,52px);margin-bottom:12px"><?php esc_html_e( 'Your order has been received.', 'align-theme' ); ?></h1>
    <p style="margin-bottom:28px"><?php esc_html_e( 'A confirmation email has been sent to you.', 'align-theme' ); ?></p>
    <a href="<?php echo esc_url( get_permalink( wc_get_page_id( 'shop' ) ) ); ?>" class="btn"><?php esc_html_e( 'Continue shopping', 'align-theme' ); ?></a>

    <?php endif; ?>

</div>
