<?php
defined( 'ABSPATH' ) || exit;

if ( ! is_checkout() ) return;

do_action( 'woocommerce_before_checkout_form', $checkout );

// Non-WC content inserted by plugins lives here
if ( $checkout->get_checkout_fields() ) : ?>
<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">

<div class="checkout-layout">

    <!-- ── LEFT: Fields ──────────────────────────────────────── -->
    <div class="checkout-fields-col">

        <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

        <!-- Contact / Account -->
        <div class="checkout-section" id="checkout-contact">
            <h2 class="checkout-section-title"><?php esc_html_e( 'Contact', 'align-theme' ); ?></h2>

            <?php if ( is_user_logged_in() ) : ?>
                <p class="checkout-logged-in">
                    <?php
                    $current = wp_get_current_user();
                    /* translators: %s: user display name */
                    printf( esc_html__( 'Signed in as %s.', 'align-theme' ), esc_html( $current->display_name ) );
                    echo ' <a href="' . esc_url( wc_get_account_endpoint_url( 'dashboard' ) ) . '">' . esc_html__( 'Manage account', 'align-theme' ) . '</a>';
                    ?>
                </p>
            <?php else : ?>
                <?php woocommerce_form_field( 'billing_email', [
                    'type'        => 'email',
                    'label'       => __( 'Email address', 'align-theme' ),
                    'required'    => true,
                    'class'       => [ 'form-row-wide' ],
                    'placeholder' => __( 'your@email.com', 'align-theme' ),
                ], $checkout->get_value( 'billing_email' ) ); ?>

                <?php if ( 'yes' === get_option( 'woocommerce_enable_guest_checkout' ) && 'yes' !== get_option( 'woocommerce_enable_signup_and_login_from_checkout' ) ) : ?>
                <?php elseif ( 'yes' === get_option( 'woocommerce_enable_signup_and_login_from_checkout' ) ) : ?>
                    <p class="create-account-row">
                        <label class="check-field">
                            <input type="checkbox" name="createaccount" id="createaccount" value="1" <?php checked( ( true === $checkout->get_value( 'createaccount' ) || ( true === apply_filters( 'woocommerce_create_account_default_checked', false ) ) ), true ); ?>>
                            <?php esc_html_e( 'Create an account (optional)', 'align-theme' ); ?>
                        </label>
                    </p>
                <?php endif; ?>
            <?php endif; ?>

            <!-- Omnisend opt-in (X8) -->
            <p class="omnisend-optin-row">
                <label class="check-field">
                    <input type="checkbox" name="omnisend_optin" id="omnisend_optin" value="1" checked>
                    <?php esc_html_e( 'Keep me updated on new products and exclusive offers', 'align-theme' ); ?>
                </label>
            </p>
        </div>

        <!-- Shipping address -->
        <div class="checkout-section" id="checkout-shipping">
            <h2 class="checkout-section-title"><?php esc_html_e( 'Shipping address', 'align-theme' ); ?></h2>
            <div class="checkout-fields-grid">
                <?php
                $fields = $checkout->get_checkout_fields( 'shipping' );
                // Hide company
                unset( $fields['shipping_company'] );
                // Re-order: first/last name side-by-side, then address, postcode/city, province, phone
                $ordered = [
                    'shipping_first_name', 'shipping_last_name',
                    'shipping_address_1', 'shipping_address_2',
                    'shipping_postcode', 'shipping_city',
                    'shipping_state', 'shipping_country',
                    'billing_phone',
                ];
                // Render in custom order
                foreach ( $ordered as $key ) {
                    if ( $key === 'billing_phone' ) {
                        $phone_fields = $checkout->get_checkout_fields( 'billing' );
                        if ( isset( $phone_fields['billing_phone'] ) ) {
                            woocommerce_form_field( 'billing_phone', $phone_fields['billing_phone'], $checkout->get_value( 'billing_phone' ) );
                        }
                        continue;
                    }
                    if ( ! isset( $fields[ $key ] ) ) continue;
                    // Make first/last name half-width
                    if ( in_array( $key, [ 'shipping_first_name', 'shipping_last_name' ], true ) ) {
                        $fields[ $key ]['class'] = [ 'form-row-first', 'form-row-half' ];
                    }
                    woocommerce_form_field( $key, $fields[ $key ], $checkout->get_value( $key ) );
                }
                // Catch any remaining fields we didn't list
                foreach ( $fields as $key => $field ) {
                    if ( in_array( $key, $ordered, true ) ) continue;
                    woocommerce_form_field( $key, $field, $checkout->get_value( $key ) );
                }
                ?>
            </div>
        </div>

        <!-- Coupon toggle (X4) -->
        <div class="checkout-section checkout-coupon-section" id="checkout-coupon">
            <button type="button" class="coupon-toggle" id="coupon-toggle" aria-expanded="false">
                <?php esc_html_e( 'Have a promo code?', 'align-theme' ); ?>
                <svg class="coupon-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
            </button>
            <div class="coupon-form-row" id="coupon-form-row" hidden>
                <div class="coupon-fields">
                    <input type="text" name="coupon_code" id="coupon_code" class="input-text" placeholder="<?php esc_attr_e( 'Promo code', 'align-theme' ); ?>">
                    <button type="button" class="btn btn-apply-coupon" id="btn-apply-coupon" data-nonce="<?php echo esc_attr( wp_create_nonce( 'apply-coupon' ) ); ?>">
                        <?php esc_html_e( 'Apply', 'align-theme' ); ?>
                    </button>
                </div>
                <p class="coupon-msg" id="coupon-msg" hidden></p>
            </div>
        </div>

        <!-- Order note -->
        <div class="checkout-section" id="checkout-notes">
            <?php woocommerce_form_field( 'order_comments', [
                'type'        => 'textarea',
                'label'       => __( 'Order notes (optional)', 'align-theme' ),
                'placeholder' => __( 'Notes about your order, e.g. special delivery instructions.', 'align-theme' ),
                'class'       => [ 'form-row-wide' ],
                'required'    => false,
            ], $checkout->get_value( 'order_comments' ) ); ?>
        </div>

        <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

        <!-- Payment (rendered in left col, above submit on mobile) -->
        <div class="checkout-section checkout-payment-section" id="checkout-payment">
            <h2 class="checkout-section-title"><?php esc_html_e( 'Payment', 'align-theme' ); ?></h2>

            <?php if ( WC()->cart->needs_payment() ) : ?>
                <?php wc_get_template( 'checkout/payment.php' ); ?>
            <?php else : ?>
                <?php wc_get_template( 'checkout/payment.php' ); ?>
            <?php endif; ?>
        </div>

        <?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>

    </div><!-- .checkout-fields-col -->

    <!-- ── RIGHT: Order summary ──────────────────────────────── -->
    <div class="checkout-summary-col" id="checkout-order-review">

        <h2 class="checkout-section-title checkout-summary-toggle" id="checkout-summary-toggle">
            <?php esc_html_e( 'Your order', 'align-theme' ); ?>
            <svg class="summary-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
        </h2>

        <div class="checkout-summary-inner" id="checkout-summary-inner">
            <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>
            <?php wc_get_template( 'checkout/review-order.php', [ 'checkout' => $checkout ] ); ?>
            <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
        </div>

    </div><!-- .checkout-summary-col -->

</div><!-- .checkout-layout -->

<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

</form>
<?php endif; ?>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
