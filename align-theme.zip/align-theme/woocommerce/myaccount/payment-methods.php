<?php
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_payment_methods', $has_methods );
?>

<div class="account-payment-page">
    <div class="account-section-head" style="margin-bottom:28px">
        <h2><?php esc_html_e( 'Payment Methods', 'align-theme' ); ?></h2>
    </div>

    <?php if ( $has_methods ) : ?>
    <table class="account-orders-table" style="margin-bottom:24px">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Method', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Expires', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Default', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'align-theme' ); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $payment_methods as $method ) :
            $method_title = $method->get_display_name();
            $expiry_year  = $method->get_meta_data()['expiry_year'] ?? '';
            $expiry_month = $method->get_meta_data()['expiry_month'] ?? '';
            $is_default   = $method->is_default();
            ?>
            <tr>
                <td><?php echo wp_kses_post( $method_title ); ?></td>
                <td><?php echo $expiry_month && $expiry_year ? esc_html( $expiry_month . '/' . $expiry_year ) : '&mdash;'; ?></td>
                <td><?php echo $is_default ? '<span class="order-status-badge">' . esc_html__( 'Default', 'align-theme' ) . '</span>' : '&mdash;'; ?></td>
                <td>
                    <?php
                    $actions = $method->get_actions();
                    foreach ( $actions as $key => $action ) :
                    ?>
                        <a href="<?php echo esc_url( $action['url'] ); ?>" class="text-link" style="font-size:13px;margin-right:10px"><?php echo esc_html( $action['name'] ); ?></a>
                    <?php endforeach; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else : ?>
    <div class="account-empty">
        <p><?php esc_html_e( 'No saved payment methods found.', 'align-theme' ); ?></p>
    </div>
    <?php endif; ?>

    <?php if ( WC()->payment_gateways->get_available_payment_gateways() ) : ?>
    <a href="<?php echo esc_url( wc_get_endpoint_url( 'add-payment-method' ) ); ?>" class="btn btn-outline">
        <?php esc_html_e( '+ Add Payment Method', 'align-theme' ); ?>
    </a>
    <?php endif; ?>
</div>

<?php do_action( 'woocommerce_after_account_payment_methods', $has_methods ); ?>
