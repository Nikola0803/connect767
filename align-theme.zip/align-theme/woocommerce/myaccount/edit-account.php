<?php
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_edit_account_form' ); ?>

<div class="account-edit-page">
    <div class="account-section-head" style="margin-bottom:28px">
        <h2><?php esc_html_e( 'Account Details', 'align-theme' ); ?></h2>
    </div>

    <form class="form-card" method="post" action="" style="max-width:540px">

        <?php do_action( 'woocommerce_edit_account_form_start' ); ?>

        <div class="form-grid" style="grid-template-columns:1fr 1fr">
            <div class="field">
                <label for="account_first_name"><?php esc_html_e( 'First name', 'align-theme' ); ?> <abbr title="required">*</abbr></label>
                <input type="text" class="woocommerce-Input" name="account_first_name" id="account_first_name" autocomplete="given-name" value="<?php echo esc_attr( $user->first_name ); ?>" required>
            </div>
            <div class="field">
                <label for="account_last_name"><?php esc_html_e( 'Last name', 'align-theme' ); ?> <abbr title="required">*</abbr></label>
                <input type="text" class="woocommerce-Input" name="account_last_name" id="account_last_name" autocomplete="family-name" value="<?php echo esc_attr( $user->last_name ); ?>" required>
            </div>
            <div class="field full">
                <label for="account_display_name"><?php esc_html_e( 'Display name', 'align-theme' ); ?> <abbr title="required">*</abbr></label>
                <input type="text" class="woocommerce-Input" name="account_display_name" id="account_display_name" value="<?php echo esc_attr( $user->display_name ); ?>" required>
                <small style="color:#999;font-size:11px"><?php esc_html_e( 'This will be how your name will be displayed in the account section and in reviews.', 'align-theme' ); ?></small>
            </div>
            <div class="field full">
                <label for="account_email"><?php esc_html_e( 'Email address', 'align-theme' ); ?> <abbr title="required">*</abbr></label>
                <input type="email" class="woocommerce-Input" name="account_email" id="account_email" autocomplete="email" value="<?php echo esc_attr( $user->user_email ); ?>" required>
            </div>
        </div>

        <fieldset style="border:none;padding:0;margin:32px 0 0">
            <legend style="font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;margin-bottom:18px"><?php esc_html_e( 'Password change', 'align-theme' ); ?></legend>
            <div class="form-grid" style="grid-template-columns:1fr">
                <div class="field">
                    <label for="password_current"><?php esc_html_e( 'Current password', 'align-theme' ); ?></label>
                    <input type="password" class="woocommerce-Input" name="password_current" id="password_current" autocomplete="off">
                    <small style="color:#999;font-size:11px"><?php esc_html_e( 'Leave blank to keep unchanged.', 'align-theme' ); ?></small>
                </div>
                <div class="field">
                    <label for="password_1"><?php esc_html_e( 'New password', 'align-theme' ); ?></label>
                    <input type="password" class="woocommerce-Input woocommerce-Input--password" name="password_1" id="password_1" autocomplete="off">
                </div>
                <div class="field">
                    <label for="password_2"><?php esc_html_e( 'Confirm new password', 'align-theme' ); ?></label>
                    <input type="password" class="woocommerce-Input" name="password_2" id="password_2" autocomplete="off">
                </div>
            </div>
        </fieldset>

        <?php do_action( 'woocommerce_edit_account_form' ); ?>

        <div style="margin-top:24px">
            <?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
            <input type="hidden" name="action" value="save_account_details">
            <button type="submit" name="save_account_details" class="btn" style="width:100%"><?php esc_html_e( 'Save changes', 'align-theme' ); ?></button>
        </div>

        <?php do_action( 'woocommerce_edit_account_form_end' ); ?>

    </form>
</div>

<?php do_action( 'woocommerce_after_edit_account_form' ); ?>
