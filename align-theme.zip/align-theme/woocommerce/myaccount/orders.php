<?php
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_orders', $has_orders ); ?>

<div class="account-orders-page">
    <div class="account-section-head">
        <h2><?php esc_html_e( 'Orders', 'align-theme' ); ?></h2>
    </div>

    <?php if ( $has_orders ) : ?>
    <table class="account-orders-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Order', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Date', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Status', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Total', 'align-theme' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'align-theme' ); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php
        foreach ( $customer_orders->orders as $customer_order ) {
            $order      = wc_get_order( $customer_order );
            $item_count = $order->get_item_count() - $order->get_item_count_refunded();
            ?>
            <tr>
                <td>
                    <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>">
                        #<?php echo esc_html( $order->get_order_number() ); ?>
                    </a>
                </td>
                <td><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></td>
                <td><span class="order-status-badge"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span></td>
                <td><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></td>
                <td>
                    <?php
                    $actions = wc_get_account_orders_actions( $order );
                    if ( ! empty( $actions ) ) {
                        foreach ( $actions as $key => $action ) {
                            echo '<a href="' . esc_url( $action['url'] ) . '" class="' . esc_attr( isset( $action['classes'] ) ? implode( ' ', $action['classes'] ) : 'text-link' ) . '">' . esc_html( $action['name'] ) . '</a> ';
                        }
                    }
                    ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

    <?php do_action( 'woocommerce_before_account_orders_pagination' ); ?>

    <?php if ( 1 < $customer_orders->max_num_pages ) : ?>
    <div class="woocommerce-pagination">
        <?php if ( 1 !== $customer_orders->current_page ) : ?>
            <a class="btn btn-outline" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $customer_orders->current_page - 1 ) ); ?>">&larr; <?php esc_html_e( 'Previous', 'align-theme' ); ?></a>
        <?php endif; ?>
        <?php if ( $customer_orders->max_num_pages !== $customer_orders->current_page ) : ?>
            <a class="btn btn-outline" href="<?php echo esc_url( wc_get_endpoint_url( 'orders', $customer_orders->current_page + 1 ) ); ?>"><?php esc_html_e( 'Next', 'align-theme' ); ?> &rarr;</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php else : ?>
    <div class="account-empty">
        <p><?php esc_html_e( "You haven't placed any orders yet.", 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>" class="btn" style="margin-top:16px;display:inline-block">
            <?php esc_html_e( 'Browse Products', 'align-theme' ); ?>
        </a>
    </div>
    <?php endif; ?>
</div>

<?php do_action( 'woocommerce_after_account_orders', $has_orders ); ?>
