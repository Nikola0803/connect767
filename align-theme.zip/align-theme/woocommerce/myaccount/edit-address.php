<?php
defined( 'ABSPATH' ) || exit;
?>

<div class="account-edit-address-page">

    <?php if ( ! $load_address ) : ?>

    <div class="account-section-head" style="margin-bottom:28px">
        <h2><?php esc_html_e( 'Addresses', 'align-theme' ); ?></h2>
    </div>
    <p style="font-size:14px;color:#666;margin-bottom:28px"><?php esc_html_e( 'The following addresses will be used on the checkout page by default.', 'align-theme' ); ?></p>

    <?php do_action( 'woocommerce_before_edit_account_address_form' ); ?>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px">
    <?php foreach ( wc_get_account_addresses() as $name => $address ) :
        $title     = get_option( 'woocommerce_' . $name . '_address_enabled' ) !== 'no' ? $address['title'] : '';
        $addr_html = wc_get_account_address_description( $name );
        ?>
        <div class="form-card" style="position:relative">
            <h3 style="font-size:15px;font-weight:700;margin-bottom:10px"><?php echo esc_html( $title ); ?></h3>
            <?php if ( $addr_html ) : ?>
                <address style="font-style:normal;font-size:14px;color:#555;line-height:1.8"><?php echo wp_kses_post( $addr_html ); ?></address>
            <?php else : ?>
                <p style="font-size:14px;color:#aaa"><?php esc_html_e( 'Not set yet.', 'align-theme' ); ?></p>
            <?php endif; ?>
            <a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', $name ) ); ?>" class="text-link" style="font-size:13px;display:block;margin-top:16px">
                <?php echo $addr_html ? esc_html__( 'Edit', 'align-theme' ) : esc_html__( 'Add', 'align-theme' ); ?> &rarr;
            </a>
        </div>
    <?php endforeach; ?>
    </div>

    <?php do_action( 'woocommerce_after_edit_account_address_form' ); ?>

    <?php else : ?>

    <div class="account-section-head" style="margin-bottom:28px">
        <h2><?php echo esc_html( $title ); ?></h2>
        <a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address' ) ); ?>" class="text-link" style="font-size:13px">&larr; <?php esc_html_e( 'Back', 'align-theme' ); ?></a>
    </div>

    <?php do_action( 'woocommerce_before_edit_account_address_form' ); ?>

    <form method="post" class="form-card" style="max-width:560px">
        <div class="form-grid" style="grid-template-columns:1fr">
            <?php do_action( 'woocommerce_address_to_edit', $load_address ); ?>
        </div>
        <?php wp_nonce_field( 'woocommerce-edit_address', 'woocommerce-edit-address-nonce' ); ?>
        <input type="hidden" name="action" value="edit_address">
        <div style="margin-top:20px">
            <button type="submit" name="save_address" class="btn" style="width:100%"><?php esc_html_e( 'Save address', 'align-theme' ); ?></button>
        </div>
    </form>

    <?php do_action( 'woocommerce_after_edit_account_address_form' ); ?>

    <?php endif; ?>

</div>
