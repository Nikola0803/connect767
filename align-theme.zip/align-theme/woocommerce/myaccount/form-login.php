<?php
/**
 * Login / My Account form — Align Precision
 * Overrides WooCommerce default. Matches design reference 1:1.
 */
defined( 'ABSPATH' ) || exit;

$is_reset = false; // login state only; lost-password handled separately

do_action( 'woocommerce_before_customer_login_form' );
?>

<style>.account-visual{background-image:url('<?php echo esc_url( ALIGN_THEME_URI . '/assets/images/align-forest-hero-v2.png' ); ?>')!important;background-size:cover!important;background-position:80% center!important}</style>
<!-- PAGE HERO -->
<section class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Account access', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Your Align account', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Order information and account details, in one place.', 'align-theme' ); ?></p>
    </div>
</section>

<!-- WC notices (login errors) -->
<?php wc_print_notices(); ?>

<!-- ACCOUNT LAYOUT: visual (left) + form card (right) -->
<section class="account-layout wrap section" style="padding-top:0">

    <div class="account-visual">
        <div>
            <div class="eyebrow" style="color:rgba(255,255,255,.55)"><?php esc_html_e( 'Precision. Consistency. Documentation.', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Research comes first.', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'All products are supplied strictly for qualified in vitro laboratory research.', 'align-theme' ); ?></p>
        </div>
    </div>

    <form class="form-card woocommerce-form woocommerce-form-login login" method="post" novalidate>

        <?php do_action( 'woocommerce_login_form_start' ); ?>

        <h2><?php esc_html_e( 'Welcome back.', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Sign in to access your account.', 'align-theme' ); ?></p>

        <div class="form-grid">

            <label class="field full">
                <?php esc_html_e( 'Email address', 'align-theme' ); ?>
                <input type="text" name="username" id="username" autocomplete="username"
                       value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>"
                       required aria-required="true">
            </label>

            <label class="field full">
                <?php esc_html_e( 'Password', 'align-theme' ); ?>
                <input type="password" name="password" id="password" autocomplete="current-password"
                       required aria-required="true">
            </label>

            <?php do_action( 'woocommerce_login_form' ); ?>

            <?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
            <input type="hidden" name="redirect" value="<?php echo esc_url( wc_get_account_endpoint_url( 'dashboard' ) ); ?>">

            <button type="submit" name="login" value="<?php esc_attr_e( 'Sign in', 'align-theme' ); ?>" class="btn">
                <?php esc_html_e( 'Sign in', 'align-theme' ); ?>
            </button>

        </div>

        <?php do_action( 'woocommerce_login_form_end' ); ?>

        <p class="form-message" role="status"></p>

        <p style="margin-top:22px">
            <a href="<?php echo esc_url( wp_lostpassword_url() ); ?>" class="text-link">
                <?php esc_html_e( 'Forgot your password?', 'align-theme' ); ?>
            </a>
        </p>

        <hr style="border:0;border-top:1px solid var(--line);margin:30px 0">

        <p>
            <a href="<?php echo esc_url( home_url( '/register/' ) ); ?>" class="text-link">
                <?php esc_html_e( 'Create an account →', 'align-theme' ); ?>
            </a>
        </p>

    </form>

</section>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
