<?php
defined( 'ABSPATH' ) || exit;

$notes = $order->get_customer_order_notes();
?>

<div class="view-order-page">
    <div class="account-section-head" style="margin-bottom:28px">
        <h2><?php printf( esc_html__( 'Order #%s', 'align-theme' ), esc_html( $order->get_order_number() ) ); ?></h2>
        <a href="<?php echo esc_url( wc_get_endpoint_url( 'orders' ) ); ?>" class="text-link" style="font-size:13px">&larr; <?php esc_html_e( 'Back to orders', 'align-theme' ); ?></a>
    </div>

    <p style="font-size:14px;color:#666;margin-bottom:28px">
        <?php
        printf(
            esc_html__( 'Order placed on %1$s. Status: %2$s.', 'align-theme' ),
            '<strong>' . esc_html( wc_format_datetime( $order->get_date_created() ) ) . '</strong>',
            '<span class="order-status-badge">' . esc_html( wc_get_order_status_name( $order->get_status() ) ) . '</span>'
        );
        ?>
    </p>

    <?php do_action( 'woocommerce_view_order', $order->get_id() ); ?>

    <?php if ( $notes ) : ?>
    <div class="order-notes" style="margin-top:28px">
        <h3 style="font-size:15px;margin-bottom:14px"><?php esc_html_e( 'Order updates', 'align-theme' ); ?></h3>
        <ol class="woocommerce-OrderUpdates commentlist notes" style="list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:12px">
            <?php foreach ( $notes as $note ) : ?>
            <li class="woocommerce-OrderUpdate comment note" style="background:#f8f8f8;border-radius:10px;padding:14px 16px;font-size:13px">
                <p style="margin:0"><?php echo wp_kses_post( $note->comment_content ); ?></p>
                <small style="color:#aaa;display:block;margin-top:6px"><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $note->comment_date ) ) ); ?></small>
            </li>
            <?php endforeach; ?>
        </ol>
    </div>
    <?php endif; ?>
</div>
