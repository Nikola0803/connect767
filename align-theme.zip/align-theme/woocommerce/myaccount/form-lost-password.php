<?php
/**
 * Lost Password form — Align Precision
 * Overrides WooCommerce default. Matches design reference 1:1.
 */
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_form' );
?>

<!-- PAGE HERO -->
<section class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Account access', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Reset your password', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Order information and account details, in one place.', 'align-theme' ); ?></p>
    </div>
</section>

<style>.account-visual{background-image:url('<?php echo esc_url( ALIGN_THEME_URI . '/assets/images/align-forest-hero-v2.png' ); ?>')!important;background-size:cover!important;background-position:80% center!important}</style>
<?php wc_print_notices(); ?>

<section class="account-layout wrap section" style="padding-top:0">

    <div class="account-visual">
        <div>
            <div class="eyebrow" style="color:rgba(255,255,255,.55)"><?php esc_html_e( 'Precision. Consistency. Documentation.', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Research comes first.', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'All products are supplied strictly for qualified in vitro laboratory research.', 'align-theme' ); ?></p>
        </div>
    </div>

    <form class="form-card woocommerce-ResetPassword lost_reset_password" method="post">

        <h2><?php esc_html_e( 'Forgot your password?', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Enter your email address to request a reset link.', 'align-theme' ); ?></p>

        <div class="form-grid">

            <label class="field full">
                <?php esc_html_e( 'Email address', 'align-theme' ); ?>
                <input type="text" name="user_login" id="user_login" autocomplete="username" required aria-required="true">
            </label>

            <?php do_action( 'woocommerce_lostpassword_form' ); ?>

            <input type="hidden" name="wc_reset_password" value="true">
            <?php wp_nonce_field( 'lost_password', 'woocommerce-lost-password-nonce' ); ?>

            <button type="submit" class="btn" value="<?php esc_attr_e( 'Request reset link', 'align-theme' ); ?>">
                <?php esc_html_e( 'Request reset link', 'align-theme' ); ?>
            </button>

        </div>

        <p class="form-message" role="status"></p>

        <hr style="border:0;border-top:1px solid var(--line);margin:30px 0">

        <p>
            <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'dashboard' ) ); ?>" class="text-link">
                <?php esc_html_e( '← Back to sign in', 'align-theme' ); ?>
            </a>
        </p>

    </form>

</section>

<?php do_action( 'woocommerce_after_lost_password_form' ); ?>
