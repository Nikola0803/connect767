<?php
/**
 * My Account Dashboard — Align theme.
 * Matches design reference account layout.
 */
defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$orders       = wc_get_orders( [ 'customer' => get_current_user_id(), 'limit' => 3, 'status' => wc_get_is_paid_statuses() ] );
?>

<div class="account-dashboard">

    <div class="account-greeting">
        <div class="eyebrow"><?php esc_html_e( 'Welcome back', 'align-theme' ); ?></div>
        <h2><?php echo esc_html( $current_user->display_name ?: $current_user->user_login ); ?></h2>
    </div>

    <div class="account-nav-grid">
        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>" class="account-nav-card">
            <svg class="icon" viewBox="0 0 24 24"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
            <h3><?php esc_html_e( 'My Orders', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'View and track your research orders.', 'align-theme' ); ?></p>
        </a>
        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-address' ) ); ?>" class="account-nav-card">
            <svg class="icon" viewBox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
            <h3><?php esc_html_e( 'Addresses', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Manage billing and shipping addresses.', 'align-theme' ); ?></p>
        </a>
        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'edit-account' ) ); ?>" class="account-nav-card">
            <svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="7" r="3.5"/><path d="M5 21v-2a7 7 0 0114 0v2"/></svg>
            <h3><?php esc_html_e( 'Account Details', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Update your name, email, and password.', 'align-theme' ); ?></p>
        </a>
        <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'payment-methods' ) ); ?>" class="account-nav-card">
            <svg class="icon" viewBox="0 0 24 24"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><path d="M1 10h22"/></svg>
            <h3><?php esc_html_e( 'Payment Methods', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Manage your saved payment methods.', 'align-theme' ); ?></p>
        </a>
        <a href="<?php echo esc_url( home_url( '/wishlist/' ) ); ?>" class="account-nav-card">
            <svg class="icon" viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"/></svg>
            <h3><?php esc_html_e( 'Saved Products', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Your saved research compounds.', 'align-theme' ); ?></p>
        </a>
        <a href="<?php echo esc_url( wc_logout_url() ); ?>" class="account-nav-card" style="border-color:transparent;background:transparent">
            <svg class="icon" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
            <h3><?php esc_html_e( 'Sign Out', 'align-theme' ); ?></h3>
            <p><?php esc_html_e( 'Sign out of your account.', 'align-theme' ); ?></p>
        </a>
    </div>

    <?php if ( ! empty( $orders ) ) : ?>
    <div class="account-recent-orders" style="margin-top:48px">
        <div class="section-head" style="margin-bottom:20px">
            <h3><?php esc_html_e( 'Recent Orders', 'align-theme' ); ?></h3>
            <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>" class="text-link"><?php esc_html_e( 'View all →', 'align-theme' ); ?></a>
        </div>
        <div class="order-table-wrap">
            <table class="woocommerce-orders-table" style="width:100%;border-collapse:collapse;font-size:14px">
                <thead>
                    <tr>
                        <th style="padding:12px 16px;text-align:left;border-bottom:1px solid var(--line);font-size:11px;text-transform:uppercase;letter-spacing:.1em"><?php esc_html_e( 'Order', 'align-theme' ); ?></th>
                        <th style="padding:12px 16px;text-align:left;border-bottom:1px solid var(--line);font-size:11px;text-transform:uppercase;letter-spacing:.1em"><?php esc_html_e( 'Date', 'align-theme' ); ?></th>
                        <th style="padding:12px 16px;text-align:left;border-bottom:1px solid var(--line);font-size:11px;text-transform:uppercase;letter-spacing:.1em"><?php esc_html_e( 'Status', 'align-theme' ); ?></th>
                        <th style="padding:12px 16px;text-align:right;border-bottom:1px solid var(--line);font-size:11px;text-transform:uppercase;letter-spacing:.1em"><?php esc_html_e( 'Total', 'align-theme' ); ?></th>
                        <th style="padding:12px 16px;border-bottom:1px solid var(--line)"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $orders as $order ) : ?>
                    <tr>
                        <td style="padding:14px 16px;border-bottom:1px solid var(--line)">
                            <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="text-link">#<?php echo esc_html( $order->get_order_number() ); ?></a>
                        </td>
                        <td style="padding:14px 16px;border-bottom:1px solid var(--line);color:var(--muted)">
                            <?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?>
                        </td>
                        <td style="padding:14px 16px;border-bottom:1px solid var(--line)">
                            <span class="tag" style="font-size:11px"><?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></span>
                        </td>
                        <td style="padding:14px 16px;border-bottom:1px solid var(--line);text-align:right;font-weight:600">
                            <?php echo wp_kses_post( $order->get_formatted_order_total() ); ?>
                        </td>
                        <td style="padding:14px 16px;border-bottom:1px solid var(--line);text-align:right">
                            <a href="<?php echo esc_url( $order->get_view_order_url() ); ?>" class="text-link" style="font-size:12px"><?php esc_html_e( 'View', 'align-theme' ); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>

</div>

<?php
// Default WooCommerce dashboard hooks
do_action( 'woocommerce_account_dashboard' );
do_action( 'woocommerce_after_account_dashboard' );
?>
