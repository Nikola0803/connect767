<?php
/**
 * Register form — Align theme. Matches design 1:1 (account-layout: dark visual + form card).
 */
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_customer_login_form' );
?>

<style>.account-visual{background-image:url('<?php echo esc_url( ALIGN_THEME_URI . '/assets/images/align-forest-hero-v2.png' ); ?>')!important;background-size:cover!important;background-position:80% center!important}</style>

<section class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Account access', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Create your account', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Order information and account details, in one place.', 'align-theme' ); ?></p>
    </div>
</section>

<?php wc_print_notices(); ?>

<section class="account-layout wrap section" style="padding-top:0">

    <div class="account-visual">
        <div>
            <div class="eyebrow" style="color:rgba(255,255,255,.55)"><?php esc_html_e( 'Precision. Consistency. Documentation.', 'align-theme' ); ?></div>
            <h2><?php esc_html_e( 'Research comes first.', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'All products are supplied strictly for qualified in vitro laboratory research.', 'align-theme' ); ?></p>
        </div>
    </div>

    <form class="form-card woocommerce-form woocommerce-form-register register" method="post" novalidate>

        <?php do_action( 'woocommerce_register_form_start' ); ?>

        <h2><?php esc_html_e( 'Create your account', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Enter your details to get started.', 'align-theme' ); ?></p>

        <div class="form-grid">

            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
            <label class="field full">
                <?php esc_html_e( 'Username', 'align-theme' ); ?>
                <input
                    type="text"
                    name="username"
                    id="reg_username"
                    value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( sanitize_user( wp_unslash( $_POST['username'] ) ) ) : ''; ?>"
                    autocomplete="username"
                    required
                    aria-required="true"
                >
            </label>
            <?php endif; ?>

            <label class="field full">
                <?php esc_html_e( 'Email address', 'align-theme' ); ?>
                <input
                    type="email"
                    name="email"
                    id="reg_email"
                    value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( sanitize_email( wp_unslash( $_POST['email'] ) ) ) : ''; ?>"
                    autocomplete="email"
                    required
                    aria-required="true"
                >
            </label>

            <?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
            <label class="field full">
                <?php esc_html_e( 'Password', 'align-theme' ); ?>
                <input
                    type="password"
                    name="password"
                    id="reg_password"
                    autocomplete="new-password"
                    required
                    aria-required="true"
                >
            </label>
            <?php else : ?>
            <p class="form-message" style="grid-column:1/-1;font-size:13px"><?php esc_html_e( 'A password will be emailed to you.', 'align-theme' ); ?></p>
            <?php endif; ?>

            <?php do_action( 'woocommerce_register_form' ); ?>

            <?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>

            <label class="check-field full" style="display:flex;gap:10px;align-items:flex-start">
                <input type="checkbox" name="align_ruo_confirm" required style="margin-top:2px;flex-shrink:0">
                <span><?php printf(
                    esc_html__( 'I am 19+ and confirm I am accessing this site in a qualified research capacity. I agree to the %s and %s.', 'align-theme' ),
                    '<a href="' . esc_url( home_url( '/terms-conditions/' ) ) . '" target="_blank">Terms & Conditions</a>',
                    '<a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '" target="_blank">Privacy Policy</a>'
                ); ?></span>
            </label>

            <button type="submit" name="register" value="<?php esc_attr_e( 'Create Account', 'align-theme' ); ?>" class="btn full">
                <?php esc_html_e( 'Create Account', 'align-theme' ); ?>
            </button>

        </div>

        <?php do_action( 'woocommerce_register_form_end' ); ?>

        <p class="form-message" role="status"></p>

        <hr style="border:0;border-top:1px solid var(--line);margin:30px 0">

        <p>
            <?php esc_html_e( 'Already have an account?', 'align-theme' ); ?>
            <a href="<?php echo esc_url( wc_get_account_endpoint_url( 'dashboard' ) ); ?>" class="text-link">
                <?php esc_html_e( 'Sign in →', 'align-theme' ); ?>
            </a>
        </p>

    </form>

</section>

<?php do_action( 'woocommerce_after_customer_login_form' ); ?>
