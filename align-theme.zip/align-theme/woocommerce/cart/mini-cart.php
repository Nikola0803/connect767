<?php
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_mini_cart' );

if ( ! WC()->cart->is_empty() ) : ?>

<ul class="woocommerce-mini-cart cart_list product_list_widget <?php echo esc_attr( $args['list_class'] ); ?>">
    <?php
    do_action( 'woocommerce_before_mini_cart_contents' );

    foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
        $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
        $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

        if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
            $product_name      = apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key );
            $thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image( 'thumbnail' ), $cart_item, $cart_item_key );
            $product_price     = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
            $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
            $max_qty           = $_product->get_max_purchase_quantity();
        ?>
        <li class="woocommerce-mini-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key ) ); ?>">

            <?php echo apply_filters( 'woocommerce_cart_item_remove_link', sprintf(
                '<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">×</a>',
                esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                esc_attr__( 'Remove this item', 'align-theme' ),
                esc_attr( $product_id ),
                esc_attr( $cart_item_key ),
                esc_attr( $_product->get_sku() )
            ), $cart_item_key ); ?>

            <?php if ( empty( $product_permalink ) ) : ?>
                <?php echo $thumbnail; ?>
            <?php else : ?>
                <a href="<?php echo esc_url( $product_permalink ); ?>"><?php echo $thumbnail; ?></a>
            <?php endif; ?>

            <div class="mini-cart-item-details">
                <div class="mini-cart-item-name">
                    <?php if ( empty( $product_permalink ) ) : ?>
                        <?php echo wp_kses_post( $product_name ); ?>
                    <?php else : ?>
                        <a href="<?php echo esc_url( $product_permalink ); ?>"><?php echo wp_kses_post( $product_name ); ?></a>
                    <?php endif; ?>
                </div>

                <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>

                <div class="mini-cart-item-row">
                    <!-- Qty stepper (K1) -->
                    <div class="qty-stepper mini-cart-stepper"
                         data-key="<?php echo esc_attr( $cart_item_key ); ?>"
                         data-nonce="<?php echo esc_attr( wp_create_nonce( 'align_nonce' ) ); ?>">
                        <button type="button" class="qty-minus" aria-label="-">−</button>
                        <span class="qty-display"><?php echo esc_html( $cart_item['quantity'] ); ?></span>
                        <button type="button" class="qty-plus" aria-label="+" <?php echo ( $max_qty > 0 && $cart_item['quantity'] >= $max_qty ) ? 'disabled' : ''; ?>>+</button>
                    </div>
                    <span class="mini-cart-item-price"><?php echo wp_kses_post( $product_price ); ?></span>
                </div>
            </div>
        </li>
        <?php }
    }

    do_action( 'woocommerce_mini_cart_contents' );
    ?>
</ul>

<p class="woocommerce-mini-cart__total total">
    <strong><?php esc_html_e( 'Subtotal', 'align-theme' ); ?>:</strong>
    <?php echo WC()->cart->get_cart_subtotal(); ?>
</p>

<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>

<p class="woocommerce-mini-cart__buttons buttons">
    <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="button wc-forward cart-btn-view"><?php esc_html_e( 'View cart', 'align-theme' ); ?></a>
    <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" class="button checkout wc-forward cart-btn-checkout"><?php esc_html_e( 'Checkout', 'align-theme' ); ?></a>
</p>

<?php do_action( 'woocommerce_widget_shopping_cart_after_buttons' ); ?>

<?php else : ?>
    <p class="woocommerce-mini-cart__empty-message"><?php esc_html_e( 'No products in the cart.', 'align-theme' ); ?></p>
<?php endif; ?>

<?php do_action( 'woocommerce_after_mini_cart' ); ?>
