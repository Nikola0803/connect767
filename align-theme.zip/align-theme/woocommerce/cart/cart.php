<?php
defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_cart' );

// Free-shipping threshold
$free_ship_threshold = 400;
$cart_total          = WC()->cart->get_subtotal();
$free_ship_remaining = max( 0, $free_ship_threshold - $cart_total );
$free_ship_pct       = min( 100, round( ( $cart_total / $free_ship_threshold ) * 100 ) );
$free_ship_unlocked  = $cart_total >= $free_ship_threshold;
?>

<div class="wrap cart-page" style="padding-top:40px;padding-bottom:80px">

    <div class="eyebrow" style="margin-bottom:8px"><?php esc_html_e( 'Align / Your cart', 'align-theme' ); ?></div>
    <h1 style="font-size:clamp(32px,5vw,52px);margin-bottom:32px"><?php esc_html_e( 'Your research cart.', 'align-theme' ); ?></h1>

    <!-- Free-shipping bar -->
    <div class="cart-freeship-bar" style="margin-bottom:28px">
        <?php if ( $free_ship_unlocked ) : ?>
        <p class="cart-freeship-msg cart-freeship-unlocked">
            🎉 <?php esc_html_e( 'Free shipping unlocked!', 'align-theme' ); ?>
        </p>
        <?php else : ?>
        <p class="cart-freeship-msg">
            <?php printf( esc_html__( 'Spend %s more for free shipping.', 'align-theme' ), '<strong>' . wc_price( $free_ship_remaining ) . '</strong>' ); ?>
        </p>
        <?php endif; ?>
        <div class="cart-freeship-track">
            <div class="cart-freeship-fill" style="width:<?php echo esc_attr( $free_ship_pct ); ?>%"></div>
        </div>
    </div>

    <div class="cart-layout">

        <!-- Cart items table -->
        <div class="cart-items-col">
            <form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
                <?php do_action( 'woocommerce_before_cart_table' ); ?>

                <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="product-thumbnail"></th>
                            <th class="product-name"><?php esc_html_e( 'Product', 'align-theme' ); ?></th>
                            <th class="product-price"><?php esc_html_e( 'Price', 'align-theme' ); ?></th>
                            <th class="product-quantity"><?php esc_html_e( 'Qty', 'align-theme' ); ?></th>
                            <th class="product-subtotal"><?php esc_html_e( 'Subtotal', 'align-theme' ); ?></th>
                            <th class="product-remove"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php do_action( 'woocommerce_before_cart_contents' ); ?>

                        <?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) :
                            $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                            $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

                            if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) :
                                $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
                                $thumbnail         = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image( 'align-card' ), $cart_item, $cart_item_key );
                                $product_price     = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key );
                                $product_subtotal  = apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key );
                                $max_qty           = $_product->get_max_purchase_quantity();
                        ?>
                        <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
                            <td class="product-thumbnail">
                                <?php if ( ! $product_permalink ) : ?>
                                    <?php echo $thumbnail; ?>
                                <?php else : ?>
                                    <a href="<?php echo esc_url( $product_permalink ); ?>"><?php echo $thumbnail; ?></a>
                                <?php endif; ?>
                            </td>
                            <td class="product-name">
                                <?php if ( ! $product_permalink ) : ?>
                                    <?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) ); ?>
                                <?php else : ?>
                                    <a href="<?php echo esc_url( $product_permalink ); ?>"><?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) ); ?></a>
                                <?php endif; ?>
                                <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
                            </td>
                            <td class="product-price">
                                <?php echo wp_kses_post( $product_price ); ?>
                            </td>
                            <td class="product-quantity">
                                <div class="qty-stepper">
                                    <button type="button" class="qty-minus" aria-label="<?php esc_attr_e( 'Decrease quantity', 'align-theme' ); ?>">−</button>
                                    <input
                                        type="number"
                                        class="qty input-text"
                                        name="cart[<?php echo esc_attr( $cart_item_key ); ?>][qty]"
                                        value="<?php echo esc_attr( $cart_item['quantity'] ); ?>"
                                        min="1"
                                        <?php echo $max_qty > 0 ? 'max="' . esc_attr( $max_qty ) . '"' : ''; ?>
                                        step="1"
                                    >
                                    <button type="button" class="qty-plus" aria-label="<?php esc_attr_e( 'Increase quantity', 'align-theme' ); ?>">+</button>
                                </div>
                            </td>
                            <td class="product-subtotal">
                                <?php echo wp_kses_post( $product_subtotal ); ?>
                            </td>
                            <td class="product-remove">
                                <?php echo apply_filters(
                                    'woocommerce_cart_item_remove_link',
                                    sprintf(
                                        '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-cart_item_key="%s">×</a>',
                                        esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                                        esc_attr__( 'Remove this item', 'align-theme' ),
                                        esc_attr( $product_id ),
                                        esc_attr( $cart_item_key )
                                    ),
                                    $cart_item_key
                                ); ?>
                            </td>
                        </tr>
                        <?php endif; endforeach; ?>

                        <?php do_action( 'woocommerce_cart_contents' ); ?>

                        <tr>
                            <td colspan="6" class="actions">
                                <?php if ( wc_coupons_enabled() ) : ?>
                                <div class="coupon">
                                    <input type="text" name="coupon_code" class="input-text" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Coupon code', 'align-theme' ); ?>">
                                    <button type="submit" class="btn outline small" name="apply_coupon" value="<?php esc_attr_e( 'Apply coupon', 'align-theme' ); ?>"><?php esc_html_e( 'Apply', 'align-theme' ); ?></button>
                                    <?php do_action( 'woocommerce_cart_coupon' ); ?>
                                </div>
                                <?php endif; ?>
                                <button type="submit" class="btn outline small" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'align-theme' ); ?>"><?php esc_html_e( 'Update cart', 'align-theme' ); ?></button>
                                <?php do_action( 'woocommerce_cart_actions' ); ?>
                                <?php wp_nonce_field( 'woocommerce-cart', '_wpnonce' ); ?>
                            </td>
                        </tr>

                        <?php do_action( 'woocommerce_after_cart_contents' ); ?>
                    </tbody>
                </table>

                <?php do_action( 'woocommerce_after_cart_table' ); ?>
            </form>

            <!-- Order note -->
            <div class="cart-order-note" style="margin-top:20px">
                <label for="order_comments" style="font-size:13px;font-weight:600;display:block;margin-bottom:6px"><?php esc_html_e( 'Order note (optional)', 'align-theme' ); ?></label>
                <textarea id="order_comments" name="order_comments" rows="3" class="input-text" placeholder="<?php esc_attr_e( 'Notes about your order, e.g. special instructions.', 'align-theme' ); ?>"></textarea>
            </div>
        </div>

        <!-- Cart totals -->
        <div class="cart-totals-col">
            <?php do_action( 'woocommerce_before_cart_collaterals' ); ?>
            <div class="cart-collaterals">
                <?php do_action( 'woocommerce_cart_collaterals' ); ?>
            </div>
        </div>

    </div><!-- .cart-layout -->
</div>

<?php do_action( 'woocommerce_after_cart' ); ?>

<script>
(function(){
    document.querySelectorAll('.qty-stepper').forEach(function(wrap){
        var minus = wrap.querySelector('.qty-minus');
        var plus  = wrap.querySelector('.qty-plus');
        var input = wrap.querySelector('input.qty');
        if(!minus||!plus||!input) return;
        minus.addEventListener('click', function(){
            var v = parseInt(input.value,10)||1;
            if(v>1){ input.value = v-1; input.dispatchEvent(new Event('change')); }
        });
        plus.addEventListener('click', function(){
            var v = parseInt(input.value,10)||1;
            var max = parseInt(input.max,10)||9999;
            if(v<max){ input.value = v+1; input.dispatchEvent(new Event('change')); }
        });
    });
})();
</script>
