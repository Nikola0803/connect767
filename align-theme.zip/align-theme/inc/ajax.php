<?php
defined( 'ABSPATH' ) || exit;

// Add to cart via AJAX (both logged-in and guest)
add_action( 'wp_ajax_align_add_to_cart',        'align_ajax_add_to_cart' );
add_action( 'wp_ajax_nopriv_align_add_to_cart', 'align_ajax_add_to_cart' );

function align_ajax_add_to_cart() {
    check_ajax_referer( 'align_nonce', 'nonce' );

    $product_id   = absint( $_POST['product_id'] ?? 0 );
    $variation_id = absint( $_POST['variation_id'] ?? 0 );
    $quantity     = absint( $_POST['quantity'] ?? 1 );
    $variation    = isset( $_POST['variation'] ) ? (array) $_POST['variation'] : [];

    if ( ! $product_id ) {
        wp_send_json_error( [ 'message' => __( 'Invalid product.', 'align-theme' ) ] );
    }

    $added = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation );

    if ( $added ) {
        wp_send_json_success( [
            'count'   => WC()->cart->get_cart_contents_count(),
            'total'   => WC()->cart->get_cart_total(),
            'message' => __( 'Added to cart.', 'align-theme' ),
        ] );
    } else {
        wp_send_json_error( [ 'message' => __( 'Could not add to cart.', 'align-theme' ) ] );
    }
}

// Get cart HTML fragment for drawer
add_action( 'wp_ajax_align_get_cart',        'align_ajax_get_cart' );
add_action( 'wp_ajax_nopriv_align_get_cart', 'align_ajax_get_cart' );

function align_ajax_get_cart() {
    check_ajax_referer( 'align_nonce', 'nonce' );

    ob_start();
    woocommerce_mini_cart();
    $mini_cart = ob_get_clean();

    wp_send_json_success( [
        'cart_html' => $mini_cart,
        'count'     => WC()->cart->get_cart_contents_count(),
        'total'     => WC()->cart->get_cart_total(),
    ] );
}

// ── Email popup capture (S40 server endpoint replacement) ────
add_action( 'wp_ajax_align_popup_capture',        'align_ajax_popup_capture' );
add_action( 'wp_ajax_nopriv_align_popup_capture', 'align_ajax_popup_capture' );

function align_ajax_popup_capture() {
    check_ajax_referer( 'align_popup_capture', 'nonce' );

    $email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
    if ( ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => __( 'Please enter a valid email address.', 'align-theme' ) ] );
    }

    // Save to DB table (S40 compat) — create if missing
    global $wpdb;
    $table = $wpdb->prefix . 'align_email_captures';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        $wpdb->query( "CREATE TABLE IF NOT EXISTS $table (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(200) NOT NULL,
            source VARCHAR(100) DEFAULT 'popup',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) " . $wpdb->get_charset_collate() );
    }
    $wpdb->replace( $table, [ 'email' => $email, 'source' => 'popup' ], [ '%s', '%s' ] );

    wp_send_json_success( [ 'message' => __( 'Subscribed!', 'align-theme' ) ] );
}

// ── Live search (S6) ─────────────────────────────────────────
add_action( 'wp_ajax_align_live_search',        'align_ajax_live_search' );
add_action( 'wp_ajax_nopriv_align_live_search', 'align_ajax_live_search' );

function align_ajax_live_search() {
    check_ajax_referer( 'align_nonce', 'nonce' );

    $q = sanitize_text_field( wp_unslash( $_POST['q'] ?? '' ) );
    if ( strlen( $q ) < 2 ) {
        wp_send_json_success( [ 'html' => '' ] );
    }

    $args = [
        'post_type'      => 'product',
        'post_status'    => 'publish',
        's'              => $q,
        'posts_per_page' => 8,
        'fields'         => 'ids',
    ];
    $ids = get_posts( $args );

    if ( empty( $ids ) ) {
        wp_send_json_success( [ 'html' => '<p class="search-empty">' . esc_html__( 'No products found.', 'align-theme' ) . '</p>' ] );
    }

    ob_start();
    foreach ( $ids as $id ) {
        $p = wc_get_product( $id );
        if ( ! $p ) continue;
        $img = wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) ?: wc_placeholder_img_src( 'thumbnail' );
        ?>
        <a class="search-result-item" href="<?php echo esc_url( $p->get_permalink() ); ?>">
            <img src="<?php echo esc_url( $img ); ?>" alt="" width="44" height="44" loading="lazy">
            <div>
                <strong><?php echo esc_html( $p->get_name() ); ?></strong>
                <span><?php echo wp_kses_post( $p->get_price_html() ); ?></span>
            </div>
        </a>
        <?php
    }
    $html = ob_get_clean();
    wp_send_json_success( [ 'html' => $html ] );
}

// Remove from cart
add_action( 'wp_ajax_align_remove_cart_item',        'align_ajax_remove_cart_item' );
add_action( 'wp_ajax_nopriv_align_remove_cart_item', 'align_ajax_remove_cart_item' );

function align_ajax_remove_cart_item() {
    check_ajax_referer( 'align_nonce', 'nonce' );

    $cart_item_key = sanitize_text_field( $_POST['key'] ?? '' );
    if ( $cart_item_key && WC()->cart->remove_cart_item( $cart_item_key ) ) {
        wp_send_json_success( [
            'count' => WC()->cart->get_cart_contents_count(),
            'total' => WC()->cart->get_cart_total(),
        ] );
    } else {
        wp_send_json_error();
    }
}
