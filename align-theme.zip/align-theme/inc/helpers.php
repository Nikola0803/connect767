<?php
defined( 'ABSPATH' ) || exit;

function align_logo() {
    if ( has_custom_logo() ) {
        $logo_id  = get_theme_mod( 'custom_logo' );
        $logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
    } else {
        $logo_url = ALIGN_THEME_URI . '/assets/images/align-logo.webp';
    }
    return esc_url( $logo_url );
}

function align_get_coa( $product_id ) {
    return [
        'url'    => get_post_meta( $product_id, '_coa_pdf_testides',   true ),
        'batch'  => get_post_meta( $product_id, '_coa_batch_testides', true ),
        'purity' => get_post_meta( $product_id, '_coa_purity_testides', true ),
    ];
}

function align_cart_count() {
    return WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
}

function align_format_price( $price ) {
    return wc_price( $price );
}

function align_get_category_image( $term_id ) {
    $thumb_id = get_term_meta( $term_id, 'thumbnail_id', true );
    if ( $thumb_id ) {
        return wp_get_attachment_image_url( $thumb_id, 'align-card' );
    }
    return '';
}

function align_breadcrumbs() {
    if ( function_exists( 'woocommerce_breadcrumb' ) && ( is_woocommerce() || is_singular( 'product' ) ) ) {
        woocommerce_breadcrumb( [
            'delimiter'   => '<span class="sep"> / </span>',
            'wrap_before' => '<nav class="breadcrumbs" aria-label="Breadcrumb">',
            'wrap_after'  => '</nav>',
            'before'      => '',
            'after'       => '',
        ] );
        return;
    }
    echo '<nav class="breadcrumbs" aria-label="Breadcrumb">';
    echo '<a href="' . home_url( '/' ) . '">' . __( 'Home', 'align-theme' ) . '</a>';
    if ( is_singular() ) {
        echo '<span class="sep"> / </span><span>' . get_the_title() . '</span>';
    }
    echo '</nav>';
}

function align_render_product_card( $product, $args = [] ) {
    if ( ! $product instanceof WC_Product ) {
        $product = wc_get_product( $product );
    }
    if ( ! $product ) return;
    get_template_part( 'woocommerce/content-product', null, [ 'product' => $product ] );
}
