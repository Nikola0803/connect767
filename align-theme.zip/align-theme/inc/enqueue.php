<?php
defined( 'ABSPATH' ) || exit;

add_action( 'wp_enqueue_scripts', function() {
    $v = ALIGN_THEME_VERSION;

    wp_enqueue_style(
        'align-fonts',
        'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;750&display=swap',
        [],
        null
    );

    wp_enqueue_style( 'align-theme', ALIGN_THEME_URI . '/assets/css/theme.css', [ 'align-fonts' ], $v );

    if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) {
        wp_enqueue_style( 'align-woocommerce', ALIGN_THEME_URI . '/assets/css/woocommerce.css', [ 'align-theme' ], $v );
    }

    wp_enqueue_script( 'align-theme', ALIGN_THEME_URI . '/assets/js/theme.js', [], $v, true );

    if ( is_singular( 'product' ) ) {
        wp_enqueue_script( 'align-product', ALIGN_THEME_URI . '/assets/js/product.js', [ 'align-theme' ], $v, true );
        wp_enqueue_script( 'align-variations', ALIGN_THEME_URI . '/assets/js/variations.js', [ 'jquery', 'wc-add-to-cart-variation' ], $v, true );
    }

    wp_localize_script( 'align-theme', 'alignData', [
        'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'align_nonce' ),
        'cartUrl'   => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/cart/' ),
        'shopUrl'   => function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ),
        'currency'  => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '$',
        'siteUrl'   => get_site_url(),
        'isLoggedIn'=> is_user_logged_in() ? 1 : 0,
    ] );
} );

// Remove default WooCommerce styles — we handle styling ourselves
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

// Late override — must load AFTER Glozin/Elementor plugin CSS (priority 999)
add_action( 'wp_head', function() {
    echo '<style id="align-last-overrides">
/* ===== CSS variable overrides — ALL green → black/neutral ===== */
:root{--ink:#111111!important;--muted:#666666!important;--forest:#0a0a0a!important;--forest-2:#111111!important;--green:#0a0a0a!important;--sage:#f5f5f5!important;--line:#e2e2e2!important}
html body{color:#111111}
/* ===== TOPBAR (hardcoded #062f2b in precision layer) ===== */
.topbar{background:#0a0a0a!important}
/* ===== HERO ===== */
.hero{background:#0a0a0a!important}
.strong-hero-art{background:radial-gradient(ellipse at 55% 50%,#2a2a2a 0,#111 55%,#0a0a0a 85%)!important}
.hero-art-word{color:rgba(255,255,255,.06)!important}
.hero-art-caption{color:rgba(255,255,255,.35)!important}
.hero h1 span,.hero h1 em{color:#fff!important}
.hero p{color:rgba(255,255,255,.68)!important}
.hp-0,.hp-2{background:#e5e5e5!important}
.hero-product{background:#eeeeee!important}
/* ===== TICKER ===== */
.ticker-icon{background:#f0f0f0!important;color:#333!important;border-color:#e0e0e0!important}
/* ===== PRODUCT CARDS ===== */
.product-media{background:#f5f5f5!important}
.card-document{background:#0a0a0a!important}
.card-arrow{background:#0a0a0a!important;color:#fff!important}
.save-product.saved{background:#0a0a0a!important}
.image-view{background:linear-gradient(to top,rgba(0,0,0,.75),transparent)!important}
/* ===== CATEGORY TILES (shop pages) ===== */
.category-tile{background:#0a0a0a!important;color:#fff!important}
.category-tile:nth-child(even){background:#1a1a1a!important}
.category-tile:first-child{background:#f5f5f5!important;color:#111!important}
.category-tile small{color:rgba(255,255,255,.6)!important}
.category-tile:first-child small{color:#555!important}
/* ===== EYEBROWS ===== */
.eyebrow,.section-eyebrow{color:#555!important}
.quality-inner .eyebrow,.proof-tile .eyebrow,.welcome-band .eyebrow{color:rgba(255,255,255,.55)!important}
/* ===== QUALITY BAND ===== */
.quality-band{background:#0a0a0a!important}
.strong-report{color:#111!important;box-shadow:12px 12px 0 #333!important}
.strong-report h3,.strong-report strong{color:#111!important}
.strong-report p{color:#666!important}
.strong-report .btn{background:#0a0a0a!important;color:#fff!important}
/* ===== PROOF SECTION ===== */
.proof-tile{background:#f5f5f5!important}
.proof-tile.main{background:#f0f0f0!important}
.proof-tile.dark{background:#111!important}
.proof-title h2 span{color:#0a0a0a!important}
.proof-bottom{background:#0a0a0a!important}
/* ===== ABOUT SPLIT ===== */
.strong-about-art{background:#f0f0f0!important}
/* ===== WHY SECTION ===== */
.why-section{background:#f5f5f5!important}
.why-grid .icon{color:#0a0a0a!important}
/* ===== FAQ ===== */
.faq-list details{background:#f5f5f5!important}
/* ===== WELCOME BAND ===== */
.welcome-band{background:#0a0a0a!important}
.welcome-band .eyebrow{color:rgba(255,255,255,.5)!important}
.welcome-band .btn{background:#fff!important;color:#0a0a0a!important}
/* ===== MEGA MENU LAYOUT — 4 columns matching design ===== */
.mega .wrap{grid-template-columns:repeat(4,1fr)!important}
.mega-promo{background:#0a0a0a!important;color:#fff!important;display:flex!important;flex-direction:column!important;justify-content:space-between!important}
.mega-promo .eyebrow{color:rgba(255,255,255,.45)!important}
.mega-promo h3{color:#fff!important;font-size:22px!important;line-height:1.2!important;margin:8px 0 0!important}
.mega-promo p.small{color:rgba(255,255,255,.6)!important;font-size:12px!important;line-height:1.8!important}
.mega-promo>a{color:#fff!important;font-size:13px!important;font-weight:600!important;margin-top:auto!important;padding-top:18px!important;border-top:1px solid rgba(255,255,255,.12)!important;display:block!important}
.mega-promo>a:hover{color:rgba(255,255,255,.7)!important}
/* ===== MEGA MENU MORE LABEL ===== */
.mega-more-label{font-size:10px!important;letter-spacing:.12em!important;text-transform:uppercase!important;color:#999!important;margin:10px 0 2px!important;pointer-events:none!important}
/* ===== NAV / LINKS ===== */
.bag-count{background:#0a0a0a!important}
.nav-links>a:hover{color:#555!important}
.mega a:hover{color:#333!important}
/* ===== GLOZIN overlays ===== */
#search-overlay[hidden],#cart-overlay[hidden],html .overlay[hidden]{display:none!important;visibility:hidden!important;pointer-events:none!important}
/* ===== FILTER PILLS ===== */
.align-filter__pill.is-active,.align-filter__pill.is-active:hover{background:#0a0a0a!important;background-color:#0a0a0a!important;color:#fff!important;border-color:#0a0a0a!important}
.align-filter__pill:hover{background:rgba(0,0,0,.08)!important;background-color:rgba(0,0,0,.08)!important}
.align-filter__pill.is-active .align-filter__count{background:rgba(255,255,255,.2)!important}
/* ===== VARIATION FORM — hide native WC table, show chip UI ===== */
.purchase-row-wrapper .variations{display:none!important}
.purchase-row-wrapper .woocommerce-variation-add-to-cart{display:flex!important;gap:10px!important;margin-top:20px!important}
.purchase-row-wrapper .quantity{display:none!important}
.purchase-row-wrapper .single_add_to_cart_button{flex:1!important}
/* Simple product qty row */
.purchase-row-wrapper .cart:not(.variations_form) .quantity{display:none!important}
/* ===== WOOCOMMERCE ADD TO CART ===== */
.single_add_to_cart_button,.single_add_to_cart_button.button,.single_add_to_cart_button.button.alt,
html .woocommerce button.single_add_to_cart_button,html .woocommerce a.button.add_to_cart_button,
html .woocommerce a.button.ajax_add_to_cart,html .product .add_to_cart_button,
html .glozin-product-actions .button,.align-msatc__btn,.align-msatc__btn.button{
background:#0a0a0a!important;background-color:#0a0a0a!important;color:#fff!important;
border-radius:99px!important;border:0!important;letter-spacing:0!important}
.single_add_to_cart_button:hover,html .woocommerce button.single_add_to_cart_button:hover,
.align-msatc__btn:hover{background:#333!important;background-color:#333!important;color:#fff!important}
/* Glozin feature chips */
.gz-product-feature,.align-msatc__feature,html [class*="gz-feature"]{background:#f0f0f0!important;color:#111!important;border-color:#e0e0e0!important}
/* Lime-green computed style override */
[style*="84cc16"],[style*="132, 204"]{background-color:#0a0a0a!important;color:#fff!important}
/* ===== COLLECTION EDIT — force 2-column layout + correct padding ===== */
.collection-edit{padding-top:45px!important}
.edit-layout{grid-template-columns:1fr 1.4fr!important;display:grid!important;align-items:start!important}
.edit-products .product-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}
/* Force explicit 2x2 placement — auto-flow skips col 1 without this */
.edit-products .product-card:nth-child(1){grid-column:1!important;grid-row:1!important}
.edit-products .product-card:nth-child(2){grid-column:2!important;grid-row:1!important}
.edit-products .product-card:nth-child(3){grid-column:1!important;grid-row:2!important}
.edit-products .product-card:nth-child(4){grid-column:2!important;grid-row:2!important}
/* ===== REMIX PILLS ===== */
.remix-pill-0{grid-column:1/3!important}
/* ===== TOPBAR COPY-CODE BUTTON ===== */
.topbar-code{background:rgba(255,255,255,.12)!important;color:rgba(255,255,255,.9)!important;border:1px solid rgba(255,255,255,.2)!important;border-radius:99px!important;padding:4px 14px!important;font-size:11px!important;font-weight:600!important;cursor:pointer!important;transition:background .15s!important}
.topbar-code:hover{background:rgba(255,255,255,.22)!important}
.topbar-code span{color:rgba(255,255,255,.65)!important}
/* ===== CATALOG — horizontal chip layout matching design ===== */
/* active chip: black (green→black) */
.catalog-category-tabs a.active{background:#0a0a0a!important;color:#fff!important;border-color:#0a0a0a!important}
.catalog-category-tabs a:hover:not(.active){background:#e8e8e8!important}
/* 4-column product grid */
.catalog-results ul.products{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr))!important;gap:22px!important;list-style:none!important;padding:0!important;margin:0!important}
.catalog-results ul.products>li.product{width:auto!important;float:none!important;margin:0!important;padding:0!important}
.catalog-results .product-grid{display:contents!important}
/* Hero: no tint background */
.page-hero.tint{background:transparent!important;margin-bottom:0!important}
/* ===== FOOTER ===== */
.site-footer{background:#0a0a0a!important}
.footer-masthead{display:flex!important;justify-content:space-between!important;align-items:flex-end!important;padding-bottom:35px!important;border-bottom:1px solid rgba(255,255,255,.12)!important;margin-bottom:50px!important}
.footer-masthead>span{font-size:clamp(50px,6vw,80px)!important;font-weight:750!important;letter-spacing:-2px!important;line-height:1!important;color:#fff!important}
.footer-masthead>div{font-size:10px!important;letter-spacing:.15em!important;text-transform:uppercase!important;color:rgba(255,255,255,.45)!important;text-align:right!important;line-height:2!important}
.footer-brand a[href^="mailto"]{display:block!important;color:rgba(255,255,255,.75)!important;font-size:13px!important;margin:12px 0!important}
.footer-brand a[href^="mailto"]:hover{color:#fff!important}
/* ===== CONTACT CARD ===== */
.contact-card{background:#f5f5f5!important}
.contact-card h3{color:#111!important}
/* ===== SOURCE NOTE ===== */
.source-note{background:#f0f0f0!important;color:#555!important}
/* ===== ARTICLE VISUAL (dark variant for even cards) ===== */
.article-card:nth-child(even) .article-visual{background:#111!important;color:rgba(255,255,255,.5)!important}
.article-card:nth-child(even) .article-visual .icon{color:rgba(255,255,255,.4)!important}
/* ===== ACCOUNT VISUAL ===== */
.account-visual{background:#0a0a0a!important}
/* ===== READING SIDEBAR ===== */
@media(max-width:850px){
  .reading-sidebar a{background:#f5f5f5!important;border-color:#e2e2e2!important}
  .reading-sidebar a.active{background:#0a0a0a!important;color:#fff!important;border-color:#0a0a0a!important}
}
/* ===== ACCOUNT / LOGIN PAGE ===== */
.account-layout{display:grid!important;grid-template-columns:1fr 1fr!important;gap:60px!important;max-width:1000px!important;margin:auto!important}
.account-visual{border-radius:20px!important;background:#0a0a0a!important;min-height:490px!important;position:relative!important;overflow:hidden!important}
.account-visual>div{padding:30px!important;position:absolute!important;bottom:0!important;background:linear-gradient(transparent,rgba(0,0,0,.85))!important;color:#fff!important;width:100%!important;padding-top:100px!important}
.account-visual h2{font-size:37px!important;margin-bottom:15px!important;color:#fff!important}
.account-visual p{color:rgba(255,255,255,.7)!important;font-size:14px!important}
.form-card{padding:35px!important;border:1px solid var(--line)!important;border-radius:18px!important}
.form-card h2{font-size:30px!important;margin-bottom:14px!important}
.form-card>p{font-size:14px!important;margin-bottom:25px!important}
.form-grid{display:grid!important;grid-template-columns:1fr 1fr!important;gap:18px!important}
.field{display:flex!important;flex-direction:column!important;gap:7px!important;font-size:13px!important}
.field.full{grid-column:1/-1!important}
.field input,.field textarea{width:100%!important;border:1px solid var(--line)!important;border-radius:8px!important;padding:10px 13px!important;font-size:14px!important;font-family:inherit!important;background:#fff!important;color:#111!important}
.field input:focus,.field textarea:focus{outline:none!important;border-color:#0a0a0a!important}
.field textarea{resize:vertical!important;min-height:125px!important}
.form-grid .btn{grid-column:1/-1!important}
.form-message{margin-top:16px!important;font-size:13px!important}
.check-field{font-size:12px!important;display:flex!important;align-items:flex-start!important;gap:10px!important}
@media(max-width:760px){
  .account-layout{grid-template-columns:1fr!important;gap:30px!important}
  .account-visual{min-height:220px!important}
}
/* ===== ROTATING PROMO BANNER ===== */
.promo-slides{position:relative!important;overflow:hidden!important;height:38px!important;display:flex!important;align-items:center!important;justify-content:center!important}
.promo-slide{position:absolute!important;top:0!important;left:0!important;right:0!important;bottom:0!important;display:flex!important;align-items:center!important;justify-content:center!important;opacity:0!important;transform:translateY(8px)!important;transition:opacity .35s ease,transform .35s ease!important;pointer-events:none!important;font-size:12px!important;letter-spacing:.04em!important;color:#fff!important;white-space:nowrap!important;gap:10px!important}
.promo-slide.active{opacity:1!important;transform:translateY(0)!important;pointer-events:auto!important}
#topbar-copy-code{background:rgba(255,255,255,.15)!important;color:#fff!important;border:1px solid rgba(255,255,255,.25)!important;border-radius:99px!important;padding:3px 12px!important;font-size:11px!important;font-weight:700!important;letter-spacing:.06em!important;cursor:pointer!important;transition:background .15s!important;line-height:1.6!important}
#topbar-copy-code:hover{background:rgba(255,255,255,.28)!important}
/* ===== EMAIL POPUP OVERLAY ===== */
#popup-overlay{position:fixed!important;inset:0!important;z-index:9999!important;background:rgba(0,0,0,.6)!important;display:flex!important;align-items:center!important;justify-content:center!important;padding:20px!important;opacity:0!important;transition:opacity .25s ease!important}
#popup-overlay[hidden]{display:none!important;pointer-events:none!important}
#popup-overlay.popup-visible{opacity:1!important}
.popup-card{background:#fff!important;border-radius:20px!important;max-width:440px!important;width:100%!important;padding:44px 40px 38px!important;position:relative!important;text-align:center!important}
.popup-close{position:absolute!important;top:16px!important;right:18px!important;background:none!important;border:none!important;font-size:22px!important;line-height:1!important;cursor:pointer!important;color:#999!important;padding:4px 8px!important;border-radius:6px!important;transition:color .15s!important}
.popup-close:hover{color:#111!important}
.popup-card .eyebrow{color:#187a54!important;margin-bottom:10px!important;font-size:11px!important}
.popup-card h2{font-size:clamp(24px,4vw,32px)!important;line-height:1.15!important;margin-bottom:8px!important}
.popup-card p{font-size:14px!important;color:#666!important;margin-bottom:22px!important}
.popup-email-form{display:flex!important;flex-direction:column!important;gap:10px!important}
.popup-email-form input[type="email"]{border:1px solid #dde1df!important;border-radius:10px!important;padding:12px 16px!important;font-size:14px!important;font-family:inherit!important;width:100%!important;background:#fafafa!important}
.popup-email-form input[type="email"]:focus{outline:none!important;border-color:#0a0a0a!important}
.popup-email-form .btn{width:100%!important;background:#0a0a0a!important;color:#fff!important;border-radius:99px!important;padding:13px!important;font-size:14px!important;font-weight:600!important;border:none!important;cursor:pointer!important}
.popup-email-form .btn:hover{background:#333!important}
.popup-dismiss{display:block!important;margin-top:14px!important;font-size:12px!important;color:#aaa!important;cursor:pointer!important;background:none!important;border:none!important;text-decoration:underline!important}
.popup-dismiss:hover{color:#666!important}
/* ===== BACK-TO-TOP ===== */
#back-to-top{position:fixed!important;bottom:24px!important;right:24px!important;z-index:999!important;background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:50%!important;width:44px!important;height:44px!important;display:flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;opacity:0!important;transform:translateY(10px)!important;transition:opacity .25s,transform .25s!important;pointer-events:none!important}
#back-to-top.visible{opacity:1!important;transform:translateY(0)!important;pointer-events:auto!important}
#back-to-top:hover{background:#333!important}
#back-to-top svg{width:18px!important;height:18px!important;stroke:#fff!important;stroke-width:2!important;fill:none!important}
/* ===== TOAST ===== */
#toast{position:fixed!important;bottom:80px!important;left:50%!important;transform:translateX(-50%) translateY(20px)!important;background:#0a0a0a!important;color:#fff!important;padding:12px 24px!important;border-radius:99px!important;font-size:13px!important;z-index:10000!important;opacity:0!important;transition:opacity .25s,transform .25s!important;pointer-events:none!important;white-space:nowrap!important}
#toast.toast-show{opacity:1!important;transform:translateX(-50%) translateY(0)!important}
/* ===== STICKY ATC BAR ===== */
.sticky-atc{position:fixed!important;bottom:0!important;left:0!important;right:0!important;z-index:990!important;background:#fff!important;border-top:1px solid #e8e8e8!important;padding:12px 0!important;transform:translateY(100%)!important;transition:transform .3s ease!important}
.sticky-atc.sticky-visible{transform:translateY(0)!important}
.sticky-atc[hidden]{display:none!important}
.sticky-atc-inner{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:16px!important}
.sticky-atc-info{display:flex!important;flex-direction:column!important;gap:2px!important;min-width:0!important}
.sticky-atc-name{font-size:14px!important;font-weight:600!important;color:#111!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}
.sticky-atc-price{font-size:13px!important;color:#555!important}
.sticky-atc-btn{background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:99px!important;padding:11px 28px!important;font-size:14px!important;font-weight:600!important;cursor:pointer!important;white-space:nowrap!important;flex-shrink:0!important}
.sticky-atc-btn:hover{background:#333!important}
/* ===== MOBILE NAV ACCORDION ===== */
.mobile-nav-accordion{cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:space-between!important;padding:14px 0!important;font-size:16px!important;font-weight:600!important;color:#111!important;border-bottom:1px solid #f0f0f0!important;user-select:none!important}
.mobile-nav-accordion .acc-chevron{display:inline-block!important;transition:transform .2s ease!important;flex-shrink:0!important}
.mobile-nav-accordion.open .acc-chevron{transform:rotate(180deg)!important}
.mobile-nav-sub{display:none!important;padding:6px 0 12px 0!important;border-bottom:1px solid #f0f0f0!important}
.mobile-nav-sub.open{display:block!important}
.mobile-nav-sub a{display:block!important;padding:9px 12px!important;font-size:14px!important;color:#333!important;text-decoration:none!important;border-radius:8px!important}
.mobile-nav-sub a:hover{background:#f5f5f5!important;color:#111!important}
/* ===== PRODUCT CARD BADGES & PURITY ===== */
.card-badges{display:flex!important;align-items:center!important;flex-wrap:wrap!important;gap:5px!important;margin-bottom:6px!important}
.sale-tag{background:#0a0a0a!important;color:#fff!important;font-size:10px!important;font-weight:700!important;letter-spacing:.05em!important;padding:3px 8px!important;border-radius:99px!important;line-height:1.5!important}
.oos-tag{background:#f5f0f0!important;color:#c0392b!important;font-size:10px!important;font-weight:600!important;letter-spacing:.04em!important;padding:3px 8px!important;border-radius:99px!important}
.custom-badge{font-size:10px!important;font-weight:700!important;letter-spacing:.06em!important;padding:3px 8px!important;border-radius:99px!important;text-transform:uppercase!important}
.badge-best-seller{background:#fff8e6!important;color:#b45309!important;border:1px solid #f6d860!important}
.badge-top-pick{background:#f0f9ff!important;color:#0369a1!important;border:1px solid #bae6fd!important}
.badge-new{background:#f0fdf4!important;color:#16a34a!important;border:1px solid #bbf7d0!important}
.badge-popular{background:#fdf4ff!important;color:#9333ea!important;border:1px solid #e9d5ff!important}
.card-purity{font-size:11px!important;color:#16825e!important;font-weight:500!important;margin:4px 0 0!important;letter-spacing:.01em!important}
.card-cat{font-size:10px!important;letter-spacing:.1em!important;text-transform:uppercase!important;color:#999!important;margin-bottom:4px!important;display:block!important}
/* Quick-add button on product card */
.add-to-cart-btn{background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:50%!important;width:34px!important;height:34px!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:20px!important;font-weight:400!important;cursor:pointer!important;flex-shrink:0!important;line-height:1!important;transition:background .15s!important}
.add-to-cart-btn:hover{background:#333!important}
/* ===== LIVE SEARCH RESULTS DROPDOWN ===== */
#search-results{background:#fff!important;border-radius:12px!important;margin-top:10px!important;overflow:hidden!important;max-height:400px!important;overflow-y:auto!important;border:1px solid #e8e8e8!important}
.search-result-item{display:flex!important;align-items:center!important;gap:14px!important;padding:12px 18px!important;text-decoration:none!important;color:#111!important;border-bottom:1px solid #f5f5f5!important;transition:background .12s!important}
.search-result-item:last-child{border-bottom:none!important}
.search-result-item:hover{background:#f8f8f8!important}
.search-result-item img{border-radius:8px!important;object-fit:cover!important;flex-shrink:0!important}
.search-result-item strong{display:block!important;font-size:14px!important;font-weight:600!important;color:#111!important}
.search-result-item span{font-size:13px!important;color:#16825e!important;margin-top:2px!important;display:block!important}
.search-empty{padding:20px!important;text-align:center!important;font-size:14px!important;color:#999!important;margin:0!important}
/* ===== ACCOUNT DASHBOARD ===== */
.account-dashboard{max-width:880px!important;margin:0 auto!important;padding:50px 20px 80px!important}
.account-greeting{margin-bottom:36px!important}
.account-greeting .eyebrow{color:#187a54!important;margin-bottom:8px!important}
.account-greeting h1{font-size:clamp(28px,4vw,40px)!important;margin-bottom:6px!important}
.account-greeting p{font-size:14px!important;color:#666!important}
.account-nav-grid{display:grid!important;grid-template-columns:repeat(3,1fr)!important;gap:16px!important;margin-bottom:48px!important}
.account-nav-card{display:flex!important;flex-direction:column!important;align-items:flex-start!important;gap:10px!important;padding:22px 20px!important;border:1px solid #e8e8e8!important;border-radius:16px!important;text-decoration:none!important;color:#111!important;transition:border-color .15s,box-shadow .15s!important;background:#fff!important}
.account-nav-card:hover{border-color:#0a0a0a!important;box-shadow:0 4px 20px rgba(0,0,0,.07)!important}
.account-nav-card .nav-card-icon{width:40px!important;height:40px!important;background:#f5f5f5!important;border-radius:10px!important;display:flex!important;align-items:center!important;justify-content:center!important}
.account-nav-card .nav-card-icon svg{width:20px!important;height:20px!important;stroke:#333!important;fill:none!important;stroke-width:1.5!important}
.account-nav-card strong{font-size:14px!important;font-weight:600!important}
.account-nav-card span{font-size:12px!important;color:#888!important}
.account-section-head{display:flex!important;align-items:center!important;justify-content:space-between!important;margin-bottom:16px!important}
.account-section-head h2{font-size:18px!important;font-weight:700!important}
.account-orders-table{width:100%!important;border-collapse:collapse!important;font-size:14px!important}
.account-orders-table th{text-align:left!important;padding:10px 14px!important;font-size:11px!important;letter-spacing:.08em!important;text-transform:uppercase!important;color:#999!important;border-bottom:1px solid #eee!important}
.account-orders-table td{padding:14px 14px!important;border-bottom:1px solid #f5f5f5!important;color:#333!important}
.account-orders-table tr:last-child td{border-bottom:none!important}
.account-orders-table a{color:#16825e!important;text-decoration:none!important;font-weight:600!important}
.account-orders-table a:hover{text-decoration:underline!important}
.order-status-badge{display:inline-block!important;padding:3px 10px!important;border-radius:99px!important;font-size:11px!important;font-weight:600!important;background:#f0fdf4!important;color:#16a34a!important}
.account-empty{text-align:center!important;padding:40px!important;color:#999!important;font-size:14px!important}
@media(max-width:640px){
  .account-nav-grid{grid-template-columns:1fr 1fr!important}
  .account-orders-table th:nth-child(3),.account-orders-table td:nth-child(3){display:none!important}
}
/* ===== PRICE DROP PILL (D3) ===== */
.price-drop-pill{display:inline-block!important;background:#16825e!important;color:#fff!important;font-size:11px!important;font-weight:700!important;letter-spacing:.04em!important;padding:4px 10px!important;border-radius:99px!important;line-height:1.5!important;vertical-align:middle!important}
/* ===== PAYMENT ICONS (D6) ===== */
.payment-icons{display:flex!important;align-items:center!important;flex-wrap:wrap!important;gap:6px!important;margin-top:18px!important;padding-top:16px!important;border-top:1px solid var(--line)!important}
.payment-icons svg{border-radius:4px!important;flex-shrink:0!important}
.payment-icon-label{font-size:11px!important;color:#999!important;flex-basis:100%!important;margin-top:2px!important}
/* ===== FREQUENTLY BOUGHT TOGETHER (D8) ===== */
.fbt-section{margin-top:60px!important}
.fbt-grid{display:grid!important;grid-template-columns:repeat(auto-fill,minmax(200px,1fr))!important;gap:16px!important;margin-top:24px!important}
.fbt-card{border:1px solid #e8e8e8!important;border-radius:14px!important;padding:16px!important;display:flex!important;flex-direction:column!important;align-items:center!important;gap:10px!important;text-align:center!important}
.fbt-img-link img{border-radius:10px!important;object-fit:cover!important}
.fbt-info{flex:1!important}
.fbt-name{font-size:13px!important;font-weight:600!important;color:#111!important;text-decoration:none!important;display:block!important;margin-bottom:4px!important}
.fbt-name:hover{color:#16825e!important}
.fbt-price{font-size:13px!important;color:#555!important}
.fbt-card .btn.small,.fbt-card .btn.outline.small{padding:8px 16px!important;font-size:12px!important;border-radius:99px!important}
/* ===== CART DRAWER FREE-SHIP BAR (K2) ===== */
.drawer-freeship{padding:14px 20px 10px!important;border-bottom:1px solid #f0f0f0!important}
.drawer-freeship-msg{font-size:12px!important;color:#555!important;margin-bottom:7px!important}
.drawer-freeship-msg strong{color:#111!important}
.drawer-freeship-track{background:#f0f0f0!important;border-radius:99px!important;height:4px!important;overflow:hidden!important}
.drawer-freeship-fill{background:#16825e!important;height:100%!important;border-radius:99px!important;transition:width .4s ease!important}
/* ===== QTY STEPPER ===== */
.qty-stepper{display:inline-flex!important;align-items:center!important;border:1px solid #e0e0e0!important;border-radius:99px!important;overflow:hidden!important}
.qty-stepper .qty-minus,.qty-stepper .qty-plus{background:none!important;border:none!important;width:36px!important;height:36px!important;font-size:18px!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:center!important;color:#333!important;flex-shrink:0!important;transition:background .12s!important}
.qty-stepper .qty-minus:hover,.qty-stepper .qty-plus:hover{background:#f5f5f5!important}
.qty-stepper input.qty{width:40px!important;border:none!important;text-align:center!important;font-size:14px!important;font-weight:600!important;padding:0!important;outline:none!important;-moz-appearance:textfield!important}
.qty-stepper input.qty::-webkit-inner-spin-button,.qty-stepper input.qty::-webkit-outer-spin-button{-webkit-appearance:none!important}
/* ===== CART PAGE LAYOUT (K4) ===== */
.cart-page .cart-layout{display:grid!important;grid-template-columns:1fr 360px!important;gap:40px!important;align-items:start!important}
.cart-page .shop_table{width:100%!important;border-collapse:collapse!important;font-size:14px!important}
.cart-page .shop_table th{padding:10px 12px!important;font-size:11px!important;letter-spacing:.08em!important;text-transform:uppercase!important;color:#999!important;border-bottom:1px solid #eee!important;text-align:left!important}
.cart-page .shop_table td{padding:14px 12px!important;border-bottom:1px solid #f5f5f5!important;vertical-align:middle!important}
.cart-page .shop_table .product-thumbnail img{border-radius:10px!important;width:66px!important;height:66px!important;object-fit:cover!important}
.cart-page .shop_table .product-name a{font-weight:600!important;color:#111!important;text-decoration:none!important}
.cart-page .shop_table .product-name a:hover{color:#16825e!important}
.cart-page .shop_table .remove{color:#ccc!important;font-size:18px!important;text-decoration:none!important;font-weight:400!important;transition:color .12s!important}
.cart-page .shop_table .remove:hover{color:#c0392b!important}
.cart-page .actions{padding:14px 0!important}
.cart-page .coupon{display:flex!important;gap:8px!important;margin-bottom:10px!important}
.cart-page .coupon input{flex:1!important;border:1px solid #dde1df!important;border-radius:99px!important;padding:9px 16px!important;font-size:13px!important}
.cart-page .btn.outline.small{padding:9px 18px!important;font-size:13px!important;background:#fff!important;color:#0a0a0a!important;border:1px solid #0a0a0a!important;border-radius:99px!important;cursor:pointer!important}
.cart-page .btn.outline.small:hover{background:#0a0a0a!important;color:#fff!important}
.cart-page .cart-collaterals{background:#fafafa!important;border:1px solid #e8e8e8!important;border-radius:16px!important;padding:24px!important}
.cart-page .cart_totals h2{font-size:16px!important;font-weight:700!important;margin-bottom:16px!important}
.cart-page .cart_totals table{width:100%!important;font-size:14px!important;border-collapse:collapse!important}
.cart-page .cart_totals table th,.cart-page .cart_totals table td{padding:8px 0!important;border-bottom:1px solid #f0f0f0!important;vertical-align:top!important}
.cart-page .cart_totals table tr:last-child th,.cart-page .cart_totals table tr:last-child td{font-weight:700!important;border-bottom:none!important;padding-top:12px!important;font-size:15px!important}
.cart-page .cart_totals .wc-proceed-to-checkout .checkout-button{display:block!important;width:100%!important;text-align:center!important;background:#0a0a0a!important;color:#fff!important;border-radius:99px!important;padding:14px!important;font-size:14px!important;font-weight:700!important;text-decoration:none!important;margin-top:16px!important;border:none!important}
.cart-page .cart_totals .wc-proceed-to-checkout .checkout-button:hover{background:#333!important}
.cart-freeship-bar{background:#f8f8f8!important;border:1px solid #e8e8e8!important;border-radius:12px!important;padding:14px 18px!important}
.cart-freeship-msg{font-size:13px!important;color:#555!important;margin-bottom:8px!important}
.cart-freeship-msg strong{color:#111!important}
.cart-freeship-track{background:#e8e8e8!important;border-radius:99px!important;height:5px!important;overflow:hidden!important}
.cart-freeship-fill{background:#16825e!important;height:100%!important;border-radius:99px!important;transition:width .4s!important}
.cart-freeship-unlocked{color:#16825e!important;font-weight:600!important}
.cart-order-note textarea{width:100%!important;border:1px solid #dde1df!important;border-radius:10px!important;padding:10px 14px!important;font-size:13px!important;font-family:inherit!important;resize:vertical!important}
@media(max-width:800px){
  .cart-page .cart-layout{grid-template-columns:1fr!important}
  .cart-page .shop_table th:nth-child(3),.cart-page .shop_table td:nth-child(3){display:none!important}
}
/* ===== CHECKOUT PAGE ===== */
.woocommerce-checkout-payment,.woocommerce-page .woocommerce-checkout-payment{background:#fff!important}
.checkout-layout{display:grid!important;grid-template-columns:1fr 400px!important;gap:60px!important;align-items:start!important;max-width:1160px!important;margin:0 auto!important;padding:40px 20px 80px!important}
.checkout-section{margin-bottom:30px!important}
.checkout-section-title{font-size:17px!important;font-weight:700!important;margin-bottom:18px!important;color:#111!important}
.checkout-logged-in{font-size:13px!important;color:#555!important;margin-bottom:14px!important}
.checkout-logged-in a{color:#16825e!important}
.checkout-fields-grid .form-row{margin-bottom:16px!important}
.checkout-fields-grid .form-row-first,.checkout-fields-grid .form-row-half{float:left!important;width:calc(50% - 6px)!important;margin-right:12px!important}
.checkout-fields-grid .form-row-last,.checkout-fields-grid .form-row-half:nth-child(even){float:left!important;width:calc(50% - 6px)!important;margin-right:0!important}
.woocommerce-checkout .form-row input.input-text,.woocommerce-checkout .form-row select,.woocommerce-checkout .form-row textarea{width:100%!important;border:1px solid #dde1df!important;border-radius:10px!important;padding:11px 14px!important;font-size:14px!important;font-family:inherit!important;background:#fff!important;color:#111!important;-webkit-appearance:none!important;appearance:none!important}
.woocommerce-checkout .form-row input.input-text:focus,.woocommerce-checkout .form-row select:focus{outline:none!important;border-color:#0a0a0a!important}
.woocommerce-checkout .form-row label{font-size:12px!important;font-weight:600!important;color:#555!important;margin-bottom:5px!important;display:block!important}
.woocommerce-checkout .form-row.woocommerce-invalid input{border-color:#c0392b!important}
/* Coupon toggle */
.checkout-coupon-section{border:1px solid #e8e8e8!important;border-radius:12px!important;padding:16px 20px!important}
.coupon-toggle{background:none!important;border:none!important;font-size:14px!important;font-weight:600!important;color:#111!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:space-between!important;width:100%!important;padding:0!important}
.coupon-chevron{width:18px!important;height:18px!important;transition:transform .2s!important;flex-shrink:0!important}
.coupon-toggle[aria-expanded="true"] .coupon-chevron{transform:rotate(180deg)!important}
.coupon-form-row{margin-top:14px!important}
.coupon-fields{display:flex!important;gap:8px!important}
.coupon-fields input{flex:1!important;border:1px solid #dde1df!important;border-radius:99px!important;padding:10px 16px!important;font-size:14px!important;font-family:inherit!important}
.coupon-fields input:focus{outline:none!important;border-color:#0a0a0a!important}
.btn-apply-coupon{background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:99px!important;padding:10px 22px!important;font-size:14px!important;font-weight:600!important;cursor:pointer!important;white-space:nowrap!important}
.btn-apply-coupon:hover{background:#333!important}
.coupon-msg{font-size:13px!important;margin-top:8px!important;padding:8px 12px!important;border-radius:8px!important;background:#f0fdf4!important;color:#16a34a!important}
.coupon-msg.error{background:#fdf2f2!important;color:#c0392b!important}
/* Order review table */
.checkout-summary-col{position:sticky!important;top:80px!important;background:#fafafa!important;border:1px solid #e8e8e8!important;border-radius:18px!important;padding:28px!important}
.checkout-summary-toggle{cursor:default!important}
.woocommerce-checkout-review-order-table{width:100%!important;border-collapse:collapse!important;font-size:13px!important}
.woocommerce-checkout-review-order-table th,.woocommerce-checkout-review-order-table td{padding:10px 0!important;border-bottom:1px solid #f0f0f0!important}
.woocommerce-checkout-review-order-table tfoot tr:last-child th,.woocommerce-checkout-review-order-table tfoot tr:last-child td{font-size:16px!important;font-weight:700!important;border-bottom:none!important;padding-top:14px!important}
/* Payment section */
.woocommerce-checkout #payment{background:transparent!important;border-radius:0!important;padding:0!important}
.woocommerce-checkout #payment ul.payment_methods{list-style:none!important;padding:0!important;margin:0 0 20px!important}
.woocommerce-checkout #payment ul.payment_methods li.payment_method{border:1px solid #e8e8e8!important;border-radius:12px!important;margin-bottom:10px!important;padding:0!important;background:#fff!important}
.woocommerce-checkout #payment ul.payment_methods li.payment_method>label{display:flex!important;align-items:center!important;gap:12px!important;padding:16px 18px!important;cursor:pointer!important;font-size:14px!important;font-weight:600!important;color:#111!important}
.woocommerce-checkout #payment ul.payment_methods li.payment_method input[type="radio"]{accent-color:#0a0a0a!important;width:16px!important;height:16px!important}
.woocommerce-checkout #payment .payment_box{padding:0 18px 16px!important;font-size:13px!important;color:#666!important}
/* Interac fee note */
.interac-fee-note{font-size:11px!important;background:#fff8e6!important;color:#b45309!important;border-radius:6px!important;padding:4px 10px!important;margin-left:auto!important;font-weight:600!important}
/* Place order / terms */
.woocommerce-checkout #payment .place-order{padding:0!important;margin-top:20px!important}
.woocommerce-checkout #payment .terms{font-size:12px!important;color:#555!important;margin-bottom:14px!important}
.woocommerce-checkout #payment .terms a{color:#16825e!important}
.woocommerce-checkout #payment #place_order,
.woocommerce-checkout #payment .button#place_order{width:100%!important;background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:99px!important;padding:16px!important;font-size:15px!important;font-weight:700!important;cursor:pointer!important;letter-spacing:.02em!important}
.woocommerce-checkout #payment #place_order:hover{background:#333!important}
/* Create account section */
.create-account-row,.omnisend-optin-row{margin-bottom:12px!important}
@media(max-width:900px){
  .checkout-layout{grid-template-columns:1fr!important;gap:30px!important}
  .checkout-summary-col{position:static!important;order:-1!important}
  .checkout-summary-inner{display:none}
  .checkout-summary-toggle{cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:space-between!important}
  .checkout-summary-toggle.open .summary-chevron{transform:rotate(180deg)!important}
  .checkout-summary-inner.open{display:block!important}
  .summary-chevron{width:18px!important;height:18px!important;transition:transform .2s!important}
}
@media(min-width:901px){.summary-chevron{display:none!important}}
/* ===== THANK-YOU PAGE ===== */
.checkout-thankyou{padding-left:20px!important;padding-right:20px!important}
/* ===== PDP PACK/STRENGTH PILLS (D2) ===== */
.pdp-pills-row{margin-bottom:16px!important}
.pdp-pills-label{font-size:11px!important;font-weight:700!important;letter-spacing:.08em!important;text-transform:uppercase!important;color:#777!important;margin-bottom:8px!important}
.pdp-pills{display:flex!important;flex-wrap:wrap!important;gap:8px!important}
.pdp-pill{background:#fff!important;color:#111!important;border:1.5px solid #e0e0e0!important;border-radius:99px!important;padding:8px 18px!important;font-size:13px!important;font-weight:600!important;cursor:pointer!important;display:flex!important;align-items:center!important;gap:6px!important;transition:border-color .15s,background .15s!important;line-height:1.3!important}
.pdp-pill:hover{border-color:#888!important}
.pdp-pill.active{border-color:#0a0a0a!important;background:#0a0a0a!important;color:#fff!important}
.pdp-pill.active .pill-save{color:rgba(255,255,255,.75)!important}
.pill-save{font-size:10px!important;font-weight:700!important;color:#16825e!important;background:#f0fdf4!important;border-radius:99px!important;padding:2px 7px!important}
.pdp-pill.active .pill-save{background:rgba(255,255,255,.15)!important}
/* ===== MINI-CART DRAWER LINE ITEMS ===== */
.woocommerce-mini-cart .mini_cart_item{display:flex!important;align-items:flex-start!important;gap:12px!important;padding:12px 0!important;border-bottom:1px solid #f5f5f5!important}
.woocommerce-mini-cart .mini_cart_item img{border-radius:8px!important;object-fit:cover!important;flex-shrink:0!important;width:56px!important;height:56px!important}
.woocommerce-mini-cart .mini_cart_item .remove{color:#ccc!important;font-size:16px!important;text-decoration:none!important;flex-shrink:0!important;margin-left:auto!important}
.woocommerce-mini-cart .mini_cart_item .remove:hover{color:#c0392b!important}
.mini-cart-item-details{flex:1!important;min-width:0!important}
.mini-cart-item-details .mini-cart-item-name a{font-size:13px!important;font-weight:600!important;color:#111!important;text-decoration:none!important;display:block!important;margin-bottom:3px!important}
.mini-cart-item-row{display:flex!important;align-items:center!important;justify-content:space-between!important;margin-top:6px!important}
.mini-cart-item-price{font-size:13px!important;color:#555!important}
.mini-cart-stepper{display:inline-flex!important;align-items:center!important;border:1px solid #e0e0e0!important;border-radius:99px!important;overflow:hidden!important}
.mini-cart-stepper .qty-minus,.mini-cart-stepper .qty-plus{background:none!important;border:none!important;width:28px!important;height:28px!important;font-size:16px!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:center!important;color:#333!important}
.mini-cart-stepper .qty-display{width:28px!important;text-align:center!important;font-size:13px!important;font-weight:600!important}
.woocommerce-mini-cart__total{padding:14px 0 8px!important;font-size:14px!important;font-weight:600!important;display:flex!important;justify-content:space-between!important}
.woocommerce-mini-cart__buttons{display:flex!important;flex-direction:column!important;gap:10px!important;margin-top:8px!important}
.cart-btn-view{background:#fff!important;color:#0a0a0a!important;border:1px solid #0a0a0a!important;border-radius:99px!important;text-align:center!important;padding:12px!important;font-size:14px!important;font-weight:600!important;text-decoration:none!important}
.cart-btn-view:hover{background:#f5f5f5!important}
.cart-btn-checkout{background:#0a0a0a!important;color:#fff!important;border:none!important;border-radius:99px!important;text-align:center!important;padding:12px!important;font-size:14px!important;font-weight:700!important;text-decoration:none!important}
.cart-btn-checkout:hover{background:#333!important}
</style>' . "\n";
}, 999 );
