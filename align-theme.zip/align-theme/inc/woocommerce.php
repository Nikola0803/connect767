<?php
defined( 'ABSPATH' ) || exit;

// Remove default WooCommerce wrappers — theme provides its own
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content',  'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

add_action( 'woocommerce_before_main_content', function() {
    echo '<main id="primary" class="site-main woo-main">';
}, 10 );

add_action( 'woocommerce_after_main_content', function() {
    echo '</main>';
}, 10 );

// Product columns
add_filter( 'loop_shop_columns', function() { return 4; } );
add_filter( 'loop_shop_per_page', function() { return 16; } );

// Breadcrumbs
add_filter( 'woocommerce_breadcrumb_defaults', function( $defaults ) {
    $defaults['delimiter'] = '<span class="sep"> / </span>';
    return $defaults;
} );

// Mini cart fragment for AJAX drawer updates
add_filter( 'woocommerce_add_to_cart_fragments', function( $fragments ) {
    ob_start();
    ?>
    <span class="bag-count" data-count="<?php echo esc_attr( WC()->cart->get_cart_contents_count() ); ?>">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </span>
    <?php
    $fragments['.bag-count'] = ob_get_clean();
    return $fragments;
} );

// Disable default single product tabs structure (we build our own accordion)
add_filter( 'woocommerce_product_tabs', function( $tabs ) {
    return $tabs;
}, 98 );

// Sale badge
add_filter( 'woocommerce_sale_flash', function( $html, $post, $product ) {
    return '<span class="tag sale-tag">' . __( 'Sale', 'align-theme' ) . '</span>';
}, 10, 3 );

// Remove default product title on single (theme header.php covers it)
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );

// Star rating shortening
add_filter( 'woocommerce_product_get_rating_html', function( $html, $rating, $count ) {
    if ( $count ) {
        return '<div class="star-rating"><span style="width:' . ( ( $rating / 5 ) * 100 ) . '%"></span></div>';
    }
    return $html;
}, 10, 3 );
