<?php
defined( 'ABSPATH' ) || exit;

// ── Age gate server-side redirect (S154 replacement) ─────────
// Redirects un-verified visitors to /disclaimer/, preserving destination + UTM.
// Exempt: /disclaimer/, /my-account/*, /shopping-cart/, /checkouts/*, policy pages, /access/, REST API.
add_action( 'template_redirect', function() {
    if ( is_admin() || wp_is_json_request() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) return;
    if ( ! empty( $_COOKIE['align_age_verified'] ) ) return;

    $exempt = [ 'disclaimer', 'my-account', 'shopping-cart', 'checkouts', 'shipping-policy',
                'refund-policy', 'privacy-policy', 'terms-conditions', 'access' ];

    $obj = get_queried_object();
    if ( $obj instanceof WP_Post && in_array( $obj->post_name, $exempt, true ) ) return;
    if ( $obj instanceof WP_Post && wp_get_post_parent_id( $obj->ID ) ) {
        $parent = get_post( wp_get_post_parent_id( $obj->ID ) );
        if ( $parent && in_array( $parent->post_name, $exempt, true ) ) return;
    }
    if ( is_wc_endpoint_url() ) return;

    // Store intended destination (30 min)
    $dest = $_SERVER['REQUEST_URI'] ?? '/';
    setcookie( 'align_intended_dest', $dest, time() + 1800, '/', '', is_ssl(), false );

    wp_safe_redirect( add_query_arg( null, null, home_url( '/disclaimer/' ) ) );
    exit;
} );

add_action( 'after_setup_theme', function() {
    load_theme_textdomain( 'align-theme', ALIGN_THEME_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'wp-block-styles' );

    // WooCommerce
    add_theme_support( 'woocommerce', [
        'thumbnail_image_width' => 600,
        'single_image_width'    => 900,
        'product_grid'          => [ 'default_columns' => 4, 'default_rows' => 4 ],
    ] );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    register_nav_menus( [
        'primary'   => __( 'Primary Navigation', 'align-theme' ),
        'footer'    => __( 'Footer Links', 'align-theme' ),
        'footer-2'  => __( 'Footer Column 2', 'align-theme' ),
        'footer-3'  => __( 'Footer Column 3', 'align-theme' ),
    ] );

    add_image_size( 'align-card',     600, 600, true );
    add_image_size( 'align-hero',    1440, 700, true );
    add_image_size( 'align-product',  900, 900, false );
} );

// ── S167 search aliases ───────────────────────────────────────
// Retatrutide → GLP-3, Tirzepatide → GLP-2, Semaglutide → GLP-1
add_filter( 'request', function( $vars ) {
    if ( empty( $vars['s'] ) ) return $vars;
    $map = [
        'retatrutide' => 'GLP-3',
        'tirzepatide' => 'GLP-2',
        'semaglutide' => 'GLP-1',
    ];
    $q = strtolower( $vars['s'] );
    foreach ( $map as $term => $alias ) {
        if ( strpos( $q, $term ) !== false ) {
            $vars['s'] = str_ireplace( $term, $alias, $vars['s'] );
            break;
        }
    }
    return $vars;
} );

// ── Canada-only checkout ──────────────────────────────────────
add_filter( 'woocommerce_countries', function( $countries ) {
    return isset( $countries['CA'] ) ? [ 'CA' => $countries['CA'] ] : $countries;
} );
add_filter( 'woocommerce_allowed_countries', function() {
    return [ 'CA' => __( 'Canada', 'woocommerce' ) ];
} );
add_filter( 'woocommerce_shipping_allowed_countries', function() {
    return [ 'CA' => __( 'Canada', 'woocommerce' ) ];
} );

// ── Fix 19+ terms text ────────────────────────────────────────
add_filter( 'woocommerce_checkout_terms_and_conditions_checkbox_text', function() {
    return sprintf(
        __( 'I am 19 years of age or older and agree to the <a href="%1$s">Terms &amp; Conditions</a> and <a href="%2$s">Privacy Policy</a>. Products are for research use only.', 'align-theme' ),
        esc_url( home_url( '/terms-conditions/' ) ),
        esc_url( home_url( '/privacy-policy/' ) )
    );
} );

// ── C4: Page-1 product pinning ────────────────────────────────
// GLP-3, BPC-157, KLOW 80mg, GLOW appear first on the shop page.
// Uses menu_order to pin by slug — products not in this list keep their natural order.
add_filter( 'woocommerce_product_query_meta_query', function( $meta_query, $query ) {
    return $meta_query;
}, 10, 2 );

add_filter( 'posts_clauses', function( $clauses, $query ) {
    if ( ! $query->is_main_query() ) return $clauses;
    if ( ! ( is_shop() || is_product_category() ) ) return $clauses;
    if ( 1 !== (int) $query->get( 'paged', 1 ) ) return $clauses;

    global $wpdb;

    // Slugs to pin to the top, in this order
    $pinned = [ 'glp-3', 'bpc-157', 'klow-80mg', 'glow' ];

    // Add a CASE expression to the ORDER BY: pinned slugs get rank 0-3, rest get rank 99
    $case = "CASE {$wpdb->posts}.post_name";
    foreach ( $pinned as $i => $slug ) {
        $case .= $wpdb->prepare( ' WHEN %s THEN %d', $slug, $i );
    }
    $case .= ' ELSE 99 END';

    $clauses['orderby'] = "{$case} ASC, {$clauses['orderby']}";
    return $clauses;
}, 10, 2 );
