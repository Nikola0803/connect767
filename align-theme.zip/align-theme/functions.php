<?php
defined( 'ABSPATH' ) || exit;

define( 'ALIGN_THEME_VERSION', '2.0.0' );
define( 'ALIGN_THEME_DIR', get_template_directory() );
define( 'ALIGN_THEME_URI', get_template_directory_uri() );

require_once ALIGN_THEME_DIR . '/inc/setup.php';
require_once ALIGN_THEME_DIR . '/inc/enqueue.php';
require_once ALIGN_THEME_DIR . '/inc/helpers.php';
require_once ALIGN_THEME_DIR . '/inc/woocommerce.php';
require_once ALIGN_THEME_DIR . '/inc/ajax.php';
