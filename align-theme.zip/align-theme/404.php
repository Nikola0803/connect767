<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="wrap" style="padding:80px 0">
    <div class="empty-state">
        <svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <h2><?php esc_html_e( 'Page Not Found', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'The page you\'re looking for doesn\'t exist or has been moved.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn"><?php esc_html_e( 'Return Home', 'align-theme' ); ?></a>
    </div>
</div>
<?php get_footer(); ?>
