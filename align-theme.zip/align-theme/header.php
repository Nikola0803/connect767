<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip" href="#primary"><?php esc_html_e( 'Skip to content', 'align-theme' ); ?></a>

<!-- Rotating promo banner (3 slides, 4 s, matches S25) -->
<div class="topbar" id="promo-bar" aria-label="<?php esc_attr_e( 'Announcements', 'align-theme' ); ?>">
    <div class="wrap promo-bar-wrap">
        <div class="promo-slides" id="promo-slides" aria-live="polite">
            <div class="promo-slide active">🔻 <?php esc_html_e( 'PRICE DROP · GLP-3, WOLVERINE, GLOW &amp; KLOW NOW UP TO 19% OFF', 'align-theme' ); ?></div>
            <div class="promo-slide">✨ <?php esc_html_e( 'NEW HERE? 10% OFF YOUR FIRST ORDER · CODE', 'align-theme' ); ?> <button type="button" class="topbar-code" id="topbar-copy-code" aria-label="<?php esc_attr_e( 'Copy code WELCOME10', 'align-theme' ); ?>">WELCOME10</button></div>
            <div class="promo-slide">🇨🇦 <?php esc_html_e( 'SHIPS FROM CANADA · FREE SHIPPING OVER $400', 'align-theme' ); ?></div>
        </div>
    </div>
</div>

<header class="site-header" id="site-header">
    <div class="nav wrap">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="brand" aria-label="<?php bloginfo( 'name' ); ?>">
            <img src="<?php echo esc_url( align_logo() ); ?>" alt="<?php bloginfo( 'name' ); ?>" width="140" height="49">
        </a>

        <nav class="nav-links" id="nav-links" aria-label="<?php esc_attr_e( 'Main navigation', 'align-theme' ); ?>">
            <button type="button" class="nav-mega-trigger" aria-expanded="false" aria-controls="mega-menu"><?php esc_html_e( 'Catalogue +', 'align-theme' ); ?></button>
            <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab results', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><?php esc_html_e( 'Our approach', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>"><?php esc_html_e( 'Resources', 'align-theme' ); ?></a>
            <button type="button" class="nav-mega-trigger nav-explore-trigger" aria-expanded="false" aria-controls="mega-menu-explore"><?php esc_html_e( 'Explore +', 'align-theme' ); ?></button>
        </nav>

        <div class="nav-actions">
            <button type="button" class="icon-btn search-toggle" aria-label="<?php esc_attr_e( 'Search', 'align-theme' ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
            </button>

            <a href="<?php echo esc_url( function_exists( 'wc_get_account_page_permalink' ) ? wc_get_account_page_permalink() : home_url( '/my-account/' ) ); ?>" class="icon-btn" aria-label="<?php esc_attr_e( 'Account', 'align-theme' ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><circle cx="12" cy="7" r="3.5"/><path d="M5 21v-2a7 7 0 0 1 14 0v2"/></svg>
            </a>

            <button type="button" class="icon-btn bag cart-toggle" aria-label="<?php esc_attr_e( 'Cart', 'align-theme' ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><path d="M5 7h14l1 14H4L5 7Z"/><path d="M9 8V5a3 3 0 0 1 6 0v3"/></svg>
                <span class="bag-count" data-count="<?php echo esc_attr( align_cart_count() ); ?>"><?php echo esc_html( align_cart_count() > 0 ? align_cart_count() : '' ); ?></span>
            </button>

            <button type="button" class="icon-btn mobile-menu" aria-label="<?php esc_attr_e( 'Menu', 'align-theme' ); ?>" aria-expanded="false">
                <svg class="icon" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
            </button>
        </div>
    </div>

    <!-- Catalogue mega menu — 4 columns matching design -->
    <div class="mega" id="mega-menu" hidden>
        <div class="wrap">
            <!-- Col 1: primary categories -->
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Shop by research category', 'align-theme' ); ?></div>
                <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'All Products', 'align-theme' ); ?></a>
                <?php
                foreach ( [ 'glp1-agonists', 'research-pens', 'recovery-repair', 'longevity' ] as $mslug ) {
                    $mcat = get_term_by( 'slug', $mslug, 'product_cat' );
                    if ( $mcat && ! is_wp_error( $mcat ) ) {
                        echo '<a href="' . esc_url( get_term_link( $mcat ) ) . '">' . esc_html( $mcat->name ) . '</a>';
                    }
                }
                ?>
            </div>
            <!-- Col 2: more categories -->
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Explore more', 'align-theme' ); ?></div>
                <?php
                foreach ( [ 'metabolic-research', 'growth-research', 'hormonal-cognitive', 'research-bundles', 'research-supplies' ] as $mslug ) {
                    $mcat = get_term_by( 'slug', $mslug, 'product_cat' );
                    if ( $mcat && ! is_wp_error( $mcat ) ) {
                        echo '<a href="' . esc_url( get_term_link( $mcat ) ) . '">' . esc_html( $mcat->name ) . '</a>';
                    }
                }
                ?>
            </div>
            <!-- Col 3: docs & account -->
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Documentation & account', 'align-theme' ); ?></div>
                <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab Results', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/track-order/' ) ); ?>"><?php esc_html_e( 'Track Order', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( function_exists( 'wc_get_account_page_permalink' ) ? wc_get_account_page_permalink() : home_url( '/my-account/' ) ); ?>"><?php esc_html_e( 'My Account', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/wishlist/' ) ); ?>"><?php esc_html_e( 'Wishlist', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/all-categories/' ) ); ?>"><?php esc_html_e( 'All Categories', 'align-theme' ); ?></a>
            </div>
            <!-- Col 4: promo -->
            <div class="mega-promo">
                <div class="eyebrow"><?php esc_html_e( 'Your first order', 'align-theme' ); ?></div>
                <h3><?php esc_html_e( 'Welcome to Align.', 'align-theme' ); ?></h3>
                <p class="small" style="margin-top:15px">WELCOME10 · <?php esc_html_e( '10% off', 'align-theme' ); ?><br><?php esc_html_e( 'Free shipping over $400', 'align-theme' ); ?></p>
                <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'Explore the catalogue →', 'align-theme' ); ?></a>
            </div>
        </div>
    </div>

    <!-- Explore mega menu -->
    <div class="mega" id="mega-menu-explore" hidden>
        <div class="wrap">
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Align Biosciences', 'align-theme' ); ?></div>
                <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><?php esc_html_e( 'About Us', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>"><?php esc_html_e( 'Research Standards', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>"><?php esc_html_e( 'Resources', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/partnership/' ) ); ?>"><?php esc_html_e( 'Partnership', 'align-theme' ); ?></a>
            </div>
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Support', 'align-theme' ); ?></div>
                <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/faqs/' ) ); ?>"><?php esc_html_e( 'FAQs', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/shipping-policy/' ) ); ?>"><?php esc_html_e( 'Shipping Policy', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/refund-policy/' ) ); ?>"><?php esc_html_e( 'Refund Policy', 'align-theme' ); ?></a>
            </div>
            <div>
                <div class="eyebrow"><?php esc_html_e( 'Documentation & account', 'align-theme' ); ?></div>
                <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab Results', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/track-order/' ) ); ?>"><?php esc_html_e( 'Track Order', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( function_exists( 'wc_get_account_page_permalink' ) ? wc_get_account_page_permalink() : home_url( '/my-account/' ) ); ?>"><?php esc_html_e( 'My Account', 'align-theme' ); ?></a>
                <a href="<?php echo esc_url( home_url( '/all-categories/' ) ); ?>"><?php esc_html_e( 'All Categories', 'align-theme' ); ?></a>
            </div>
            <div class="mega-promo">
                <div class="eyebrow"><?php esc_html_e( 'Your first order', 'align-theme' ); ?></div>
                <h3><?php esc_html_e( 'Welcome to Align.', 'align-theme' ); ?></h3>
                <p class="small" style="margin-top:15px">WELCOME10 · <?php esc_html_e( '10% off', 'align-theme' ); ?><br><?php esc_html_e( 'Free shipping over $400', 'align-theme' ); ?></p>
                <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'Explore the catalogue →', 'align-theme' ); ?></a>
            </div>
        </div>
    </div>
</header>

<!-- Mobile navigation -->
<div class="mobile-nav-overlay" id="mobile-nav-overlay"></div>
<nav class="mobile-nav" id="mobile-nav" aria-label="<?php esc_attr_e( 'Mobile navigation', 'align-theme' ); ?>">
    <div class="mobile-nav-head">
        <img src="<?php echo esc_url( align_logo() ); ?>" alt="<?php bloginfo( 'name' ); ?>" width="110" height="38">
        <button type="button" class="icon-btn mobile-nav-close" aria-label="<?php esc_attr_e( 'Close menu', 'align-theme' ); ?>">
            <svg class="icon" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
    </div>
    <div class="mobile-nav-links">

        <!-- Catalogue accordion -->
        <button type="button" class="mobile-nav-accordion" aria-expanded="false">
            <?php esc_html_e( 'Catalogue', 'align-theme' ); ?>
            <svg class="icon acc-chevron" viewBox="0 0 24 24" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
        <div class="mobile-nav-sub" hidden>
            <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>"><?php esc_html_e( 'All Products', 'align-theme' ); ?></a>
            <?php
            $mnav_cats = [ 'glp1-agonists', 'research-pens', 'recovery-repair', 'longevity', 'metabolic-research', 'growth-research', 'hormonal-cognitive', 'research-bundles', 'research-supplies' ];
            foreach ( $mnav_cats as $mslug ) {
                $mcat = get_term_by( 'slug', $mslug, 'product_cat' );
                if ( $mcat && ! is_wp_error( $mcat ) ) {
                    echo '<a href="' . esc_url( get_term_link( $mcat ) ) . '">' . esc_html( $mcat->name ) . '</a>';
                }
            }
            ?>
        </div>

        <!-- Explore accordion -->
        <button type="button" class="mobile-nav-accordion" aria-expanded="false">
            <?php esc_html_e( 'Explore', 'align-theme' ); ?>
            <svg class="icon acc-chevron" viewBox="0 0 24 24" aria-hidden="true"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
        <div class="mobile-nav-sub" hidden>
            <a href="<?php echo esc_url( home_url( '/about-us/' ) ); ?>"><?php esc_html_e( 'About Us', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/research/' ) ); ?>"><?php esc_html_e( 'Research Standards', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/resources/' ) ); ?>"><?php esc_html_e( 'Resources', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/partnership/' ) ); ?>"><?php esc_html_e( 'Partnership', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/faqs/' ) ); ?>"><?php esc_html_e( 'FAQs', 'align-theme' ); ?></a>
            <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>"><?php esc_html_e( 'Contact Us', 'align-theme' ); ?></a>
        </div>

        <!-- Direct links -->
        <a href="<?php echo esc_url( home_url( '/coa/' ) ); ?>"><?php esc_html_e( 'Lab Results', 'align-theme' ); ?></a>
        <a href="<?php echo esc_url( function_exists( 'wc_get_account_page_permalink' ) ? wc_get_account_page_permalink() : home_url( '/my-account/' ) ); ?>"><?php esc_html_e( 'My Account', 'align-theme' ); ?></a>
        <a href="<?php echo esc_url( home_url( '/wishlist/' ) ); ?>"><?php esc_html_e( 'Wishlist', 'align-theme' ); ?></a>

    </div>
</nav>

<!-- Cart drawer -->
<div class="overlay cart-overlay" id="cart-overlay" hidden aria-modal="true" role="dialog" aria-label="<?php esc_attr_e( 'Cart', 'align-theme' ); ?>">
    <div class="drawer" id="cart-drawer">
        <div class="drawer-head">
            <h2><?php esc_html_e( 'Your Cart', 'align-theme' ); ?></h2>
            <button type="button" class="icon-btn cart-close" aria-label="<?php esc_attr_e( 'Close cart', 'align-theme' ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <div class="cart-drawer-inner">
            <?php if ( function_exists( 'woocommerce_mini_cart' ) ) { woocommerce_mini_cart(); } ?>
        </div>

        <?php
        // Cart upsells: show 3 popular products not already in cart
        if ( function_exists( 'wc_get_products' ) ) :
            $cart_ids = function_exists( 'WC' ) && WC()->cart ? array_map( function( $item ) { return $item['product_id']; }, WC()->cart->get_cart() ) : [];
            $upsells  = wc_get_products( [ 'limit' => 6, 'orderby' => 'popularity', 'status' => 'publish', 'exclude' => $cart_ids ] );
            $upsells  = array_slice( $upsells, 0, 3 );
            if ( ! empty( $upsells ) ) : ?>
        <div class="cart-upsells">
            <div class="cart-upsells-label"><?php esc_html_e( 'You might also like', 'align-theme' ); ?></div>
            <?php foreach ( $upsells as $up ) :
                $up_img = wp_get_attachment_image_url( $up->get_image_id(), 'thumbnail' ) ?: wc_placeholder_img_src();
            ?>
            <a href="<?php echo esc_url( $up->get_permalink() ); ?>" class="cart-upsell-item">
                <img src="<?php echo esc_url( $up_img ); ?>" alt="<?php echo esc_attr( $up->get_name() ); ?>" width="54" height="54">
                <div class="cart-upsell-info">
                    <span class="cart-upsell-name"><?php echo esc_html( $up->get_name() ); ?></span>
                    <span class="cart-upsell-price"><?php echo wp_kses_post( $up->get_price_html() ); ?></span>
                </div>
                <span class="cart-upsell-arrow">
                    <svg viewBox="0 0 24 24" width="14" height="14"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; endif; ?>

        <div class="cart-drawer-trust">
            <span><svg viewBox="0 0 24 24" width="12" height="12"><path d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8"/></svg> <?php esc_html_e( 'Free shipping over $400', 'align-theme' ); ?></span>
            <span><svg viewBox="0 0 24 24" width="12" height="12"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> <?php esc_html_e( 'Secure checkout', 'align-theme' ); ?></span>
        </div>
    </div>
</div>

<!-- Search overlay -->
<div class="overlay search-overlay" id="search-overlay" hidden aria-modal="true" role="dialog" aria-label="<?php esc_attr_e( 'Search', 'align-theme' ); ?>">
    <div class="search-panel">
        <div class="drawer-head">
            <h2><?php esc_html_e( 'Search', 'align-theme' ); ?></h2>
            <button type="button" class="icon-btn search-close" aria-label="<?php esc_attr_e( 'Close search', 'align-theme' ); ?>">
                <svg class="icon" viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <?php get_search_form(); ?>
        <div class="search-results" id="search-results"></div>
    </div>
</div>

<div id="toast" role="status" aria-live="polite"></div>

<div id="primary">
