<?php
/**
 * Template Name: Track Order
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Order support', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Track your order.', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Enter your order information to look up its status.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap section" style="padding-top:0">
    <div class="form-card" style="max-width:560px">
        <h2><?php esc_html_e( 'Order tracking', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Use the order number and email address from your order confirmation.', 'align-theme' ); ?></p>
        <?php
        // Use WooCommerce's native order tracking form if available
        if ( function_exists( 'woocommerce_order_tracking' ) || shortcode_exists( 'woocommerce_order_tracking' ) ) :
            echo do_shortcode( '[woocommerce_order_tracking]' );
        else :
        ?>
        <form class="form-grid" method="post" action="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ?: home_url( '/my-account/orders/' ) ); ?>">
            <?php wp_nonce_field( 'woocommerce-order_tracking', 'woocommerce-order-tracking-nonce' ); ?>
            <label class="field full">
                <?php esc_html_e( 'Order number', 'align-theme' ); ?>
                <input type="text" name="orderid" required placeholder="<?php esc_attr_e( '#12345', 'align-theme' ); ?>">
            </label>
            <label class="field full">
                <?php esc_html_e( 'Billing email', 'align-theme' ); ?>
                <input type="email" name="order_email" required placeholder="<?php esc_attr_e( 'you@example.com', 'align-theme' ); ?>">
            </label>
            <div style="grid-column:1/-1">
                <button type="submit" class="btn">
                    <?php esc_html_e( 'Track order', 'align-theme' ); ?>
                    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16m-6-6 6 6-6 6"/></svg>
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
