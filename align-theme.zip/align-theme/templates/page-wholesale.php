<?php
/**
 * Template Name: Wholesale
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Align partnerships', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Wholesale Portal', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Research-use-only compounds, direct pricing for approved accounts.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap section" style="padding-top:0">
    <div class="two-column">
        <div>
            <h2 style="font-size:38px;margin-bottom:24px"><?php esc_html_e( 'Structured supply.', 'align-theme' ); ?><br><?php esc_html_e( 'Documented quality.', 'align-theme' ); ?></h2>
            <p style="margin-bottom:24px;font-size:14px;line-height:1.8"><?php esc_html_e( 'Orders are subject to review and confirmation before fulfillment. All products are for laboratory and research use only.', 'align-theme' ); ?></p>
            <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'myaccount' ) ) : home_url( '/my-account/' ) ); ?>" class="btn">
                <?php esc_html_e( 'Sign in to your wholesale account', 'align-theme' ); ?>
            </a>
            <p style="margin-top:25px;font-size:14px">
                <?php esc_html_e( 'Not approved yet?', 'align-theme' ); ?>
                <a href="<?php echo esc_url( home_url( '/wholesale-apply/' ) ); ?>" class="text-link">
                    <?php esc_html_e( 'Apply for a wholesale account →', 'align-theme' ); ?>
                </a>
            </p>
        </div>
        <div>
            <div class="contact-card">
                <h3><?php esc_html_e( 'A Disciplined Wholesale Model', 'align-theme' ); ?></h3>
                <p style="margin-top:15px;font-size:14px;line-height:1.75"><?php esc_html_e( 'Structured pricing. Consistent documentation standards. Independent laboratory testing.', 'align-theme' ); ?></p>
                <a href="<?php echo esc_url( home_url( '/partnership/' ) ); ?>" class="text-link" style="display:inline-block;margin-top:20px">
                    <?php esc_html_e( 'Explore partnership information →', 'align-theme' ); ?>
                </a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
