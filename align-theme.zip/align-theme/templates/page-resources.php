<?php
/**
 * Template Name: Resources
 */
defined( 'ABSPATH' ) || exit;
get_header();

// Query posts from 'post' type for articles/resources
$args = [
    'post_type'      => 'post',
    'post_status'    => 'publish',
    'posts_per_page' => 12,
    'orderby'        => 'date',
    'order'          => 'DESC',
];
$articles = new WP_Query( $args );
$icons    = [ 'file', 'lab', 'shield', 'check' ];
$icon_paths = [
    'file'   => 'M5 3h9l5 5v13H5V3Zm9 0v6h5M8 13h8M8 17h6',
    'lab'    => 'M8 3h8M9 3v7L3 20h18l-6-10V3M7 15h10',
    'shield' => 'M12 2l8 3v7c0 5-8 10-8 10S4 17 4 12V5l8-3zM9 12l2 2 4-4',
    'check'  => 'M7 12l3 3 7-7M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z',
];
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'The research library', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Research &amp; Resources', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Plain-language guides on peptides, Canadian regulation, sourcing, and lab technique.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap section" style="padding-top:0">
    <?php if ( $articles->have_posts() ) : ?>
    <div class="article-grid">
        <?php $i = 0; while ( $articles->have_posts() ) : $articles->the_post();
            $icon_key  = $icons[ $i % 4 ];
            $icon_path = $icon_paths[ $icon_key ];
            $i++;
        ?>
        <article class="article-card">
            <a href="<?php the_permalink(); ?>">
                <div class="article-visual">
                    <span>RESEARCH NOTES<br>ALIGN BIOSCIENCES</span>
                    <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="<?php echo esc_attr( $icon_path ); ?>"/></svg>
                </div>
                <div class="article-card-content">
                    <div class="eyebrow"><?php esc_html_e( 'Research &amp; Resources', 'align-theme' ); ?></div>
                    <h2><?php the_title(); ?></h2>
                    <p><?php echo wp_trim_words( get_the_excerpt() ?: get_the_content(), 20 ); ?></p>
                    <span class="text-link"><?php esc_html_e( 'Read article →', 'align-theme' ); ?></span>
                </div>
            </a>
        </article>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <?php else : ?>
    <div class="empty-state">
        <h2><?php esc_html_e( 'No articles yet', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Research guides and resources will appear here.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="btn"><?php esc_html_e( 'Browse compounds', 'align-theme' ); ?></a>
    </div>
    <?php endif; ?>
</section>

<?php get_footer(); ?>
