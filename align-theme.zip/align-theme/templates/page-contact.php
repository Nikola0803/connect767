<?php
/**
 * Template Name: Contact Us
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Contact Align', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( "Let's talk research.", 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Questions about product availability, Certificates of Analysis, batch documentation or an order? We\'re here to help.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="two-column wrap section" style="padding-top:0">
    <div>
        <?php
        // If the page has content (e.g. a CF7 or WPForms shortcode), render it
        while ( have_posts() ) : the_post();
            $content = get_the_content();
        endwhile;

        if ( ! empty( trim( strip_tags( $content ) ) ) ) :
            echo '<div class="form-card">';
            the_content();
            echo '</div>';
        else : ?>
        <form class="form-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <?php wp_nonce_field( 'align_contact', 'align_contact_nonce' ); ?>
            <input type="hidden" name="action" value="align_contact_form">
            <h2><?php esc_html_e( 'Send us a message', 'align-theme' ); ?></h2>
            <p><?php esc_html_e( 'Including your order number and product name helps us respond faster.', 'align-theme' ); ?></p>
            <div class="form-grid">
                <label class="field">
                    <?php esc_html_e( 'Your name', 'align-theme' ); ?>
                    <input type="text" name="contact_name" required placeholder="<?php esc_attr_e( 'Full name', 'align-theme' ); ?>">
                </label>
                <label class="field">
                    <?php esc_html_e( 'Your email', 'align-theme' ); ?>
                    <input type="email" name="contact_email" required placeholder="<?php esc_attr_e( 'you@example.com', 'align-theme' ); ?>">
                </label>
                <label class="field full">
                    <?php esc_html_e( 'Order number (optional)', 'align-theme' ); ?>
                    <input type="text" name="contact_order" placeholder="<?php esc_attr_e( '#12345', 'align-theme' ); ?>">
                </label>
                <label class="field full">
                    <?php esc_html_e( 'Your message', 'align-theme' ); ?>
                    <textarea name="contact_message" required rows="5" placeholder="<?php esc_attr_e( 'How can we help?', 'align-theme' ); ?>"></textarea>
                </label>
                <label class="check-field field full">
                    <input type="checkbox" required name="contact_privacy">
                    <span><?php
                        printf(
                            esc_html__( 'I agree to the %s.', 'align-theme' ),
                            '<a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '" class="text-link">' . esc_html__( 'Privacy Policy', 'align-theme' ) . '</a>'
                        );
                    ?></span>
                </label>
                <div style="grid-column:1/-1">
                    <button type="submit" class="btn">
                        <?php esc_html_e( 'Send message', 'align-theme' ); ?>
                        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16m-6-6 6 6-6 6"/></svg>
                    </button>
                </div>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <div>
        <div class="contact-card">
            <div class="eyebrow"><?php esc_html_e( 'Customer Support', 'align-theme' ); ?></div>
            <h3><?php esc_html_e( 'Real questions.', 'align-theme' ); ?><br><?php esc_html_e( 'A direct conversation.', 'align-theme' ); ?></h3>
            <a href="mailto:info@alignpeptides.com">info@alignpeptides.com</a>
            <p style="margin-top:25px"><?php esc_html_e( 'Messages are reviewed during regular business hours. Please allow one to two business days for a reply.', 'align-theme' ); ?></p>
            <p style="margin-top:12px">P.O BOX 92064 WOODBRIDGE RPO PIAZZA VILAGGIO, ON L4L 3J3</p>
        </div>
        <p class="small muted" style="margin-top:25px;font-size:12px;line-height:1.7"><?php esc_html_e( 'Align Biosciences supplies materials strictly for laboratory research use. We cannot provide medical advice, dosing information, reconstitution guidance, administration instructions, or any direction for human or animal use. Enquiries of that nature will not be answered.', 'align-theme' ); ?></p>
    </div>
</section>

<?php get_footer(); ?>
