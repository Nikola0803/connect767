<?php
/**
 * Template Name: Compare Products
 */
defined( 'ABSPATH' ) || exit;
get_header();

$saved_slugs = [];
if ( is_user_logged_in() ) {
    $saved_slugs = get_user_meta( get_current_user_id(), '_align_saved_products', true ) ?: [];
} else {
    $saved_slugs = isset( $_COOKIE['align_saved'] ) ? json_decode( stripslashes( $_COOKIE['align_saved'] ), true ) ?: [] : [];
}
$saved_slugs = array_slice( (array) $saved_slugs, 0, 3 );

$saved_products = [];
foreach ( $saved_slugs as $slug ) {
    $product_post = get_page_by_path( $slug, OBJECT, 'product' );
    if ( $product_post ) {
        $saved_products[] = wc_get_product( $product_post->ID );
    }
}
$saved_products = array_filter( $saved_products );
?>

<section class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Your research shortlist', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Compare research listings.', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Save products with the heart icon to compare available formats and documentation.', 'align-theme' ); ?></p>
    </div>
</section>

<div class="wrap section" style="padding-top:0">
    <?php if ( ! empty( $saved_products ) ) : ?>
    <div class="product-grid">
        <?php foreach ( $saved_products as $product ) : ?>
            <?php
            $product_id  = $product->get_id();
            $img_url     = wp_get_attachment_image_url( $product->get_image_id(), 'align-product' ) ?: wc_placeholder_img_src();
            $cats        = wc_get_product_category_list( $product_id );
            $price_html  = $product->get_price_html();
            $in_stock    = $product->is_in_stock();
            $coa         = align_get_coa( $product_id );
            ?>
            <article class="product-card">
                <div class="card-index">
                    <span><?php echo wp_kses_post( $cats ); ?></span>
                </div>
                <a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>" class="product-media">
                    <img src="<?php echo esc_url( $img_url ); ?>"
                         alt="<?php echo esc_attr( $product->get_name() ); ?>"
                         loading="lazy">
                    <span class="image-view"><?php esc_html_e( 'Explore compound', 'align-theme' ); ?> ›</span>
                </a>
                <div class="product-card-info">
                    <h3><a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h3>
                    <div class="product-card-foot">
                        <span class="price"><?php echo wp_kses_post( $price_html ); ?></span>
                        <a href="<?php echo esc_url( get_permalink( $product_id ) ); ?>" class="card-arrow" aria-label="<?php esc_attr_e( 'View product', 'align-theme' ); ?>">
                            <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 12h16m-6-6 6 6-6 6"/></svg>
                        </a>
                    </div>
                    <div class="card-document">
                        <span><?php echo $in_stock ? esc_html__( 'Available for research', 'align-theme' ) : esc_html__( 'Currently unavailable', 'align-theme' ); ?></span>
                        <?php if ( $coa['url'] ) : ?>
                        <a href="<?php echo esc_url( $coa['url'] ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Lab reports ↗', 'align-theme' ); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
    <?php else : ?>
    <div class="empty-state">
        <svg class="icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14l1 14H4L5 7Z"/><path d="M9 8V5a3 3 0 0 1 6 0v3"/></svg>
        <h2><?php esc_html_e( 'Select products to compare.', 'align-theme' ); ?></h2>
        <p><?php esc_html_e( 'Save up to three listings from the catalogue.', 'align-theme' ); ?></p>
        <a href="<?php echo esc_url( function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' ) ); ?>" class="btn">
            <?php esc_html_e( 'Explore products', 'align-theme' ); ?>
        </a>
    </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
