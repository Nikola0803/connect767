<?php
/**
 * Template Name: Reading Layout
 * Description: Sidebar navigation + article content — for about, research standards, policy pages.
 */
defined( 'ABSPATH' ) || exit;
get_header();

// Detect whether this is a policy page or a company page to build the sidebar
$slug = get_post_field( 'post_name', get_the_ID() );
$policy_slugs = [ 'shipping-policy', 'refund-policy', 'privacy-policy', 'terms-conditions', 'affiliate-tos-page' ];
$is_policy    = in_array( $slug, $policy_slugs, true );

$sidebar_links = $is_policy ? [
    '/shipping-policy/'   => __( 'Shipping Policy', 'align-theme' ),
    '/refund-policy/'     => __( 'Refund Policy', 'align-theme' ),
    '/privacy-policy/'    => __( 'Privacy Policy', 'align-theme' ),
    '/terms-conditions/'  => __( 'Terms &amp; Conditions', 'align-theme' ),
] : [
    '/about-us/'          => __( 'About Align', 'align-theme' ),
    '/research/'          => __( 'Research Standards', 'align-theme' ),
    '/faqs/'              => __( 'FAQs', 'align-theme' ),
    '/contact-us/'        => __( 'Contact', 'align-theme' ),
    '/partnership/'       => __( 'Partnership', 'align-theme' ),
];

$eyebrow = $is_policy ? __( 'Policies &amp; information', 'align-theme' ) : __( 'Align Biosciences', 'align-theme' );
?>
<?php while ( have_posts() ) : the_post(); ?>
<div class="page-hero tint">
    <div class="wrap">
        <?php align_breadcrumbs(); ?>
        <div class="eyebrow"><?php echo $eyebrow; ?></div>
        <h1><?php the_title(); ?></h1>
    </div>
</div>

<section class="reading-layout wrap">
    <aside class="reading-sidebar">
        <?php foreach ( $sidebar_links as $path => $label ) :
            $is_active = ( '/' . $slug . '/' === $path ) ? ' class="active"' : '';
        ?>
        <a href="<?php echo esc_url( home_url( $path ) ); ?>"<?php echo $is_active; ?>>
            <?php echo $label; ?>
        </a>
        <?php endforeach; ?>
    </aside>
    <article class="content-copy">
        <?php the_content(); ?>
    </article>
</section>
<?php endwhile; ?>

<?php get_footer(); ?>
