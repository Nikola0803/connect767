<?php
/**
 * Template Name: FAQs
 */
defined( 'ABSPATH' ) || exit;
get_header();
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Help &amp; support', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Frequently Asked Questions', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Clear information about research use, documentation and Canadian shipping.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap section" style="max-width:900px;padding-top:0">
    <?php
    // If the page has content, render it (for custom FAQ content via editor)
    while ( have_posts() ) : the_post();
        $has_content = trim( strip_tags( get_the_content() ) ) !== '';
    endwhile;

    if ( $has_content ) :
        the_content();
    else :
    ?>

    <h2 style="font-size:28px;margin:32px 0 20px"><?php esc_html_e( 'Shopping Information', 'align-theme' ); ?></h2>
    <div class="faq-list">
        <details>
            <summary><?php esc_html_e( 'What are ALIGN BIOSCIENCES products intended for?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'ALIGN BIOSCIENCES products are intended for research use only and are developed within clearly defined scientific boundaries.', 'align-theme' ); ?></div>
        </details>
        <details>
            <summary><?php esc_html_e( 'How is product quality verified?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'Each product undergoes structured testing and is supported by batch-specific documentation to confirm specifications and consistency.', 'align-theme' ); ?></div>
        </details>
        <details>
            <summary><?php esc_html_e( 'Do products include Certificates of Analysis (COAs)?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'Yes. Certificates of Analysis are provided for production batches to support transparency and independent verification.', 'align-theme' ); ?></div>
        </details>
    </div>

    <h2 style="font-size:28px;margin:32px 0 20px"><?php esc_html_e( 'Shipping Information', 'align-theme' ); ?></h2>
    <div class="faq-list">
        <details>
            <summary><?php esc_html_e( 'How quickly are orders shipped?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'Orders are processed promptly and dispatched through controlled logistics workflows designed to maintain product integrity. Ships next business day for orders placed Monday to Friday.', 'align-theme' ); ?></div>
        </details>
        <details>
            <summary><?php esc_html_e( 'Is international shipping available?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'No, we only ship within Canada.', 'align-theme' ); ?></div>
        </details>
    </div>

    <h2 style="font-size:28px;margin:32px 0 20px"><?php esc_html_e( 'Payment Information', 'align-theme' ); ?></h2>
    <div class="faq-list">
        <details>
            <summary><?php esc_html_e( 'What payment methods do you accept?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'We accept credit cards, onramp card-to-crypto payments, and direct cryptocurrency payments.', 'align-theme' ); ?></div>
        </details>
        <details>
            <summary><?php esc_html_e( 'Are payments secure?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'Yes. All payments are processed through secure, encrypted payment systems.', 'align-theme' ); ?></div>
        </details>
        <details>
            <summary><?php esc_html_e( 'Can I pay directly using cryptocurrency?', 'align-theme' ); ?></summary>
            <div class="faq-answer"><?php esc_html_e( 'Yes. Direct cryptocurrency payments are supported where available.', 'align-theme' ); ?></div>
        </details>
    </div>

    <?php endif; ?>

    <div style="margin-top:40px">
        <a href="<?php echo esc_url( home_url( '/contact-us/' ) ); ?>" class="btn outline">
            <?php esc_html_e( 'Still have a question? Contact us', 'align-theme' ); ?>
        </a>
    </div>
</section>

<?php get_footer(); ?>
