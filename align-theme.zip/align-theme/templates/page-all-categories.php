<?php
/**
 * Template Name: All Categories
 */
defined( 'ABSPATH' ) || exit;
get_header();

$cat_names = [
    'all-peptides'       => __( 'All Products', 'align-theme' ),
    'glps'               => __( 'GLPs', 'align-theme' ),
    'research-pens'      => __( 'Research Pens', 'align-theme' ),
    'recovery-repair'    => __( 'Recovery Research', 'align-theme' ),
    'longevity'          => __( 'Longevity Research', 'align-theme' ),
    'metabolic-research' => __( 'Metabolic Research', 'align-theme' ),
    'metabolic-compounds'=> __( 'Metabolic Compounds', 'align-theme' ),
    'growth-research'    => __( 'Growth Research', 'align-theme' ),
    'hormonal-cognitive' => __( 'Hormonal &amp; Cognitive', 'align-theme' ),
    'research-bundles'   => __( 'Stacks &amp; Bundles', 'align-theme' ),
    'research-supplies'  => __( 'Research Supplies', 'align-theme' ),
    'single-peptides'    => __( 'Single Peptides', 'align-theme' ),
    'peptide-blends'     => __( 'Peptide Blends', 'align-theme' ),
    'peptide-stacks'     => __( 'Research Stacks', 'align-theme' ),
];
?>
<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'Explore Align', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Find your research category.', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Categories based on research classification.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap section" style="padding-top:0">
    <div class="directory-grid">
        <?php foreach ( $cat_names as $slug => $name ) :
            if ( $slug === 'all-peptides' ) {
                $href  = function_exists( 'wc_get_page_id' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop/' );
                $count = absint( wp_count_posts( 'product' )->publish );
            } else {
                $cat_obj = get_term_by( 'slug', $slug, 'product_cat' );
                if ( ! $cat_obj ) continue;
                $href  = get_term_link( $cat_obj );
                $count = absint( $cat_obj->count );
            }
        ?>
        <a class="contact-card" href="<?php echo esc_url( $href ); ?>" style="display:block;text-decoration:none">
            <div class="eyebrow" style="margin-bottom:10px"><?php echo $count; ?> <?php esc_html_e( 'products', 'align-theme' ); ?></div>
            <h3><?php echo $name; ?></h3>
            <span class="text-link" style="display:inline-block;margin-top:14px"><?php esc_html_e( 'Browse category →', 'align-theme' ); ?></span>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<?php get_footer(); ?>
