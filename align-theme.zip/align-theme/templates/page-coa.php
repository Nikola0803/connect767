<?php
/**
 * Template Name: COA Listing
 */
defined( 'ABSPATH' ) || exit;
get_header();

$coas = [
    ['name'=>'BPC-157','compound'=>'Pentadecapeptide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0269','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0269-2026030630-02.pdf'],
    ]],
    ['name'=>'CJC-1295 + Ipamorelin','compound'=>'CJC-1295 · Ipamorelin','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0249','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0249-2026030612-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.57% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-CJCI-10-040626-01.pdf'],
    ]],
    ['name'=>'DSIP','compound'=>'Nonapeptide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0251','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0251-2026030614-02.pdf'],
    ]],
    ['name'=>'GHK-Cu','compound'=>'Copper-binding tripeptide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0261','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0261-2026030622-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.84% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-GHKC-100-040626-01.pdf'],
    ]],
    ['name'=>'IGF-1 LR3','compound'=>'Insulin-like growth factor analog','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0263','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0263-2026030624-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 96.87% · Tested May 2026 · Batch VTL-IGF01102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-ILGF3-1mg-050926-01.pdf'],
    ]],
    ['name'=>'NAD+','compound'=>'Nicotinamide adenine dinucleotide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0247','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0247-2026030610-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 97.33% · Tested May 2026 · Batch VTL-NAD500102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-NAD-500mg-050926-01.pdf'],
    ]],
    ['name'=>'Retatrutide','compound'=>'Triple-agonist peptide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Apr 2026 · Batch 5026_0271','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0271-2026030632-01.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.43% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-RETA-10-040626-01.pdf'],
    ]],
    ['name'=>'TB-500','compound'=>'Thymosin β4 fragment','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0267','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0267-2026030628-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.02% · Tested May 2026 · Batch VTL-TB5005','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-TB500-5mg-050926-01.pdf'],
    ]],
    ['name'=>'Tesamorelin','compound'=>'GHRH analog','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0273','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0273-2026030634-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.67% · Tested May 2026 · Batch VTL-TES10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-TESA-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Wolverine Stack','compound'=>'BPC-157 · TB-500','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 100.00% · Tested Mar 2026 · Batch 5026_0253','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0253-2026030616-02.pdf'],
    ]],
    ['name'=>'MOTS-C','compound'=>'Mitochondrial-derived peptide','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 98.27% · Tested Mar 2026 · Batch 5026_0258','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0258-2026030620-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 98.54% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-MOTS-10-040626-01.pdf'],
    ]],
    ['name'=>'KLOW 80mg','compound'=>'BPC-157 · TB-500 · GHK-Cu · KPV','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 97.65% · Tested Mar 2026 · Batch 5026_0265','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0265-2026030626-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 98.67% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-KLOW-80-040626-01.pdf'],
    ]],
    ['name'=>'GLOW 70mg','compound'=>'BPC-157 · TB-500 · GHK-Cu','labs'=>[
        ['name'=>'PPB Analytical Inc., Toronto','scope'=>'Heavy Metals + Purity','meta'=>'Purity · 97.16% · Tested Mar 2026 · Batch 5026_0255','url'=>'https://alignpeptides.com/wp-content/uploads/2026/04/Certificate-of-Analysis-5026_0255-2026030618-02.pdf'],
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.94% · Tested Apr 2026 · Batch 040626-01','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-GLOW-70-040626-01.pdf'],
    ]],
    ['name'=>'AOD-9604','compound'=>'Fragment 176-191','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.95% · Tested May 2026 · Batch VTL-AOD10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-AOD-10mg-050926-01.pdf'],
    ]],
    ['name'=>'CJC-1295 without DAC','compound'=>'mod GRF (1-29)','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.74% · Tested May 2026 · Batch VTL-CJC05102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-CJCN-5mg-050926-01.pdf'],
    ]],
    ['name'=>'Epithalon','compound'=>'Tetrapeptide','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.18% · Tested May 2026 · Batch VTL-EPI70101','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-EPI-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Ipamorelin','compound'=>'Pentapeptide secretagogue','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.91% · Tested May 2026 · Batch VTL-IPA10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-IPA-10mg-050926-01.pdf'],
    ]],
    ['name'=>'KPV','compound'=>'Tripeptide (α-MSH fragment)','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.74% · Tested May 2026 · Batch VTL-KPV10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-KPV-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Glutathione','compound'=>'Tripeptide antioxidant','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.96% · Tested May 2026 · Batch VTL-GLU1500102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-LGLU-1500mg-050926-01.pdf'],
    ]],
    ['name'=>'MT-2','compound'=>'Melanotan II','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.91% · Tested May 2026 · Batch VTL-MT210102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-MELA-10mg-050926-01.pdf'],
    ]],
    ['name'=>'PT-141','compound'=>'Bremelanotide','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.64% · Tested May 2026 · Batch VTL-PT110102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-PT141-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Selank','compound'=>'Heptapeptide','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.73% · Tested May 2026 · Batch VTL-SEL10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-SEL-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Semax','compound'=>'Heptapeptide (ACTH fragment)','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.94% · Tested May 2026 · Batch VTL-SEM10103','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-SEMAX-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Thymosin Alpha-1','compound'=>'Thymosin α1 peptide','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.49% · Tested May 2026 · Batch VTL-TA10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-TA1-10mg-050926-01.pdf'],
    ]],
    ['name'=>'Tirzepatide','compound'=>'Dual GIP/GLP-1 agonist','labs'=>[
        ['name'=>'Testides','scope'=>'Endotoxins + Purity','meta'=>'Purity · 99.47% · Tested May 2026 · Batch VTL-TIR10102','url'=>'https://alignpeptides.com/wp-content/uploads/2026/07/BW-TIRZ-10mg-050926-01.pdf'],
    ]],
];
?>

<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php esc_html_e( 'The lab results library', 'align-theme' ); ?></div>
        <h1><?php esc_html_e( 'Certificates of Analysis', 'align-theme' ); ?></h1>
        <p><?php esc_html_e( 'Independent laboratory verification and batch-specific documentation. Review the full report for the compound and batch you receive.', 'align-theme' ); ?></p>
    </div>
</div>

<section class="wrap" style="padding-bottom:80px">
    <div class="source-note">
        <?php esc_html_e( 'Results are specific to the tested sample. Where more than one laboratory report is available, each report is listed separately with its original batch details.', 'align-theme' ); ?>
    </div>

    <input class="coa-search" id="coa-search" type="search"
        placeholder="<?php esc_attr_e( 'Search compound, laboratory or batch…', 'align-theme' ); ?>"
        aria-label="<?php esc_attr_e( 'Search certificates', 'align-theme' ); ?>">

    <div id="coa-results">
        <p class="small muted" id="coa-count" style="margin-bottom:20px"><?php echo count( $coas ); ?> <?php esc_html_e( 'compound records', 'align-theme' ); ?></p>
        <div class="coa-grid coa-register">
            <?php foreach ( $coas as $c ) : ?>
            <article class="coa-card">
                <div class="coa-identity">
                    <div class="eyebrow"><?php esc_html_e( 'Original laboratory reports', 'align-theme' ); ?></div>
                    <h2><?php echo esc_html( $c['name'] ); ?></h2>
                    <p class="muted"><?php echo esc_html( $c['compound'] ); ?></p>
                </div>
                <div class="coa-labs">
                    <?php foreach ( $c['labs'] as $lab ) : ?>
                    <div class="lab-record">
                        <strong><?php echo esc_html( $lab['name'] ); ?></strong>
                        <span><?php echo esc_html( $lab['scope'] ); ?></span>
                        <p><?php echo esc_html( $lab['meta'] ); ?></p>
                        <a class="btn outline small" href="<?php echo esc_url( $lab['url'] ); ?>" target="_blank" rel="noopener">
                            <?php esc_html_e( 'View full COA ↗', 'align-theme' ); ?>
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
(function(){
    var input = document.getElementById('coa-search');
    var count = document.getElementById('coa-count');
    if(!input) return;
    input.addEventListener('input', function(){
        var q = this.value.toLowerCase();
        var cards = document.querySelectorAll('#coa-results .coa-card');
        var visible = 0;
        cards.forEach(function(card){
            var match = !q || card.textContent.toLowerCase().indexOf(q) > -1;
            card.style.display = match ? '' : 'none';
            if(match) visible++;
        });
        if(count) count.textContent = visible + ' compound records';
    });
})();
</script>

<?php get_footer(); ?>
