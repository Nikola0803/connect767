<?php
defined( 'ABSPATH' ) || exit;
get_header();

while ( have_posts() ) :
    the_post();

    $categories = get_the_category();
    $cat_label  = ! empty( $categories ) ? esc_html( $categories[0]->name ) : __( 'Align Biosciences', 'align-theme' );
?>

<div class="page-hero tint">
    <div class="wrap">
        <div class="eyebrow"><?php echo $cat_label; ?></div>
        <h1><?php the_title(); ?></h1>
        <p class="hero-meta">
            <?php echo esc_html( get_the_date() ); ?>
            <?php if ( get_the_author() ) : ?>
            · <?php echo esc_html( get_the_author() ); ?>
            <?php endif; ?>
        </p>
    </div>
</div>

<section class="reading-layout wrap">

    <aside class="reading-sidebar">

        <?php
        // Recent posts in same category, fall back to latest posts
        $args = [
            'posts_per_page'      => 8,
            'post__not_in'        => [ get_the_ID() ],
            'ignore_sticky_posts' => true,
        ];
        if ( ! empty( $categories ) ) {
            $args['category__in'] = wp_list_pluck( $categories, 'term_id' );
        }
        $sidebar_posts = get_posts( $args );
        ?>

        <?php if ( ! empty( $categories ) ) : ?>
        <div class="eyebrow" style="margin-bottom:12px"><?php echo $cat_label; ?></div>
        <?php endif; ?>

        <?php foreach ( $sidebar_posts as $sp ) : ?>
        <a href="<?php echo esc_url( get_permalink( $sp ) ); ?>" class="reading-sidebar-link<?php echo ( $sp->ID === get_the_ID() ) ? ' active' : ''; ?>">
            <?php echo esc_html( get_the_title( $sp ) ); ?>
        </a>
        <?php endforeach; ?>

        <?php if ( empty( $sidebar_posts ) ) : ?>
        <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ?: home_url( '/blog/' ) ); ?>" class="reading-sidebar-link">
            <?php esc_html_e( '← All posts', 'align-theme' ); ?>
        </a>
        <?php endif; ?>

    </aside>

    <article class="content-copy" id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

        <?php if ( has_post_thumbnail() ) : ?>
        <figure style="margin:0 0 40px;border-radius:16px;overflow:hidden">
            <?php the_post_thumbnail( 'full', [ 'style' => 'width:100%;height:auto;display:block' ] ); ?>
        </figure>
        <?php endif; ?>

        <?php the_content(); ?>

        <?php
        wp_link_pages( [
            'before' => '<nav class="page-links">' . __( 'Pages:', 'align-theme' ),
            'after'  => '</nav>',
        ] );
        ?>

        <?php if ( get_the_tags() ) : ?>
        <div style="margin-top:40px;padding-top:28px;border-top:1px solid var(--line);display:flex;gap:8px;flex-wrap:wrap">
            <?php foreach ( get_the_tags() as $tag ) : ?>
            <a href="<?php echo esc_url( get_tag_link( $tag ) ); ?>" style="font-size:12px;padding:5px 11px;border:1px solid var(--line);border-radius:99px;color:var(--body)">
                <?php echo esc_html( $tag->name ); ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Post navigation -->
        <nav class="post-nav" style="margin-top:48px;padding-top:28px;border-top:1px solid var(--line);display:grid;grid-template-columns:1fr 1fr;gap:20px">
            <?php
            $prev = get_previous_post();
            $next = get_next_post();
            if ( $prev ) : ?>
            <a href="<?php echo esc_url( get_permalink( $prev ) ); ?>" style="font-size:13px;color:var(--body)">
                <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( '← Previous', 'align-theme' ); ?></div>
                <?php echo esc_html( get_the_title( $prev ) ); ?>
            </a>
            <?php else : ?><div></div><?php endif; ?>
            <?php if ( $next ) : ?>
            <a href="<?php echo esc_url( get_permalink( $next ) ); ?>" style="font-size:13px;color:var(--body);text-align:right">
                <div class="eyebrow" style="margin-bottom:4px"><?php esc_html_e( 'Next →', 'align-theme' ); ?></div>
                <?php echo esc_html( get_the_title( $next ) ); ?>
            </a>
            <?php endif; ?>
        </nav>

    </article>

</section>

<?php
endwhile;
get_footer();
?>
