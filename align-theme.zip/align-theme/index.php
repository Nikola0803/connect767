<?php
// Silence is golden. WordPress requires this file.
get_header();
if ( have_posts() ) {
    while ( have_posts() ) {
        the_post();
        get_template_part( 'template-parts/content', get_post_type() );
    }
} else {
    get_template_part( 'template-parts/content', 'none' );
}
get_footer();
